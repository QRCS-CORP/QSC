#ifndef QSC_TEST_PSK_CODEC_H
#define QSC_TEST_PSK_CODEC_H

/**
 * \file test_pre_shared_key_codec.h
 * \brief TLS PSK Extension Codec Test
 *
 * \details
 * Validates encoding and decoding of the TLS pre_shared_key extension.
 * Ensures identity and binder integrity across round-trip operations.
 */

/**
 * \brief Execute PSK codec test
 *
 * \return int Returns 0 on success, non-zero on failure
 */
int main(void);

#endif
