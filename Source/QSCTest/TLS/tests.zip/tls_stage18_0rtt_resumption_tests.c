/* End-to-end 0-RTT resumption gate.
 *
 * Sequence:
 *   Phase 1 (fresh):  full 1-RTT handshake, server emits NST, client stores ticket.
 *   Phase 2 (resume): fresh client/server, client offers PSK + early_data,
 *                     client writes 0-RTT app data BEFORE the server's flight1
 *                     is processed, server accepts early_data, decrypts the
 *                     0-RTT bytes, completes handshake.
 *
 * Verifies:
 *   - server.pskaccepted, client.pskaccepted
 *   - server.earlydataaccepted, client.earlydataaccepted
 *   - the 0-RTT bytes are received by the server under early_traffic keys
 *   - handshake completes and post-handshake app data works under app keys
 */
#include "tlsengine.h"
#include "tlsclient.h"
#include "tlsserver.h"
#include "tlssession.h"
#include "tlssigner_default.h"
#include "memutils.h"
#include "secrand.h"
#include "acp.h"
#include "eddsa.h"
#include <stdio.h>
#include <string.h>

static int failures = 0;
#define CHECK(c,m) do{ if(!(c)){printf("FAIL: %s\n",m); failures++;} }while(0)

/* --- simple in-memory PSK store for the server --- */
typedef struct psk_entry {
    uint8_t id[64];
    size_t  idlen;
    uint8_t psk[64];
    size_t  psklen;
    qsc_tls_cipher_suite suite;
} psk_entry;

static psk_entry g_store;

static bool psk_lookup_cb(const uint8_t* identity, size_t identitylen,
    uint8_t* psk_out, size_t pskcap, size_t* psk_len_out,
    qsc_tls_cipher_suite* suite_out, uint32_t* max_early_data_out, void* state)
{
    (void)state;
    if (identitylen != g_store.idlen) return false;
    if (memcmp(identity, g_store.id, identitylen) != 0) return false;
    if (g_store.psklen > pskcap) return false;
    qsc_memutils_copy(psk_out, g_store.psk, g_store.psklen);
    *psk_len_out = g_store.psklen;
    *suite_out = g_store.suite;
    *max_early_data_out = 16384U;
    return true;
}

static uint8_t g_server_pk[32];
static uint8_t g_server_sk[64];
static uint8_t g_server_cert[32];

static bool stub_validate(const qsc_tls_certificate_view* chain, size_t chainlength,
    const qsc_tls_certificate_validation_context* ctx, void* state)
{ (void)ctx; (void)state; return chainlength == 1U && chain[0].datalen == 32U; }

static bool stub_verify(qsc_tls_signature_scheme scheme, const uint8_t* input, size_t inputlen,
    const uint8_t* signature, size_t signaturelen, const qsc_tls_certificate_view* signer, void* state)
{ (void)signer; (void)state;
  qsc_tls_certificate_view v = { g_server_pk, 32 };
  return qsc_tls_signer_default_verify(scheme, input, inputlen, signature, signaturelen, &v, NULL); }

static int do_handshake(qsc_tls_connection* c, qsc_tls_connection* s)
{
    uint8_t c2s[8192], s2c[32768], junk[128];
    size_t c2s_len=0, s2c_len=0, consumed, written;
    qsc_tls_status st = qsc_tls_engine_handshake(c, NULL, 0, &consumed, c2s, sizeof(c2s), &c2s_len);
    if (st || !c2s_len) return 0;
    st = qsc_tls_engine_handshake(s, c2s, c2s_len, &consumed, s2c, sizeof(s2c), &s2c_len);
    if (st) return 0;
    size_t off=0, fin_len=0;
    while (off < s2c_len && !qsc_tls_engine_is_handshake_complete(c)) {
        size_t w=0;
        st = qsc_tls_engine_handshake(c, s2c+off, s2c_len-off, &consumed, c2s, sizeof(c2s), &w);
        if (st) return 0;
        off += consumed;
        if (w) fin_len = w;
    }
    if (!qsc_tls_engine_is_handshake_complete(c)) return 0;
    st = qsc_tls_engine_handshake(s, c2s, fin_len, &consumed, junk, sizeof(junk), &written);
    return (!st && qsc_tls_engine_is_handshake_complete(s)) ? 1 : 0;
}

int main(void)
{
    uint8_t seed[32];
    qsc_acp_generate(seed, sizeof(seed));
    qsc_secrand_initialize(seed, sizeof(seed), NULL, 0U);
    qsc_eddsa_generate_keypair(g_server_pk, g_server_sk, qsc_secrand_generate);
    qsc_memutils_copy(g_server_cert, g_server_pk, 32U);

    const qsc_tls_cipher_suite suites[1] = { qsc_tls_cipher_suite_tls_aes_128_gcm_sha256 };
    const qsc_tls_named_group groups[1] = { qsc_tls_group_x25519 };
    const qsc_tls_signature_scheme sigs[1] = { qsc_tls_sig_ed25519 };

    qsc_tls_signer_default_context signer_ctx;
    signer_ctx.scheme = qsc_tls_sig_ed25519;
    signer_ctx.privatekey = g_server_sk;
    signer_ctx.privatekeylen = 64;

    /* ====================== PHASE 1: fresh handshake + NST ====================== */
    printf("0-RTT resumption gate\n");
    printf("Phase 1: fresh handshake + NewSessionTicket\n");

    qsc_tls_client_config ccfg1;
    qsc_memutils_clear(&ccfg1, sizeof(ccfg1));
    ccfg1.ciphersuites = suites; ccfg1.ciphersuitecount = 1;
    ccfg1.groups = groups; ccfg1.groupcount = 1;
    ccfg1.sigschemes = sigs; ccfg1.sigschemecount = 1;
    ccfg1.hostname = "example.com";
    ccfg1.certinterface.validatechain = stub_validate;
    ccfg1.certinterface.verifycertificateverify = stub_verify;

    qsc_tls_server_config scfg1;
    qsc_memutils_clear(&scfg1, sizeof(scfg1));
    scfg1.ciphersuitepreference = suites; scfg1.ciphersuitepreferencecount = 1;
    scfg1.groupspreference = groups; scfg1.groupspreferencecount = 1;
    scfg1.sigschemepreference = sigs; scfg1.sigschemepreferencecount = 1;
    scfg1.localcert.chain[0].data = g_server_cert;
    scfg1.localcert.chain[0].datalen = 32;
    scfg1.localcert.chainlength = 1;
    scfg1.localcert.verifyscheme = qsc_tls_sig_ed25519;
    scfg1.localcert.configured = true;
    scfg1.localcert.signcallback = qsc_tls_signer_default_sign;
    scfg1.localcert.signstate = &signer_ctx;

    qsc_tls_connection c1, s1;
    qsc_tls_engine_initialize_client(&c1, &ccfg1);
    qsc_tls_engine_initialize_server(&s1, &scfg1);
    CHECK(do_handshake(&c1, &s1), "phase1 handshake completes");

    /* Server emits NST, client consumes, both derive identical PSK. */
    qsc_tls_session_ticket srv_ticket, cli_ticket;
    uint8_t nst[2048];
    size_t nst_len = 0;
    qsc_tls_status st = qsc_tls_engine_emit_session_ticket(&s1, 7200U, nst, sizeof(nst), &nst_len, &srv_ticket);
    CHECK(st == qsc_tls_status_success, "server emit NST");
    size_t consumed = 0;
    st = qsc_tls_engine_consume_session_ticket(&c1, nst, nst_len, &consumed, &cli_ticket);
    CHECK(st == qsc_tls_status_success, "client consume NST");
    CHECK(memcmp(srv_ticket.resumptionsecret, cli_ticket.resumptionsecret, srv_ticket.resumptionsecretlen) == 0, "PSK matches");

    /* Stash PSK in server store (keyed on ticket id). */
    qsc_memutils_clear(&g_store, sizeof(g_store));
    g_store.idlen = srv_ticket.ticketlen;
    qsc_memutils_copy(g_store.id, srv_ticket.ticket, srv_ticket.ticketlen);
    g_store.psklen = srv_ticket.resumptionsecretlen;
    qsc_memutils_copy(g_store.psk, srv_ticket.resumptionsecret, srv_ticket.resumptionsecretlen);
    g_store.suite = srv_ticket.suite;

    qsc_tls_engine_dispose(&c1);
    qsc_tls_engine_dispose(&s1);

    /* ====================== PHASE 2: resumed handshake with 0-RTT ====================== */
    printf("Phase 2: resumption with 0-RTT\n");

    qsc_tls_client_config ccfg2 = ccfg1;
    ccfg2.offeredticket = &cli_ticket;
    ccfg2.enableearlydata = true;

    qsc_tls_server_config scfg2 = scfg1;
    scfg2.psklookup = psk_lookup_cb;
    scfg2.psklookupstate = NULL;
    scfg2.acceptearlydata = true;

    qsc_tls_connection c2, s2;
    qsc_tls_engine_initialize_client(&c2, &ccfg2);
    qsc_tls_engine_initialize_server(&s2, &scfg2);

    /* --- 1) Client emits CH with PSK + early_data. --- */
    uint8_t ch_rec[4096];
    size_t ch_rec_len = 0, cons = 0;
    st = qsc_tls_engine_handshake(&c2, NULL, 0, &cons, ch_rec, sizeof(ch_rec), &ch_rec_len);
    CHECK(st == qsc_tls_status_success && ch_rec_len > 0, "PSK+0RTT ClientHello emitted");
    CHECK(c2.state.client.pskoffered, "client flag pskoffered");
    CHECK(c2.state.client.earlydataoffered, "client flag earlydataoffered");
    printf("  C -> S  CH (PSK+early_data): %zu bytes\n", ch_rec_len);

    /* --- 2) Client writes a 0-RTT app-data record under early_traffic keys. --- */
    const uint8_t early_payload[] = "ping-0rtt";
    uint8_t early_rec[256];
    size_t early_rec_len = 0;
    st = qsc_tls_engine_write_application_data(&c2, early_payload, sizeof(early_payload)-1,
        early_rec, sizeof(early_rec), &early_rec_len);
    CHECK(st == qsc_tls_status_success && early_rec_len > 0, "client 0-RTT app-data record emitted");
    printf("  C -> S  0-RTT record: %zu bytes\n", early_rec_len);

    /* --- 3) Server processes CH. --- */
    uint8_t sh_flight[32768];
    size_t sh_flight_len = 0;
    st = qsc_tls_engine_handshake(&s2, ch_rec, ch_rec_len, &cons, sh_flight, sizeof(sh_flight), &sh_flight_len);
    CHECK(st == qsc_tls_status_success, "server processes PSK CH");
    CHECK(s2.state.server.pskaccepted, "server accepted PSK");
    CHECK(s2.state.server.earlydataaccepted, "server accepted 0-RTT");
    printf("  S      pskaccepted=%d, earlydataaccepted=%d\n",
        s2.state.server.pskaccepted, s2.state.server.earlydataaccepted);
    printf("  S -> C  flight1: %zu bytes\n", sh_flight_len);

    /* --- 4) Server consumes 0-RTT app data under early_traffic keys. --- */
    uint8_t rx_payload[256], rx_resp[256];
    size_t rx_consumed = 0, rx_plainlen = 0, rx_resplen = 0;
    st = qsc_tls_engine_read_application_data_ex(&s2, early_rec, early_rec_len, &rx_consumed,
        rx_payload, sizeof(rx_payload), &rx_plainlen,
        rx_resp, sizeof(rx_resp), &rx_resplen);
    CHECK(st == qsc_tls_status_success, "server decrypts 0-RTT record");
    CHECK(rx_plainlen == sizeof(early_payload)-1, "0-RTT plaintext len matches");
    CHECK(memcmp(rx_payload, early_payload, rx_plainlen) == 0, "0-RTT plaintext bytes match");
    printf("  S      decrypted 0-RTT payload: \"%.*s\"\n", (int)rx_plainlen, rx_payload);

    /* --- 5) Client consumes server flight1, emits EOED+Finished. --- */
    uint8_t c_out[4096];
    size_t c_out_len = 0;
    size_t off = 0;
    size_t fin_len = 0;
    while (off < sh_flight_len && !qsc_tls_engine_is_handshake_complete(&c2))
    {
        size_t w = 0;
        st = qsc_tls_engine_handshake(&c2, sh_flight+off, sh_flight_len-off, &cons,
            c_out, sizeof(c_out), &w);
        if (st != qsc_tls_status_success) break;
        off += cons;
        if (w > 0) { c_out_len = w; fin_len = w; }
    }
    CHECK(qsc_tls_engine_is_handshake_complete(&c2), "client reached established after flight1");
    CHECK(c2.state.client.pskaccepted, "client flag pskaccepted");
    CHECK(c2.state.client.earlydataaccepted, "client flag earlydataaccepted");
    printf("  C -> S  EOED+Finished: %zu bytes\n", fin_len);

    /* --- 6) Server consumes EOED+Finished. --- */
    uint8_t srv_junk[256];
    size_t srv_junk_len = 0;
    size_t srv_off = 0;
    while (srv_off < fin_len && !qsc_tls_engine_is_handshake_complete(&s2))
    {
        st = qsc_tls_engine_handshake(&s2, c_out+srv_off, fin_len-srv_off, &cons,
            srv_junk, sizeof(srv_junk), &srv_junk_len);
        if (st != qsc_tls_status_success) break;
        srv_off += cons;
        if (cons == 0) break;
    }
    CHECK(qsc_tls_engine_is_handshake_complete(&s2), "server reached established after EOED+Finished");

    /* --- 7) Post-handshake app-data exchange under app keys, both directions. --- */
    const uint8_t late_c[] = "late-from-client";
    const uint8_t late_s[] = "late-from-server";
    uint8_t rec[512];
    size_t rlen = 0;
    uint8_t plain[512];
    size_t plen = 0;
    size_t dummy = 0;

    st = qsc_tls_engine_write_application_data(&c2, late_c, sizeof(late_c)-1, rec, sizeof(rec), &rlen);
    CHECK(st == qsc_tls_status_success, "post-hs C->S write");
    st = qsc_tls_engine_read_application_data_ex(&s2, rec, rlen, &cons, plain, sizeof(plain), &plen,
        NULL, 0, &dummy);
    CHECK(st == qsc_tls_status_success && plen == sizeof(late_c)-1, "post-hs S reads C");
    CHECK(memcmp(plain, late_c, plen) == 0, "post-hs payload C->S matches");

    st = qsc_tls_engine_write_application_data(&s2, late_s, sizeof(late_s)-1, rec, sizeof(rec), &rlen);
    CHECK(st == qsc_tls_status_success, "post-hs S->C write");
    st = qsc_tls_engine_read_application_data_ex(&c2, rec, rlen, &cons, plain, sizeof(plain), &plen,
        NULL, 0, &dummy);
    CHECK(st == qsc_tls_status_success && plen == sizeof(late_s)-1, "post-hs C reads S");
    CHECK(memcmp(plain, late_s, plen) == 0, "post-hs payload S->C matches");

    printf("  post-handshake app-data exchange OK\n");

    qsc_tls_session_ticket_dispose(&srv_ticket);
    qsc_tls_session_ticket_dispose(&cli_ticket);
    qsc_tls_engine_dispose(&c2);
    qsc_tls_engine_dispose(&s2);

    if (failures == 0) { printf("\n0-RTT resumption: all checks passed\n"); return 0; }
    printf("\n0-RTT resumption: %d FAILURES\n", failures);
    return 1;
}
