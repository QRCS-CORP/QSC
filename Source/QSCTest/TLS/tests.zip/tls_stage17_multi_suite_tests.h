#ifndef QSC_TEST_MULTI_SUITE_H
#define QSC_TEST_MULTI_SUITE_H

/**
 * \file test_multi_suite.h
 * \brief Multi Cipher Suite TLS Test
 *
 * \details
 * Executes TLS handshakes across multiple cipher suites:
 * AES-128-GCM, AES-256-GCM, and ChaCha20-Poly1305.
 * Ensures negotiation correctness and data integrity.
 */

/**
 * \brief Execute multi-suite test
 *
 * \return int Returns 0 on success, non-zero on failure
 */
int main(void);

#endif
