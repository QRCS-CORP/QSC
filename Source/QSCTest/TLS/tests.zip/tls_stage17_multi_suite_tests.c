/* Multi-cipher-suite end-to-end gate.
 *
 * Drives a paired client/server through a full 1-RTT handshake under each of:
 *   - TLS_AES_128_GCM_SHA256
 *   - TLS_AES_256_GCM_SHA384
 *   - TLS_CHACHA20_POLY1305_SHA256
 *
 * Verifies the negotiated suite is the one offered, that both sides reach
 * the established phase, and that post-handshake app-data exchange works in
 * both directions.
 *
 * This catches any size assumptions baked into transcript snapshots, key
 * derivations, Finished computation, or AEAD record protection that would
 * silently fail under the SHA-384 / ChaCha20-Poly1305 paths.
 */
#include "tlsengine.h"
#include "tlsclient.h"
#include "tlsserver.h"
#include "tlssigner_default.h"
#include "memutils.h"
#include "secrand.h"
#include "acp.h"
#include "eddsa.h"
#include <stdio.h>
#include <string.h>

static int failures = 0;
#define CHECK(c,m) do{ if(!(c)){printf("    FAIL: %s\n",m); failures++;} }while(0)

static uint8_t g_server_pk[32];
static uint8_t g_server_sk[64];
static uint8_t g_server_cert[32];

static bool stub_validate(const qsc_tls_certificate_view* chain, size_t chainlength,
    const qsc_tls_certificate_validation_context* ctx, void* state)
{ (void)ctx; (void)state; return chainlength == 1U && chain[0].datalen == 32U; }

static bool stub_verify(qsc_tls_signature_scheme scheme, const uint8_t* input, size_t inputlen,
    const uint8_t* signature, size_t signaturelen, const qsc_tls_certificate_view* signer, void* state)
{ (void)signer; (void)state;
  qsc_tls_certificate_view v = { g_server_pk, 32 };
  return qsc_tls_signer_default_verify(scheme, input, inputlen, signature, signaturelen, &v, NULL); }

static int run_handshake_under_suite(qsc_tls_cipher_suite suite, const char* suite_name)
{
    printf("  Suite: %s (0x%04x)\n", suite_name, (unsigned)suite);
    int suite_failures_before = failures;

    const qsc_tls_cipher_suite suites[1] = { suite };
    const qsc_tls_named_group groups[1] = { qsc_tls_group_x25519 };
    const qsc_tls_signature_scheme sigs[1] = { qsc_tls_sig_ed25519 };

    qsc_tls_signer_default_context signer_ctx;
    signer_ctx.scheme = qsc_tls_sig_ed25519;
    signer_ctx.privatekey = g_server_sk;
    signer_ctx.privatekeylen = 64;

    qsc_tls_client_config ccfg;
    qsc_memutils_clear(&ccfg, sizeof(ccfg));
    ccfg.ciphersuites = suites; ccfg.ciphersuitecount = 1;
    ccfg.groups = groups; ccfg.groupcount = 1;
    ccfg.sigschemes = sigs; ccfg.sigschemecount = 1;
    ccfg.hostname = "example.com";
    ccfg.certinterface.validatechain = stub_validate;
    ccfg.certinterface.verifycertificateverify = stub_verify;

    qsc_tls_server_config scfg;
    qsc_memutils_clear(&scfg, sizeof(scfg));
    scfg.ciphersuitepreference = suites; scfg.ciphersuitepreferencecount = 1;
    scfg.groupspreference = groups; scfg.groupspreferencecount = 1;
    scfg.sigschemepreference = sigs; scfg.sigschemepreferencecount = 1;
    scfg.localcert.chain[0].data = g_server_cert;
    scfg.localcert.chain[0].datalen = 32;
    scfg.localcert.chainlength = 1;
    scfg.localcert.verifyscheme = qsc_tls_sig_ed25519;
    scfg.localcert.configured = true;
    scfg.localcert.signcallback = qsc_tls_signer_default_sign;
    scfg.localcert.signstate = &signer_ctx;

    qsc_tls_connection c, s;
    qsc_tls_engine_initialize_client(&c, &ccfg);
    qsc_tls_engine_initialize_server(&s, &scfg);

    /* CH */
    uint8_t ch[4096], srv_flight[32768], cli_fin[1024], junk[256];
    size_t ch_len = 0, srv_flight_len = 0, cli_fin_len = 0, junk_len = 0, cons = 0;
    qsc_tls_status st = qsc_tls_engine_handshake(&c, NULL, 0, &cons, ch, sizeof(ch), &ch_len);
    CHECK(st == qsc_tls_status_success && ch_len > 0, "client emits ClientHello");

    /* server processes CH, emits flight1 */
    st = qsc_tls_engine_handshake(&s, ch, ch_len, &cons, srv_flight, sizeof(srv_flight), &srv_flight_len);
    CHECK(st == qsc_tls_status_success && srv_flight_len > 0, "server processes CH and emits flight1");

    /* client consumes flight1 across multiple records (SH plaintext, then encrypted EE/Cert/CV/Fin) */
    size_t off = 0;
    while (off < srv_flight_len && !qsc_tls_engine_is_handshake_complete(&c)) {
        size_t w = 0;
        st = qsc_tls_engine_handshake(&c, srv_flight+off, srv_flight_len-off, &cons,
            cli_fin, sizeof(cli_fin), &w);
        if (st != qsc_tls_status_success) break;
        off += cons;
        if (w > 0) cli_fin_len = w;
        if (cons == 0) break;
    }
    CHECK(qsc_tls_engine_is_handshake_complete(&c), "client reached established");
    CHECK(cli_fin_len > 0, "client emitted Finished");
    CHECK(c.state.client.negotiatedsuite == suite, "client negotiated requested suite");

    /* server consumes client Finished */
    st = qsc_tls_engine_handshake(&s, cli_fin, cli_fin_len, &cons, junk, sizeof(junk), &junk_len);
    CHECK(st == qsc_tls_status_success, "server processes client Finished");
    CHECK(qsc_tls_engine_is_handshake_complete(&s), "server reached established");
    CHECK(s.state.server.negotiatedsuite == suite, "server negotiated requested suite");

    /* post-handshake app data, both directions */
    const uint8_t c2s_plain[] = "hello-from-client";
    const uint8_t s2c_plain[] = "ack-from-server";
    uint8_t rec[512], plain[512];
    size_t reclen = 0, plen = 0, dummy = 0;

    st = qsc_tls_engine_write_application_data(&c, c2s_plain, sizeof(c2s_plain)-1, rec, sizeof(rec), &reclen);
    CHECK(st == qsc_tls_status_success && reclen > 0, "C->S write");
    st = qsc_tls_engine_read_application_data_ex(&s, rec, reclen, &cons, plain, sizeof(plain), &plen,
        NULL, 0, &dummy);
    CHECK(st == qsc_tls_status_success && plen == sizeof(c2s_plain)-1, "S reads C plaintext");
    CHECK(memcmp(plain, c2s_plain, plen) == 0, "C->S payload bytes match");

    st = qsc_tls_engine_write_application_data(&s, s2c_plain, sizeof(s2c_plain)-1, rec, sizeof(rec), &reclen);
    CHECK(st == qsc_tls_status_success && reclen > 0, "S->C write");
    st = qsc_tls_engine_read_application_data_ex(&c, rec, reclen, &cons, plain, sizeof(plain), &plen,
        NULL, 0, &dummy);
    CHECK(st == qsc_tls_status_success && plen == sizeof(s2c_plain)-1, "C reads S plaintext");
    CHECK(memcmp(plain, s2c_plain, plen) == 0, "S->C payload bytes match");

    qsc_tls_engine_dispose(&c);
    qsc_tls_engine_dispose(&s);

    int suite_failures = failures - suite_failures_before;
    if (suite_failures == 0) printf("    OK\n");
    else                     printf("    %d FAILURES under %s\n", suite_failures, suite_name);
    return suite_failures == 0 ? 0 : 1;
}

int main(void)
{
    uint8_t seed[32];
    qsc_acp_generate(seed, sizeof(seed));
    qsc_secrand_initialize(seed, sizeof(seed), NULL, 0U);
    qsc_eddsa_generate_keypair(g_server_pk, g_server_sk, qsc_secrand_generate);
    qsc_memutils_copy(g_server_cert, g_server_pk, 32U);

    printf("Multi-suite e2e gate\n");
    run_handshake_under_suite(qsc_tls_cipher_suite_tls_aes_128_gcm_sha256, "TLS_AES_128_GCM_SHA256");
    run_handshake_under_suite(qsc_tls_cipher_suite_tls_aes_256_gcm_sha384, "TLS_AES_256_GCM_SHA384");
    run_handshake_under_suite(qsc_tls_cipher_suite_tls_chacha20_poly1305_sha256, "TLS_CHACHA20_POLY1305_SHA256");

    if (failures == 0) { printf("\nMulti-suite e2e: all checks passed\n"); return 0; }
    printf("\nMulti-suite e2e: %d FAILURES\n", failures);
    return 1;
}
