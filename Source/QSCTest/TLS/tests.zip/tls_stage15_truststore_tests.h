#ifndef QSC_TEST_TRUSTSTORE_H
#define QSC_TEST_TRUSTSTORE_H

/**
 * \file test_truststore.h
 * \brief TLS X.509 Trust Store Integration Test
 *
 * \details
 * Validates TLS certificate verification behavior using X.509 trust stores.
 * Exercises self-signed, empty store, strict, and anchored verification modes.
 */

/**
 * \brief Execute trust store integration test
 *
 * \return int Returns 0 on success, non-zero on failure
 */
int main(void);

#endif
