#ifndef QSC_TEST_0RTT_RESUMPTION_H
#define QSC_TEST_0RTT_RESUMPTION_H

/**
 * \file test_0rtt_resumption.h
 * \brief TLS 1.3 0-RTT Resumption Test
 *
 * \details
 * Verifies session ticket issuance, PSK resumption, and early data handling.
 * Confirms correct encryption, decryption, and handshake completion.
 */

/**
 * \brief Execute 0-RTT resumption test
 *
 * \return int Returns 0 on success, non-zero on failure
 */
int main(void);

#endif
