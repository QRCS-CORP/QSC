/* Trust-store integration gate.
 *
 * Verifies that the X.509-backed TLS certificate interface, when given a
 * non-NULL trust store, calls qsc_x509_chain_verify and translates the
 * verify status into an appropriate TLS alert.
 *
 * Uses Ed25519 as the issuance signing algorithm. Ed25519 was added to the
 * QSC certificate builder's supported list (qsc_x509_certwrite_signature_
 * algorithm_is_supported and qsc_x509_certwrite_spki_is_signature_capable)
 * in this iteration; previously only ECDSA and ML-DSA were accepted there
 * even though the verification side already accepted Ed25519.
 */
#include "tlscert_x509.h"
#include "tlslimits.h"
#include "tlscert.h"
#include "x509cert.h"
#include "x509certwrite.h"
#include "x509store.h"
#include "x509verify.h"
#include "x509types.h"
#include "x509name.h"
#include "x509ext.h"
#include "x509time.h"
#include "x509spki.h"
#include "x509sigver.h"
#include "memutils.h"
#include "secrand.h"
#include "acp.h"
#include "eddsa.h"
#include "timestamp.h"
#include "asn1.h"
#include "oid.h"
#include <stdio.h>
#include <string.h>

static int failures = 0;
#define CHECK(c,m) do{ if(!(c)){printf("FAIL: %s\n",m); failures++;} }while(0)

static uint8_t g_pk[32];
static uint8_t g_sk[64];

static qsc_asn1_status sign_cb(qsc_x509_signature_algorithm signaturealgorithm,
    const uint8_t* tbs, size_t tbslen,
    uint8_t* signature, size_t* signaturelen, void* context)
{
    (void)context;
    if (signaturealgorithm != QSC_X509_SIGNATURE_ALGORITHM_ED25519)
        return QSC_ASN1_STATUS_UNSUPPORTED;
    if (signature == NULL || signaturelen == NULL || *signaturelen < 64U)
        return QSC_ASN1_STATUS_BUFFER_TOO_SMALL;
    /* qsc_eddsa_sign produces signature || message. Extract the leading
     * 64-byte detached signature. */
    uint8_t scratch[2048];
    size_t scratchlen = sizeof(scratch);
    if (tbslen + 64U > sizeof(scratch))
        return QSC_ASN1_STATUS_BUFFER_TOO_SMALL;
    qsc_eddsa_sign(scratch, &scratchlen, tbs, tbslen, g_sk);
    qsc_memutils_copy(signature, scratch, 64U);
    *signaturelen = 64U;
    return QSC_ASN1_STATUS_SUCCESS;
}

static void epoch_to_x509_time(qsc_x509_time* out, uint64_t epoch)
{
    qsc_memutils_clear(out, sizeof(*out));
    uint64_t days = epoch / 86400ULL;
    uint64_t sod  = epoch % 86400ULL;
    int64_t z = (int64_t)days + 719468;
    int64_t era = (z >= 0 ? z : z - 146096) / 146097;
    uint64_t doe = (uint64_t)(z - era * 146097);
    uint64_t yoe = (doe - doe/1460 + doe/36524 - doe/146096) / 365;
    int64_t y = (int64_t)yoe + era * 400;
    uint64_t doy = doe - (365U*yoe + yoe/4U - yoe/100U);
    uint64_t mp  = (5U*doy + 2U) / 153U;
    uint32_t d   = (uint32_t)(doy - (153U*mp + 2U)/5U + 1U);
    uint32_t m   = (uint32_t)(mp < 10U ? mp + 3U : mp - 9U);
    y += (m <= 2U) ? 1 : 0;
    out->year = (uint16_t)y;
    out->month = (uint8_t)m;
    out->day = (uint8_t)d;
    out->hour = (uint8_t)(sod / 3600ULL);
    out->minute = (uint8_t)((sod % 3600ULL) / 60ULL);
    out->second = (uint8_t)(sod % 60ULL);
    out->generalized = (out->year >= 2050U || out->year < 1950U);
}

static void name_set_cn(qsc_x509_name* name, const char* cn)
{
    qsc_memutils_clear(name, sizeof(*name));
    name->count = 1U;
    name->attributes[0].type = QSC_X509_NAME_ATTRIBUTE_COMMON_NAME;
    name->attributes[0].oid = QSC_OID_ID_COMMON_NAME;
    qsc_oid_to_asn1(QSC_OID_ID_COMMON_NAME, &name->attributes[0].attribute_oid);
    name->attributes[0].string_tag = 0x0CU;
    name->attributes[0].rdn_index = 0U;
    size_t l = strlen(cn);
    if (l > QSC_X509_NAME_ATTRIBUTE_STRING_MAX) l = QSC_X509_NAME_ATTRIBUTE_STRING_MAX;
    qsc_memutils_copy(name->attributes[0].value, cn, l);
    name->attributes[0].length = l;
}

static size_t build_cert(uint8_t* out, size_t outcap, const char* cn)
{
    qsc_x509_certificate_builder b;
    qsc_x509_certificate_builder_initialize(&b);

    static const uint8_t serial[] = { 0x01 };
    qsc_x509_certificate_builder_set_serial(&b, serial, sizeof(serial));

    qsc_x509_name issuer, subject;
    name_set_cn(&issuer, cn);
    name_set_cn(&subject, cn);
    qsc_x509_certificate_builder_set_issuer(&b, &issuer);
    qsc_x509_certificate_builder_set_subject(&b, &subject);

    qsc_x509_validity vd;
    qsc_memutils_clear(&vd, sizeof(vd));
    uint64_t now = qsc_timestamp_epochtime_seconds();
    epoch_to_x509_time(&vd.notbefore, now - 60U);
    epoch_to_x509_time(&vd.notafter,  now + 31536000U);
    qsc_x509_certificate_builder_set_validity(&b, &vd);

    qsc_x509_subject_public_key_info spki;
    qsc_memutils_clear(&spki, sizeof(spki));
    spki.algorithm.oid = QSC_OID_ID_ED25519;
    spki.algorithm.publickey = QSC_X509_PUBLIC_KEY_ALGORITHM_ED25519;
    spki.algorithm.signature = QSC_X509_SIGNATURE_ALGORITHM_ED25519;
    qsc_oid_to_asn1(QSC_OID_ID_ED25519, &spki.algorithm.algorithm_oid);
    spki.algorithm.parameters_present = false;
    spki.algorithm.parameters_null = false;
    qsc_memutils_copy(spki.publickey, g_pk, 32U);
    spki.publickeylen = 32U;
    spki.unusedbits = 0U;
    qsc_asn1_status sps = qsc_x509_certificate_builder_set_spki(&b, &spki);
    if (sps != QSC_ASN1_STATUS_SUCCESS) {
        printf("  set_spki failed: %d\n", (int)sps);
        qsc_x509_certificate_builder_clear(&b);
        return 0U;
    }

    qsc_x509_algorithm_identifier sigalg;
    qsc_memutils_clear(&sigalg, sizeof(sigalg));
    sigalg.oid = QSC_OID_ID_ED25519;
    sigalg.publickey = QSC_X509_PUBLIC_KEY_ALGORITHM_ED25519;
    sigalg.signature = QSC_X509_SIGNATURE_ALGORITHM_ED25519;
    qsc_oid_to_asn1(QSC_OID_ID_ED25519, &sigalg.algorithm_oid);
    sigalg.parameters_present = false;
    sigalg.parameters_null = false;
    qsc_asn1_status sas = qsc_x509_certificate_builder_set_signature_algorithm(&b, &sigalg);
    if (sas != QSC_ASN1_STATUS_SUCCESS) {
        printf("  set_sigalg failed: %d\n", (int)sas);
        qsc_x509_certificate_builder_clear(&b);
        return 0U;
    }

    qsc_x509_certificate_builder_add_subject_alt_name_dns(&b, cn, strlen(cn));

    qsc_asn1_status apr = qsc_x509_certificate_builder_apply_profile(&b, QSC_X509_CERT_PROFILE_ROOT_CA);
    if (apr != QSC_ASN1_STATUS_SUCCESS) {
        printf("  apply_profile failed: %d\n", (int)apr);
        qsc_x509_certificate_builder_clear(&b);
        return 0U;
    }
    qsc_asn1_status agi = qsc_x509_certificate_builder_apply_generated_identifiers(&b, NULL);
    if (agi != QSC_ASN1_STATUS_SUCCESS) {
        printf("  apply_generated_identifiers failed: %d\n", (int)agi);
        qsc_x509_certificate_builder_clear(&b);
        return 0U;
    }

    size_t outlen = outcap;
    qsc_asn1_status as = qsc_x509_certificate_builder_sign(&b, sign_cb, NULL, out, &outlen);
    qsc_x509_certificate_builder_clear(&b);
    if (as != QSC_ASN1_STATUS_SUCCESS) {
        printf("  sign/encode failed: %d\n", (int)as);
        return 0U;
    }
    return outlen;
}

int main(void)
{
    uint8_t seed[32];
    qsc_acp_generate(seed, sizeof(seed));
    qsc_secrand_initialize(seed, sizeof(seed), NULL, 0U);
    qsc_eddsa_generate_keypair(g_pk, g_sk, qsc_secrand_generate);

    printf("Trust-store integration gate (Ed25519)\n");

    static uint8_t derbuf[4096];
    size_t derlen = build_cert(derbuf, sizeof(derbuf), "example.com");
    CHECK(derlen > 0, "build self-signed Ed25519 cert");
    if (derlen == 0) { printf("\nABORT\n"); return 1; }
    printf("  built self-signed cert: %zu bytes\n", derlen);

    qsc_tls_certificate_view chain[1];
    chain[0].data = derbuf;
    chain[0].datalen = derlen;

    qsc_tls_certificate_validation_context ctx;
    ctx.hostname = "example.com";
    ctx.clientauth = false;
    ctx.requirepeercertificate = true;

    /* --- 1: pinned-key mode --- */
    {
        qsc_tls_cert_x509_state s;
        qsc_tls_cert_x509_state_initialize(&s, NULL);
        s.allowselfsigned = true;
        s.enforcehostname = true;
        s.enforcevalidityperiod = true;
        qsc_tls_certificate_interface iface;
        qsc_tls_cert_x509_bind(&iface, &s);
        bool ok = iface.validatechain(chain, 1, &ctx, iface.state);
        printf("  [1] pinned mode: ok=%d status=%d alert=%d\n", (int)ok, (int)s.lastverifystatus, (int)s.lastalert);
        CHECK(ok, "pinned/test mode accepts self-signed");
    }

    /* --- 2: no truststore + no self-signed --- */
    {
        qsc_tls_cert_x509_state s;
        qsc_tls_cert_x509_state_initialize(&s, NULL);
        s.allowselfsigned = false;
        s.enforcehostname = true;
        s.enforcevalidityperiod = true;
        qsc_tls_certificate_interface iface;
        qsc_tls_cert_x509_bind(&iface, &s);
        bool ok = iface.validatechain(chain, 1, &ctx, iface.state);
        printf("  [2] no-store strict: ok=%d status=%d alert=%d\n", (int)ok, (int)s.lastverifystatus, (int)s.lastalert);
        CHECK(!ok, "rejected without truststore + !allowselfsigned");
        CHECK(s.lastverifystatus == QSC_X509_VERIFY_STATUS_TRUST_NOT_FOUND, "status=trust_not_found");
        CHECK(s.lastalert == qsc_tls_alert_unknown_ca, "alert=unknown_ca");
    }

    /* --- 3: empty truststore --- */
    {
        qsc_x509_trust_anchor anchors[4];
        qsc_x509_store store;
        qsc_x509_store_initialize(&store, anchors, 4U);
        qsc_tls_cert_x509_state s;
        qsc_tls_cert_x509_state_initialize(&s, &store);
        s.enforcehostname = true;
        s.enforcevalidityperiod = true;
        qsc_tls_certificate_interface iface;
        qsc_tls_cert_x509_bind(&iface, &s);
        bool ok = iface.validatechain(chain, 1, &ctx, iface.state);
        printf("  [3] empty store:   ok=%d status=%d alert=%d\n", (int)ok, (int)s.lastverifystatus, (int)s.lastalert);
        CHECK(!ok, "empty truststore rejects");
        CHECK(s.lastverifystatus != QSC_X509_VERIFY_STATUS_SUCCESS, "chain_verify reported failure");
    }

    /* --- 4: anchored --- */
    {
        qsc_x509_certificate anchor;
        qsc_memutils_clear(&anchor, sizeof(anchor));
        qsc_asn1_status as = qsc_x509_certificate_decode_der(derbuf, derlen, &anchor);
        CHECK(as == QSC_ASN1_STATUS_SUCCESS, "decode anchor cert");
        if (as != QSC_ASN1_STATUS_SUCCESS) goto end;

        qsc_x509_trust_anchor anchors[4];
        qsc_x509_store store;
        qsc_x509_store_initialize(&store, anchors, 4U);
        qsc_asn1_status as2 = qsc_x509_store_add_anchor(&store, &anchor, true);
        CHECK(as2 == QSC_ASN1_STATUS_SUCCESS, "add anchor");

        qsc_tls_cert_x509_state s;
        qsc_tls_cert_x509_state_initialize(&s, &store);
        s.enforcehostname = true;
        s.enforcevalidityperiod = true;
        qsc_tls_certificate_interface iface;
        qsc_tls_cert_x509_bind(&iface, &s);
        bool ok = iface.validatechain(chain, 1, &ctx, iface.state);
        printf("  [4] anchored:      ok=%d status=%d alert=%d\n", (int)ok, (int)s.lastverifystatus, (int)s.lastalert);
        CHECK(ok, "anchored chain validates");
        CHECK(s.lastverifystatus == QSC_X509_VERIFY_STATUS_SUCCESS, "chain_verify success");
        qsc_x509_certificate_clear(&anchor);
    }

end:
    if (failures == 0) { printf("\nTrust-store integration: all checks passed\n"); return 0; }
    printf("\nTrust-store integration: %d FAILURES\n", failures);
    return 1;
}
