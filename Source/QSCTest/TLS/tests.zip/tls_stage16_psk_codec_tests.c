/* pre_shared_key extension codec round-trip gate. */
#include "tlsextensions.h"
#include "memutils.h"
#include <stdio.h>
#include <string.h>

static int failures = 0;
#define CHECK(c,m) do{ if(!(c)){printf("FAIL: %s\n",m); failures++;} }while(0)

int main(void)
{
    uint8_t id1[] = "ticket-id-one-very-long-bytes-32";  /* 32 bytes w/o null, but ID can be anything */
    uint8_t id2[] = "second-id";
    qsc_tls_psk_identity_view ids[2];
    ids[0].identity = id1; ids[0].identitylen = sizeof(id1)-1; ids[0].obfuscatedticketage = 0x12345678U;
    ids[1].identity = id2; ids[1].identitylen = sizeof(id2)-1; ids[1].obfuscatedticketage = 0xDEADBEEFU;

    uint8_t buf[512];
    size_t off = 0U;
    size_t binder_off = 0U;
    qsc_tls_status st = qsc_tls_extensions_encode_pre_shared_key_offer(buf, sizeof(buf), &off,
        ids, 2U, 32U, &binder_off);
    CHECK(st == qsc_tls_status_success, "encode offer");
    CHECK(off > 0U, "offer size nonzero");
    CHECK(binder_off > 0U && binder_off < off, "binder offset inside buffer");

    /* Patch the binders with distinctive bytes so we can round-trip. */
    for (size_t i = 0; i < 32; ++i) buf[binder_off + i]          = 0xAAU;
    for (size_t i = 0; i < 32; ++i) buf[binder_off + 1U + 32U + i] = 0xBBU;

    /* Extract the extension body (skip 2-byte type + 2-byte length). */
    uint16_t etype = ((uint16_t)buf[0] << 8) | buf[1];
    CHECK(etype == qsc_tls_extension_pre_shared_key, "extension type is pre_shared_key");
    uint16_t ebodylen = ((uint16_t)buf[2] << 8) | buf[3];
    CHECK(4U + ebodylen == off, "ext body length matches");

    qsc_tls_psk_identity_view out_ids[4];
    const uint8_t* out_binders[4];
    size_t out_binderlens[4];
    size_t out_count = 0U;
    size_t out_binder_block_off = 0U;

    st = qsc_tls_extensions_decode_pre_shared_key_offer(buf + 4, ebodylen,
        out_ids, out_binders, out_binderlens, 4U, &out_count, &out_binder_block_off);
    CHECK(st == qsc_tls_status_success, "decode offer");
    CHECK(out_count == 2U, "2 identities decoded");

    CHECK(out_ids[0].identitylen == ids[0].identitylen, "id0 len");
    CHECK(memcmp(out_ids[0].identity, ids[0].identity, ids[0].identitylen) == 0, "id0 bytes");
    CHECK(out_ids[0].obfuscatedticketage == 0x12345678U, "id0 age");
    CHECK(out_ids[1].obfuscatedticketage == 0xDEADBEEFU, "id1 age");

    CHECK(out_binderlens[0] == 32U, "binder0 len");
    CHECK(out_binders[0][0] == 0xAAU, "binder0 bytes");
    CHECK(out_binderlens[1] == 32U, "binder1 len");
    CHECK(out_binders[1][0] == 0xBBU, "binder1 bytes");

    /* Server-side extension: just u16 selected_identity. */
    uint8_t srv[16];
    size_t srvoff = 0U;
    st = qsc_tls_extensions_encode_pre_shared_key_server(srv, sizeof(srv), &srvoff, 0x0001);
    CHECK(st == qsc_tls_status_success, "encode server psk");
    CHECK(srvoff == 6U, "server ext = 2 type + 2 len + 2 body");

    uint16_t selected = 0xFFFF;
    st = qsc_tls_extensions_decode_pre_shared_key_server(srv + 4, 2, &selected);
    CHECK(st == qsc_tls_status_success, "decode server psk");
    CHECK(selected == 0x0001, "selected identity round-trips");

    if (failures == 0) { printf("pre_shared_key codec: all checks passed\n"); return 0; }
    printf("pre_shared_key codec: %d FAILURES\n", failures);
    return 1;
}
