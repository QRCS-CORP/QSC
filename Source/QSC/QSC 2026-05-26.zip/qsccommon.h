/* 2020-2026 Quantum Resistant Cryptographic Solutions Corporation
 * All Rights Reserved.
 *
 * NOTICE:
 * This software and all accompanying materials are the exclusive property of
 * Quantum Resistant Cryptographic Solutions Corporation (QRCS). The intellectual
 * and technical concepts contained herein are proprietary to QRCS and are
 * protected under applicable Canadian, U.S., and international copyright,
 * patent, and trade secret laws.
 *
 * CRYPTOGRAPHIC ALGORITHMS AND IMPLEMENTATIONS:
 * - This software includes implementations of cryptographic primitives and
 *   algorithms that are standardized or in the public domain, such as AES
 *   and SHA-3, which are not proprietary to QRCS.
 * - This software also includes cryptographic primitives, constructions, and
 *   algorithms designed by QRCS, including but not limited to RCS, SCB, CSX, QMAC, and
 *   related components, which are proprietary to QRCS.
 * - All source code, implementations, protocol compositions, optimizations,
 *   parameter selections, and engineering work contained in this software are
 *   original works of QRCS and are protected under this license.
 *
 * LICENSE AND USE RESTRICTIONS:
 * - This software is licensed under the Quantum Resistant Cryptographic Solutions
 *   Public Research and Evaluation License (QRCS-PREL), 2025-2026.
 * - Permission is granted solely for non-commercial evaluation, academic research,
 *   cryptographic analysis, interoperability testing, and feasibility assessment.
 * - Commercial use, production deployment, commercial redistribution, or
 *   integration into products or services is strictly prohibited without a
 *   separate written license agreement executed with QRCS.
 * - Licensing and authorized distribution are solely at the discretion of QRCS.
 *
 * EXPERIMENTAL CRYPTOGRAPHY NOTICE:
 * Portions of this software may include experimental, novel, or evolving
 * cryptographic designs. Use of this software is entirely at the user's risk.
 *
 * DISCLAIMER:
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, SECURITY, OR NON-INFRINGEMENT. QRCS DISCLAIMS ALL
 * LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING FROM THE USE OR MISUSE OF THIS SOFTWARE.
 *
 * FULL LICENSE:
 * This software is subject to the Quantum Resistant Cryptographic Solutions
 * Public Research and Evaluation License (QRCS-PREL), 2025-2026. The complete license terms
 * are provided in the accompanying LICENSE file or at https://www.qrcscorp.ca.
 *
 * Written by: John G. Underhill
 * Contact: contact@qrcscorp.ca
 */

#ifndef QSC_COMMON_H
#define QSC_COMMON_H

#if defined(__posix) || defined(__posix__) || defined(__USE_POSIX) || defined(_POSIX_VERSION) || defined(__MACH__) || \
    defined(__linux) || defined(__linux__) || defined(__gnu_linux__) || defined(__unix) || defined(__unix__) || \
    defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__bsdi__) || defined(__DragonFly__)
#   if defined(__linux__)
#       if !defined(_DEFAULT_SOURCE)
#           define _DEFAULT_SOURCE
#       endif
#       if !defined(_XOPEN_SOURCE)
#           define _XOPEN_SOURCE 700
#       endif
#       if !defined(_GNU_SOURCE)
#           define _GNU_SOURCE
#       endif
#   elif defined(__APPLE__) && defined(__MACH__)
#       if !defined(_DARWIN_C_SOURCE)
#           define _DARWIN_C_SOURCE
#       endif
#   elif defined(__sun) && defined(__SVR4)
#       if !defined(__EXTENSIONS__)
#           define __EXTENSIONS__
#       endif
#   elif defined(__FreeBSD__)   || defined(__NetBSD__) || defined(__OpenBSD__)   || defined(__DragonFly__)
#       if !defined(_BSD_SOURCE)
#           define _BSD_SOURCE
#       endif
#endif

#   if !defined(_POSIX_C_SOURCE)
#           define _POSIX_C_SOURCE 200809L
#   endif
#endif

#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#if defined(__cplusplus)
#   define QSC_CPLUSPLUS_ENABLED_START extern "C" {
#   define QSC_CPLUSPLUS_ENABLED_END }
#else
#   define QSC_CPLUSPLUS_ENABLED_START
#   define QSC_CPLUSPLUS_ENABLED_END
#endif

QSC_CPLUSPLUS_ENABLED_START

/*!
 * \file qsccommon.h
 * \brief Contains common definitions for the Quantum Secure Cryptographic (QSC) library.
 *
 * \details
 * This file provides common macros, type definitions, compiler/OS/architecture detection,
 * API export macros, alignment macros, secure memory allocation definitions, and other utility macros.
 * These definitions are used throughout the QSC library to ensure portability and performance.
 */

/*==============================================================================
    Compiler Identification Macros
==============================================================================*/

#if defined(_MSC_VER)
    /*!
    * \def QSC_SYSTEM_COMPILER_MSC
    * \brief Defined when the Microsoft Visual C++ compiler is detected.
    */
#	define QSC_SYSTEM_COMPILER_MSC
#endif

#if defined(__MINGW32__)
    /*!
    * \def QSC_SYSTEM_COMPILER_MINGW
    * \brief Defined when using the MinGW compiler.
    */
#	define QSC_SYSTEM_COMPILER_MINGW
    /*!
    * \def QSC_SYSTEM_COMPILER_GCC
    * \brief Also defined for MinGW as it uses GCC.
    */
#	define QSC_SYSTEM_COMPILER_GCC
#endif

#if defined(__CC_ARM)
    /*!
    * \def QSC_SYSTEM_COMPILER_ARM
    * \brief Defined when using the ARM Compiler.
    */
#	define QSC_SYSTEM_COMPILER_ARM
#endif

#if defined(__BORLANDC__)
    /*!
    * \def QSC_SYSTEM_COMPILER_BORLAND
    * \brief Defined when using the Borland C compiler.
    */
#	define QSC_SYSTEM_COMPILER_BORLAND
#endif

#if defined(__GNUC__) && !defined(__MINGW32__)
    /*!
    * \def QSC_SYSTEM_COMPILER_GCC
    * \brief Defined when GCC-compatible compiler extensions are available.
    *
    * Clang defines __GNUC__ for GCC compatibility; therefore Clang builds may
    * define both QSC_SYSTEM_COMPILER_GCC and QSC_SYSTEM_COMPILER_CLANG. Code
    * requiring Clang-specific behavior must test QSC_SYSTEM_COMPILER_CLANG
    * before testing the GCC compatibility macro.
    */
#	define QSC_SYSTEM_COMPILER_GCC
#endif

#if defined(__clang__)
    /*!
    * \def QSC_SYSTEM_COMPILER_CLANG
    * \brief Defined when the Clang compiler is detected.
    *
    * This macro is not mutually exclusive with QSC_SYSTEM_COMPILER_GCC, because
    * Clang exposes the GCC compatibility preprocessor surface.
    */
#	define QSC_SYSTEM_COMPILER_CLANG
#endif

#if defined(__IBMC__) || defined(__IBMCPP__)
    /*!
    * \def QSC_SYSTEM_COMPILER_IBM
    * \brief Defined when using the IBM compiler.
    */
#	define QSC_SYSTEM_COMPILER_IBM
#endif

#if defined(__INTEL_COMPILER) || defined(__ICL)
    /*!
    * \def QSC_SYSTEM_COMPILER_INTEL
    * \brief Defined when using the Intel compiler.
    */
#	define QSC_SYSTEM_COMPILER_INTEL
#endif

#if defined(__MWERKS__)
    /*!
    * \def QSC_SYSTEM_COMPILER_MWERKS
    * \brief Defined when using the Metrowerks compiler.
    */
#	define QSC_SYSTEM_COMPILER_MWERKS
#endif

#if defined(__OPEN64__)
    /*!
    * \def QSC_SYSTEM_COMPILER_OPEN64
    * \brief Defined when using the Open64 compiler.
    */
#	define QSC_SYSTEM_COMPILER_OPEN64
#endif

#if defined(__SUNPRO_C)
    /*!
    * \def QSC_SYSTEM_COMPILER_SUNPRO
    * \brief Defined when using the SunPro C compiler.
    */
#	define QSC_SYSTEM_COMPILER_SUNPRO
#endif

#if defined(__TURBOC__)
    /*!
    * \def QSC_SYSTEM_COMPILER_TURBO
    * \brief Defined when using the Turbo C compiler.
    */
#	define QSC_SYSTEM_COMPILER_TURBO
#endif

/*==============================================================================
    Operating System Identification Macros
==============================================================================*/

#if defined(_WIN64) || defined(_WIN32) || defined(__WIN64__) || defined(__WIN32__)
    /*!
    * \def QSC_SYSTEM_OS_WINDOWS
    * \brief Defined when the target operating system is Windows.
    */
#	if !defined(QSC_SYSTEM_OS_WINDOWS)
#		define QSC_SYSTEM_OS_WINDOWS
#	endif
#   if defined(_WIN64)
        /*!
        * \def QSC_SYSTEM_ISWIN64
        * \brief Defined when building for 64-bit Windows.
        */
#		define QSC_SYSTEM_ISWIN64
#   elif defined(_WIN32)
        /*!
        * \def QSC_SYSTEM_ISWIN32
        * \brief Defined when building for 32-bit Windows.
        */
#		define QSC_SYSTEM_ISWIN32
#   endif
#else
    typedef int32_t errno_t;
#endif

#if defined(__x86_64__) || defined(__i386__) || defined(_M_IX86) || defined(_M_X64)
#   define QSC_HAS_CPUID
#endif

#if defined(__ANDROID__)
    /*!
    * \def QSC_SYSTEM_OS_ANDROID
    * \brief Defined when the target operating system is Android.
    */
#	define QSC_SYSTEM_OS_ANDROID
#endif

#if defined(__APPLE__) || defined(__MACH__)
#   if defined(__MACH__)
        /*!
        * \def QSC_SYSTEM_OS_MAC
        * \brief Defined when the target operating system is Apple (macOS or iOS).
        */
#	    define QSC_SYSTEM_OS_MAC
#   endif
    /*!
    * \def QSC_SYSTEM_OS_BSD
    * \brief Also defined for BSD-based operating systems (macOS is BSD-based).
    */
#	define QSC_SYSTEM_OS_BSD

#   if defined(TARGET_OS_IPHONE) && defined(TARGET_IPHONE_SIMULATOR)
        /*!
        * \def QSC_SYSTEM_ISIPHONESIM
        * \brief Defined when building for the iPhone Simulator.
        */
#		define QSC_SYSTEM_ISIPHONESIM
#   elif defined(TARGET_OS_IPHONE)
        /*!
        * \def QSC_SYSTEM_ISIPHONE
        * \brief Defined when building for iPhone.
        */
#		define QSC_SYSTEM_ISIPHONE
#   else
        /*!
        * \def QSC_SYSTEM_ISOSX
        * \brief Defined when building for macOS.
        */
#		define QSC_SYSTEM_ISOSX
#   endif
#endif

#if defined(__FreeBSD__)
    /*!
    * \def QSC_SYSTEM_OS_FREEBSD
    * \brief Defined when the target operating system is FreeBSD.
    */
#	define QSC_SYSTEM_OS_FREEBSD
#endif

#if defined(__OpenBSD__)
    /*!
    * \def QSC_SYSTEM_OS_OPENBSD
    * \brief Defined when the target operating system is OpenBSD.
    */
#	define QSC_SYSTEM_OS_OPENBSD
#endif

#if defined(__NetBSD__)
    /*!
    * \def QSC_SYSTEM_OS_NETBSD
    * \brief Defined when the target operating system is NetBSD.
    */
#	define QSC_SYSTEM_OS_NETBSD
#endif

#if defined(__DragonFly__)
    /*!
    * \def QSC_SYSTEM_OS_DRAGONFLY
    * \brief Defined when the target operating system is DragonFly BSD.
    */
#	define QSC_SYSTEM_OS_DRAGONFLY
#endif

#if defined(QSC_SYSTEM_OS_FREEBSD) || defined(QSC_SYSTEM_OS_OPENBSD) || defined(QSC_SYSTEM_OS_NETBSD) || defined(QSC_SYSTEM_OS_DRAGONFLY) || defined(__bsdi__) || defined(QSC_SYSTEM_ISOSX)
    /*!
    * \def QSC_SYSTEM_OS_BSD
    * \brief Defined when the target operating system is a BSD variant.
    */
#	define QSC_SYSTEM_OS_BSD
#endif

#if defined(__linux) || defined(__linux__) || defined(__gnu_linux__)
    /*!
    * \def QSC_SYSTEM_OS_LINUX
    * \brief Defined when the target operating system is Linux.
    */
#	define QSC_SYSTEM_OS_LINUX
#endif

#if defined(__unix) || defined(__unix__)
    /*!
    * \def QSC_SYSTEM_OS_UNIX
    * \brief Defined when the target operating system is Unix.
    */
#	define QSC_SYSTEM_OS_UNIX
#   if defined(__hpux) || defined(hpux)
        /*!
        * \def QSC_SYSTEM_OS_HPUX
        * \brief Defined when the target operating system is HP-UX.
        */
#		define QSC_SYSTEM_OS_HPUX
#   endif
#   if defined(__sun__) || defined(__sun) || defined(sun)
        /*!
        * \def QSC_SYSTEM_OS_SUNUX
        * \brief Defined when the target operating system is Solaris.
        */
#		define QSC_SYSTEM_OS_SUNUX
#   endif
#endif

#if defined(__posix) || defined(__posix__) || defined(__USE_POSIX) || defined(_POSIX_VERSION) || defined(QSC_SYSTEM_OS_UNIX) || defined(QSC_SYSTEM_OS_LINUX) || defined(QSC_SYSTEM_OS_BSD)
    /*!
    * \def QSC_SYSTEM_OS_POSIX
    * \brief Defined when the operating system is POSIX-compliant.
    */
#	define QSC_SYSTEM_OS_POSIX

#endif

#if defined(QSC_SYSTEM_OS_WINDOWS) && defined(QSC_SYSTEM_COMPILER_MSC)
    /*!
    * \def QSC_WINDOWS_VSTUDIO_BUILD
    * \brief Defined when building on Windows using Visual Studio.
    */
#   define QSC_WINDOWS_VSTUDIO_BUILD
#endif

#if defined(_OPENMP)
    /*!
    * \def QSC_SYSTEM_OPENMP
    * \brief Defined when OpenMP support is enabled.
    */
#	define QSC_SYSTEM_OPENMP
#endif

#if defined(DEBUG) || defined(_DEBUG) || defined(__DEBUG__) || (defined(__GNUC__) && !defined(__OPTIMIZE__))
    /*!
    * \def QSC_DEBUG_MODE
    * \brief Defined when the build is in debug mode.
    */
#	define QSC_DEBUG_MODE
#endif

#ifdef QSC_DEBUG_MODE
    /*!
    * \def QSC_ASSERT
    * \brief Define the assert function and guarantee it as debug only.
    */
#  define QSC_ASSERT(expr) assert(expr)
#else
#  define QSC_ASSERT(expr) ((void)0)
#endif

/*==============================================================================
    CPU Architecture Identification Macros
==============================================================================*/

#if defined(__OpenBSD__) || defined(__FreeBSD__) || \
    defined(__NetBSD__) || defined(__APPLE__) || \
    (defined(__GLIBC__) && (__GLIBC__ >= 2 && __GLIBC_MINOR__ >= 25))
#   define QSC_HAVE_EXPLICIT_BZERO 1
#endif

#if defined(QSC_SYSTEM_COMPILER_MSC)
#   if defined(_M_X64) || defined(_M_AMD64)
        /*!
        * \def QSC_SYSTEM_ARCH_IX86_64
        * \brief Defined when building for 64-bit x86 (AMD64/Intel 64).
        */
#	    define QSC_SYSTEM_ARCH_IX86_64
        /*!
        * \def QSC_SYSTEM_ARCH_IX86
        * \brief Also defined when building for x86 architectures.
        */
#		define QSC_SYSTEM_ARCH_IX86
#   if defined(_M_AMD64)
        /*!
        * \def QSC_SYSTEM_ARCH_AMD64
        * \brief Defined when the processor is AMD64.
        */
#		define QSC_SYSTEM_ARCH_AMD64
#   endif
#   elif defined(_M_IX86) || defined(_X86_)
        /*!
        * \def QSC_SYSTEM_ARCH_IX86_32
        * \brief Defined when building for 32-bit x86.
        */
#		define QSC_SYSTEM_ARCH_IX86_32
        /*!
        * \def QSC_SYSTEM_ARCH_IX86
        * \brief Also defined for x86 architectures.
        */
#		define QSC_SYSTEM_ARCH_IX86
#   elif defined(_M_ARM)
        /*!
        * \def QSC_SYSTEM_ARCH_ARM
        * \brief Defined when building for ARM architectures.
        */
#		define QSC_SYSTEM_ARCH_ARM
#       if defined(_M_ARM_ARMV7VE)
            /*!
            * \def QSC_SYSTEM_ARCH_ARMV7VE
            * \brief Defined when building for ARM V7VE.
            */
#			define QSC_SYSTEM_ARCH_ARMV7VE
#       elif defined(_M_ARM_FP)
            /*!
            * \def QSC_SYSTEM_ARCH_ARMFP
            * \brief Defined when building for ARM with floating point support.
            */
#			define QSC_SYSTEM_ARCH_ARMFP
#       elif defined(_M_ARM64)
            /*!
            * \def QSC_SYSTEM_ARCH_ARM64
            * \brief Defined when building for ARM64.
            */
#			define QSC_SYSTEM_ARCH_ARM64
#       endif
#   elif defined(_M_IA64)
        /*!
        * \def QSC_SYSTEM_ARCH_IA64
        * \brief Defined when building for Itanium (IA-64).
        */
#		define QSC_SYSTEM_ARCH_IA64
#   endif
#elif defined(QSC_SYSTEM_COMPILER_GCC)
#   if defined(__amd64__) || defined(__amd64) || defined(__x86_64__) || defined(__x86_64)
        /*!
        * \def QSC_SYSTEM_ARCH_IX86_64
        * \brief Defined when building for 64-bit x86 (AMD64/Intel 64) using GCC.
        */
#		define QSC_SYSTEM_ARCH_IX86_64
        /*!
        * \def QSC_SYSTEM_ARCH_IX86
        * \brief Also defined for x86 architectures.
        */
#		define QSC_SYSTEM_ARCH_IX86
#       if defined(__amd64__) || defined(__amd64)
            /*!
            * \def QSC_SYSTEM_ARCH_AMD64
            * \brief Defined when the processor is AMD64.
            */
#			define QSC_SYSTEM_ARCH_AMD64
#       endif
#   elif defined(i386) || defined(__i386) || defined(__i386__)
        /*!
        * \def QSC_SYSTEM_ARCH_IX86_32
        * \brief Defined when building for 32-bit x86 using GCC.
        */
#		define QSC_SYSTEM_ARCH_IX86_32
        /*!
        * \def QSC_SYSTEM_ARCH_IX86
        * \brief Also defined for x86 architectures.
        */
#		define QSC_SYSTEM_ARCH_IX86
#   elif defined(__arm__) || defined(__aarch64__)
        /*!
        * \def QSC_SYSTEM_ARCH_ARM
        * \brief Defined when building for ARM architectures using GCC.
        */
#		define QSC_SYSTEM_ARCH_ARM
#       if defined(__aarch64__)
            /*!
            * \def QSC_SYSTEM_ARCH_ARM64
            * \brief Defined when building for ARM64.
            */
#			define QSC_SYSTEM_ARCH_ARM64
#       endif
#   elif defined(__ia64) || defined(__ia64__) || defined(__itanium__)
        /*!
        * \def QSC_SYSTEM_ARCH_IA64
        * \brief Defined when building for Itanium (IA-64) using GCC.
        */
#		define QSC_SYSTEM_ARCH_IA64
#   elif defined(__powerpc64__) || defined(__ppc64__) || defined(__PPC64__) || defined(__64BIT__) || defined(_LP64) || defined(__LP64__)
        /*!
        * \def QSC_SYSTEM_ARCH_PPC
        * \brief Defined when building for PowerPC 64-bit.
        */
#		define QSC_SYSTEM_ARCH_PPC
#   elif defined(__sparc) || defined(__sparc__)
        /*!
        * \def QSC_SYSTEM_ARCH_SPARC
        * \brief Defined when building for SPARC architectures.
        */
#		define QSC_SYSTEM_ARCH_SPARC
#       if defined(__sparc64__)
            /*!
            * \def QSC_SYSTEM_ARCH_SPARC64
            * \brief Defined when building for 64-bit SPARC.
            */
#			define QSC_SYSTEM_ARCH_SPARC64
#       endif
#   endif
#endif

#if (defined(__x86_64__) || defined(_M_X64))
#   define QSC_SYSTEM_X86
#endif

/*==============================================================================
    Sockets and Other System Macros
==============================================================================*/

/*!
 * \def QSC_PRAGMA_STR
 * \brief The stringify function.
 */
#define QSC_PRAGMA_STR(x) _Pragma(#x)

/*!
 * \def QSC_NO_INLINE
 * \brief Tells the compiler not to inline a function.
 */
#if defined(_MSC_VER)
#   define QSC_NO_INLINE __declspec(noinline)
#elif defined(__GNUC__) || defined(__clang__)
#   define QSC_NO_INLINE __attribute__((noinline))
#else
#   define QSC_NO_INLINE
#endif

#if defined(_WIN64) || defined(_WIN32) || defined(__CYGWIN__)
    /*!
    * \def QSC_SYSTEM_SOCKETS_WINDOWS
    * \brief Defined when using Windows sockets.
    */
#	define QSC_SYSTEM_SOCKETS_WINDOWS
#else
    /*!
    * \def QSC_SYSTEM_SOCKETS_BERKELEY
    * \brief Defined when using Berkeley sockets.
    */
#	define QSC_SYSTEM_SOCKETS_BERKELEY
#endif

#if defined(__GNUC__) || defined(__clang__)
#   define QSC_ATTRIBUTE __attribute__
#else
#   define QSC_ATTRIBUTE(a)
#endif

#if defined(_DLL)
    /*!
    * \def QSC_DLL_API
    * \brief Defined when building as a DLL.
    */
#	define QSC_DLL_API
#endif

/*!
* \def QSC_EXPORT_API
* \brief API export macro for Microsoft compilers when importing from a DLL.
*/
#if defined(QSC_DLL_API)

#if defined(QSC_SYSTEM_COMPILER_MSC)
#   if defined(QSC_DLL_IMPORT)
#		define QSC_EXPORT_API __declspec(dllimport)
#   else
#	    define QSC_EXPORT_API __declspec(dllexport)
#   endif
#elif defined(QSC_SYSTEM_COMPILER_GCC)
#   if defined(QSC_DLL_IMPORT)
#		define QSC_EXPORT_API QSC_ATTRIBUTE((dllimport))
#   else
#		define QSC_EXPORT_API QSC_ATTRIBUTE((dllexport))
#   endif
#else
#   if defined(__SUNPRO_C)
#       if !defined(__GNU_C__)
#		    define QSC_EXPORT_API QSC_ATTRIBUTE (visibility(__global))
#       else
#			define QSC_EXPORT_API QSC_ATTRIBUTE __global
#       endif
#   elif defined(_MSC_VER)
#		define QSC_EXPORT_API extern __declspec(dllexport)
#   else
#		define QSC_EXPORT_API QSC_ATTRIBUTE ((visibility ("default")))
#   endif
#endif
#else
#	define QSC_EXPORT_API
#endif

/*!
* \def QSC_CACHE_ALIGNED
* \brief Defines cache-line alignment using GCC's QSC_ATTRIBUTE syntax.
*/
#if defined(__GNUC__)
#	define QSC_CACHE_ALIGNED QSC_ATTRIBUTE((aligned(64)))
#elif defined(_MSC_VER)
#	define QSC_CACHE_ALIGNED __declspec(align(64U))
#endif

#if defined(QSC_SYSTEM_ARCH_IX86_64) || defined(QSC_SYSTEM_ARCH_ARM64) || defined(QSC_SYSTEM_ARCH_IA64) || defined(QSC_SYSTEM_ARCH_AMD64) || defined(QSC_SYSTEM_ARCH_SPARC64)
    /*!
    * \def QSC_SYSTEM_IS_X64
    * \brief Defined when the target system is 64-bit.
    */
#	define QSC_SYSTEM_IS_X64
#else
    /*!
    * \def QSC_SYSTEM_IS_X86
    * \brief Defined when the target system is 32-bit.
    */
#	define QSC_SYSTEM_IS_X86
#endif

#if defined(QSC_SYSTEM_IS_X64)
    /*!
    * \def QSC_SIZE_MAX
    * \brief The maximum integer size for a 64-bit system.
    */
#	define QSC_SIZE_MAX UINT64_MAX
#else
    /*!
    * \def QSC_SIZE_MAX
    * \brief The maximum integer size for a 32-bit system.
    */
#	define QSC_SIZE_MAX UINT32_MAX
#endif

/*!
 * \def QSC_SYSTEM_IS_LITTLE_ENDIAN
 * \brief Defined if the system is little endian.
 */
#if !defined(__BIG_ENDIAN__)
#   if defined(__BYTE_ORDER__) && defined(__ORDER_LITTLE_ENDIAN__) && (__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__)
#       define QSC_SYSTEM_IS_LITTLE_ENDIAN 1U
#   elif defined(__BYTE_ORDER__) && defined(__ORDER_BIG_ENDIAN__) && (__BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
#       define QSC_SYSTEM_IS_LITTLE_ENDIAN 0U
#   elif defined(_WIN32) || defined(__LITTLE_ENDIAN__)
#       define QSC_SYSTEM_IS_LITTLE_ENDIAN 1U
#   elif defined(__LITTLE_ENDIAN__) || defined(__ARMEL__) || defined(__AARCH64EL__) || defined(__i386__) || defined(__x86_64__) || defined(_M_IX86) || defined(_M_X64)
#   define QSC_SYSTEM_IS_LITTLE_ENDIAN 1U
#   endif
#endif

#if (!defined(QSC_SYSTEM_IS_LITTLE_ENDIAN))
#	if defined(__sparc) || defined(__sparc__) || defined(__hppa__) || defined(__PPC__) || defined(__mips__) || (defined(__MWERKS__) && !defined(__INTEL__))
        /*!
        * \def QSC_SYSTEM_IS_BIG_ENDIAN
        * \brief Defined if the system is big endian.
        */
#		define QSC_SYSTEM_IS_BIG_ENDIAN
#	else
        /*!
        * \def QSC_SYSTEM_IS_LITTLE_ENDIAN
        * \brief Defined if the system is little endian.
        */
#		define QSC_SYSTEM_IS_LITTLE_ENDIAN
#	endif
#endif

/*!
 * \def QSC_SYSTEM_MAX_NAME
 * \brief The maximum system name length supported by the system.
 */
#define QSC_SYSTEM_MAX_NAME 260ULL

/*!
 * \def QSC_SYSTEM_MAX_PATH
 * \brief The maximum path length supported by the system.
 */
#define QSC_SYSTEM_MAX_PATH 260ULL

/*!
 * \def QSC_SYSTEM_SECMEMALLOC_DEFAULT
 * \brief Default secure memory buffer allocation size (in bytes).
 */
#define QSC_SYSTEM_SECMEMALLOC_DEFAULT 4096ULL

/*!
 * \def QSC_SYSTEM_SECMEMALLOC_MIN
 * \brief Minimum secure memory allocation size (in bytes).
 */
#define QSC_SYSTEM_SECMEMALLOC_MIN 16ULL

/*!
 * \def QSC_SYSTEM_SECMEMALLOC_MAX
 * \brief Maximum secure memory allocation size (in bytes).
 */
#define QSC_SYSTEM_SECMEMALLOC_MAX 131072ULL

/*!
 * \def QSC_SYSTEM_SECMEMALLOC_MAXKB
 * \brief Maximum secure memory allocation in kilobytes.
 */
#define QSC_SYSTEM_SECMEMALLOC_MAXKB 512ULL

#if defined(_WIN32)
    /*!
    * \def QSC_SYSTEM_VIRTUAL_LOCK
    * \brief Defined if the system supports virtual memory locking on Windows.
    */
#	define QSC_SYSTEM_VIRTUAL_LOCK

    /*!
    * \def QSC_RTL_SECURE_MEMORY
    * \brief Defined if the system supports secure memory allocation on Windows.
    */
#	define QSC_RTL_SECURE_MEMORY
#endif

#if defined(QSC_SYSTEM_OS_LINUX) || defined(QSC_SYSTEM_OS_MAC) || defined(QSC_SYSTEM_OS_BSD)
    /*!
    * \def QSC_SYSTEM_POSIX_MLOCK
    * \brief Defined when the target platform provides the POSIX mlock and munlock functions.
    *
    * This definition is based on the resolved operating-system target instead of
    * _POSIX_MEMLOCK_RANGE so that secure-allocation page locking is not affected
    * by the order in which system headers are included before qsccommon.h.
    */
#	define QSC_SYSTEM_POSIX_MLOCK
#endif

#if defined(QSC_SYSTEM_VIRTUAL_LOCK) || defined(QSC_SYSTEM_POSIX_MLOCK)
    /*!
    * \def QSC_SYSTEM_SECURE_ALLOCATOR
    * \brief Defined if the system has a secure memory allocator.
    */
#	define QSC_SYSTEM_SECURE_ALLOCATOR
#endif

/*!
* \def QSC_SYSTEM_OPTIMIZE_IGNORE
* \brief Compiler hint to disable optimization in MSVC.
*/
#if defined(QSC_SYSTEM_COMPILER_MSC)
#	define QSC_SYSTEM_OPTIMIZE_IGNORE __pragma(optimize("", off))
#elif defined(QSC_SYSTEM_COMPILER_GCC) || defined(QSC_SYSTEM_COMPILER_MINGW)
#   if defined(__clang__)
#		define QSC_SYSTEM_OPTIMIZE_IGNORE QSC_ATTRIBUTE((optnone))
#   else
#		define QSC_SYSTEM_OPTIMIZE_IGNORE QSC_ATTRIBUTE((optimize("O0")))
#   endif
#elif defined(QSC_SYSTEM_COMPILER_INTEL)
#	define QSC_SYSTEM_OPTIMIZE_IGNORE _Pragma("optimize(\"\", off)")
#else
#	define QSC_SYSTEM_OPTIMIZE_IGNORE
#endif

/*!
* \def QSC_SYSTEM_OPTIMIZE_RESUME
* \brief Compiler hint to resume optimization in MSVC.
*/
#if defined(QSC_SYSTEM_COMPILER_MSC)
#	define QSC_SYSTEM_OPTIMIZE_RESUME __pragma(optimize("", on))
#elif defined(QSC_SYSTEM_COMPILER_GCC) || defined(QSC_SYSTEM_COMPILER_MINGW)
#   if defined(__clang__)
#		define QSC_SYSTEM_OPTIMIZE_RESUME
#   else
#		define QSC_SYSTEM_OPTIMIZE_RESUME
#   endif
#elif defined(QSC_SYSTEM_COMPILER_INTEL)
#	define QSC_SYSTEM_OPTIMIZE_RESUME _Pragma("optimize(\"\", on)")
#else
#	define QSC_SYSTEM_OPTIMIZE_RESUME
#endif

/*!
* \def QSC_SYSTEM_CONDITION_IGNORE(x)
* \brief A macro to disable a specific warning condition.
*/
#if defined(QSC_SYSTEM_COMPILER_MSC)
#	define QSC_SYSTEM_CONDITION_IGNORE(x) __pragma(warning(disable : x))
#elif defined(QSC_SYSTEM_COMPILER_GCC) || defined(QSC_SYSTEM_COMPILER_MINGW)
#	define QSC_SYSTEM_CONDITION_IGNORE(x)
#elif defined(QSC_SYSTEM_COMPILER_INTEL)
#	define QSC_SYSTEM_CONDITION_IGNORE(x)
#else
#	define QSC_SYSTEM_CONDITION_IGNORE(x)
#endif

/*!
* \def QSC_SYSTEM_CONDITION_RESUME(x)
* \brief A macro to re-enable a specific warning condition.
*/
#if defined(QSC_SYSTEM_COMPILER_MSC)
#	define QSC_SYSTEM_CONDITION_RESUME(x) __pragma(warning(default : x))
#elif defined(QSC_SYSTEM_COMPILER_GCC) || defined(QSC_SYSTEM_COMPILER_MINGW)
#	define QSC_SYSTEM_CONDITION_RESUME(x)
#elif defined(QSC_SYSTEM_COMPILER_INTEL)
#	define QSC_SYSTEM_CONDITION_RESUME(x)
#else
#	define QSC_SYSTEM_CONDITION_RESUME(x)
#endif

#if defined(_MSC_VER) && (_MSC_VER >= 1600)
    /*!
    * \def QSC_WMMINTRIN_H
    * \brief Defined when the CPU supports SIMD instructions (MSVC).
    */
#	define QSC_WMMINTRIN_H 1
#endif

#if defined(_MSC_VER) && (_MSC_VER >= 1700) && defined(_M_X64)
    /*!
    * \def QSC_HAVE_AVX2INTRIN_H
    * \brief Defined when the CPU supports AVX2 (MSVC, 64-bit).
    */
#	define QSC_HAVE_AVX2INTRIN_H 1
#endif

/*==============================================================================
    AVX512 Capabilities
==============================================================================*/

#if defined(QSC_SYSTEM_X86)

#   if defined(__AVX512F__) && (__AVX512F__ == 1)
        /*!
        * \def __AVX512__
        * \brief Defined when the system supports AVX512 instructions.
        */
#	    include <immintrin.h>
#	    if (!defined(__AVX512__))
#		    define __AVX512__
#	    endif
#   endif

#   if defined(__SSE2__)
        /*!
        * \def QSC_SYSTEM_HAS_SSE2
        * \brief Defined if the system supports SSE2 instructions.
        */
#	    define QSC_SYSTEM_HAS_SSE2
#   endif

#   if defined(__SSE3__)
        /*!
        * \def QSC_SYSTEM_HAS_SSE3
        * \brief Defined if the system supports SSE3 instructions.
        */
#	    define QSC_SYSTEM_HAS_SSE3
#   endif

#   if defined(__SSSE3__)
        /*!
        * \def QSC_SYSTEM_HAS_SSSE3
        * \brief Defined if the system supports SSSE3 instructions.
        */
#	    define QSC_SYSTEM_HAS_SSSE3
#   endif

#   if defined(__SSE4_1__)
        /*!
        * \def QSC_SYSTEM_HAS_SSE41
        * \brief Defined if the system supports SSE4.1 instructions.
        */
#	    define QSC_SYSTEM_HAS_SSE41
#   endif

#   if defined(__SSE4_2__)
        /*!
        * \def QSC_SYSTEM_HAS_SSE42
        * \brief Defined if the system supports SSE4.2 instructions.
        */
#	    define QSC_SYSTEM_HAS_SSE42
#   endif

#   if defined(__ARM_NEON) || defined(__ARM_NEON__)
        /*!
        * \def QSC_SYSTEM_HAS_ARM_NEON
        * \brief Defined if the system supports ARM NEON instructions.
        */
#       define QSC_SYSTEM_HAS_ARM_NEON
#   endif

        /*!
        * \def QSC_SYSTEM_HAS_ARM_SVE
        * \brief Defined if the system supports ARM SVE
        * ARMv8.2-A and later; GCC/Clang define __ARM_FEATURE_SVE
        */
#   if defined(__ARM_FEATURE_SVE)
#       define QSC_SYSTEM_HAS_ARM_SVE
#   endif

        /*!
        * \def QSC_SYSTEM_HAS_RVV
        * \brief Defined if the system supports RISC-V RVV 1.0
        * GCC/Clang define __riscv_vector when -march=rv64gcv
        */
#   if defined(__riscv_vector)
#       define QSC_SYSTEM_HAS_RVV
#   endif

#   if defined(__AVX__)
        /*!
        * \def QSC_SYSTEM_HAS_AVX
        * \brief Defined if the system supports AVX instructions.
        */
#	    define QSC_SYSTEM_HAS_AVX
#   endif

#   if defined(__AVX2__)
        /*!
        * \def QSC_SYSTEM_HAS_AVX2
        * \brief Defined if the system supports AVX2 instructions.
        */
#	    define QSC_SYSTEM_HAS_AVX2
#   endif

#   if defined(__AVX512__)
        /*!
        * \def QSC_SYSTEM_HAS_AVX512
        * \brief Defined if the system supports AVX512 instructions.
        */
#	    define QSC_SYSTEM_HAS_AVX512
#   endif

#   if defined(__XOP__)
        /*!
        * \def QSC_SYSTEM_HAS_XOP
        * \brief Defined if the system supports XOP instructions.
        */
#	    define QSC_SYSTEM_HAS_XOP
#endif

#   if defined(QSC_SYSTEM_HAS_AVX) || defined(QSC_SYSTEM_HAS_AVX2) || defined(QSC_SYSTEM_HAS_AVX512)
    /*!
    * \def QSC_SYSTEM_AVX_INTRINSICS
    * \brief Defined if the system supports AVX intrinsics.
    */
#	define QSC_SYSTEM_AVX_INTRINSICS
#   endif
#endif

/*==============================================================================
    Assembly and SIMD Alignment Macros
==============================================================================*/

/*!
* \def QSC_ASM_ENABLED
* \brief Global flag for enabling ASM compilation (user-modifiable).
*/
/*#define QSC_ASM_ENABLED */

/*!
* \def QSC_MISRA_FULL_COMPLIANCE
* \brief Enable full MISRA compliant cryptographic module compliance.
*/
//#define QSC_MISRA_FULL_COMPLIANCE

#if defined(QSC_SYSTEM_AVX_INTRINSICS) && defined(QSC_SYSTEM_COMPILER_GCC) && defined(QSC_ASM_ENABLED)
  // #define QSC_GCC_ASM_ENABLED  /* Uncomment to enable GCC ASM processing */
#endif

/*!
* \def QSC_ALIGN(x)
* \brief Macro for aligning data to 'x' bytes using GCC/Clang.
*/
#if !defined(QSC_ALIGN)
    /* If compiling in C23 or later, use the built-in 'alignas' keyword. */
    #if defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 202311L)
        #define QSC_ALIGN(x) alignas(x)
#	elif defined(_MSC_VER)
#		define QSC_ALIGN(x) __declspec(align(x))
#	elif defined(__GNUC__) || defined(__clang__)
#		define QSC_ALIGN(x) __attribute__((aligned(x)))
#	else
#		define QSC_ALIGN(x)
#	endif
#endif

    /*!
    * \def QSC_SIMD_ALIGNMENT
    * \brief Alignment value for enabled intrinsic.
    */
#if defined(QSC_SYSTEM_HAS_AVX512)
#  define QSC_SIMD_ALIGNMENT 64
#elif defined(QSC_SYSTEM_HAS_AVX2)
#  define QSC_SIMD_ALIGNMENT 32
#elif defined(QSC_SYSTEM_HAS_AVX)
#  define QSC_SIMD_ALIGNMENT 16
#else
#  define QSC_SIMD_ALIGNMENT 8
#endif

    /*!
    * \def QSC_SIMD_ALIGN
    * \brief Macro to align data on supported intrinsics size
    */
#if defined(_MSC_VER)
#  define QSC_SIMD_ALIGN __declspec(align(QSC_SIMD_ALIGNMENT))
#elif defined(__GNUC__) || defined(__clang__)
#  define QSC_SIMD_ALIGN _Alignas(QSC_SIMD_ALIGNMENT)
#else
#  define QSC_SIMD_ALIGN
#endif

#if defined(QSC_SYSTEM_AVX_INTRINSICS)
    /*!
    * \def QSC_RDRAND_COMPATIBLE
    * \brief Defined if the CPU is RDRAND compatible.
    */
#	define QSC_RDRAND_COMPATIBLE
#endif

/*!
 * \def QSC_STATUS_SUCCESS
 * \brief Function return value indicating successful operation.
 */
#define QSC_STATUS_SUCCESS 0LL

/*!
 * \def QSC_STATUS_FAILURE
 * \brief Function return value indicating failed operation.
 */
#define QSC_STATUS_FAILURE -1LL

/*==============================================================================
    User Modifiable Values and Cryptographic Parameter Sets
==============================================================================*/

#if !defined(QSC_SYSTEM_AESNI_ENABLED)
#	if defined(QSC_SYSTEM_AVX_INTRINSICS)
        /*!
        * \def QSC_SYSTEM_AESNI_ENABLED
        * \brief Enable the use of intrinsics and the AES-NI implementation.
        */
#		define QSC_SYSTEM_AESNI_ENABLED
#	endif
#endif

/*!
 * \def QSC_SHA2_SHANI_ENABLED
 * \brief Enables the x86 SHA-NI SHA-256 compression path.
 *
 * \details
 * The SHA-NI implementation in sha2.c uses the Intel SHA extensions together
 * with SSSE3/SSE4.1 helper instructions such as _mm_shuffle_epi8,
 * _mm_alignr_epi8, and _mm_blend_epi16. Therefore SHA-NI must not be enabled
 * solely because the compiler defines __SHA__; a build such as -msha -msse2
 * exposes the SHA feature macro but cannot compile the helper intrinsics.
 *
 * GCC and Clang define __SHA__, __SSSE3__, and __SSE4_1__ when the required
 * instruction families are enabled explicitly, for example:
 * -msha -mssse3 -msse4.1. The MSVC compatibility branch retains the existing
 * QSC AVX-intrinsics umbrella for that toolchain.
 */
#if defined(QSC_SYSTEM_ARCH_IX86)
#	if ((defined(__SHA__) || defined(__SHA256__)) && defined(__SSSE3__) && defined(__SSE4_1__)) || \
		(defined(__ISA_AVAILABLE_SHA) && defined(QSC_SYSTEM_AVX_INTRINSICS))
#		define QSC_SHA2_SHANI_ENABLED
#	endif
#endif

///*!
// * \def QSC_KECCAK_UNROLLED_PERMUTATION
// * \brief Define to use the unrolled form of the Keccak permutation function.
// */
//#define QSC_KECCAK_UNROLLED_PERMUTATION

/*!
 * \def QSC_TLS_SECURITY_CLASS_1
 * \brief Selects the QSC TLS Security Class 1 build profile.
 *
 * \details
 * This profile enables the lowest predefined TLS-oriented parameter-set bundle
 * in QSC. When this macro is defined, the header enables the following
 * primitive parameter sets:
 * - QSC_ECDH_S1P256
 * - QSC_EDDH_S1EC25519
 * - QSC_KYBER_S1K2P512
 * - QSC_DILITHIUM_S1P44
 * - QSC_ECDSA_S1P256
 * - QSC_EDDSA_S1EC25519
 *
 * This profile is intended for compact builds that expose the 128-bit-class
 * parameter selections associated with X25519, Ed25519, NIST P-256, ML-KEM-512,
 * and ML-DSA-44.
 *
 * Only one QSC_TLS_SECURITY_CLASS_X macro should be defined in a build.
 */
#if !defined(QSC_TLS_NO_DEFAULT_SECURITY_CLASS) && !defined(QSC_TLS_SECURITY_CLASS_1) && !defined(QSC_TLS_SECURITY_CLASS_3) && !defined(QSC_TLS_SECURITY_CLASS_5)
#   define QSC_TLS_SECURITY_CLASS_1
#endif

/*!
 * \def QSC_TLS_SECURITY_CLASS_3
 * \brief Selects the QSC TLS Security Class 3 build profile.
 *
 * \details
 * This profile enables the middle predefined TLS-oriented parameter-set bundle
 * in QSC. When this macro is defined, the header enables the following
 * primitive parameter sets:
 * - QSC_ECDH_S3P384
 * - QSC_EDDH_S3EC448
 * - QSC_KYBER_S3K3P768
 * - QSC_DILITHIUM_S3P65
 * - QSC_ECDSA_S3P384
 * - QSC_EDDSA_S3EC448
 *
 * This profile is intended for builds that expose the higher-strength parameter
 * selections associated with X448, Ed448, NIST P-384, ML-KEM-768, and
 * ML-DSA-65.
 *
 * Only one QSC_TLS_SECURITY_CLASS_X macro should be defined in a build.
 */
//#define QSC_TLS_SECURITY_CLASS_3

 /*!
  * \def QSC_TLS_SECURITY_CLASS_5
  * \brief Selects the QSC TLS Security Class 5 build profile.
  *
  * \details
  * This profile enables the highest predefined TLS-oriented parameter-set bundle
  * currently defined in this header. When this macro is defined, the header
  * enables the following primitive parameter sets:
  * - QSC_ECDH_S5P521
  * - QSC_EDDH_S3EC448
  * - QSC_KYBER_S5K4P1024
  * - QSC_DILITHIUM_S5P87
  * - QSC_ECDSA_S5P521
  * - QSC_EDDSA_S3EC448
  *
  * This profile exposes both the NIST P-521 classical path and the Edwards
  * X448/Ed448 classical path alongside the highest predefined PQ parameter sets.
  * The Edwards-family options are intentionally enabled in both the Security
  * Class 3 and Security Class 5 TLS build profiles so that each higher-strength
  * profile retains an Edwards-curve option.
  *
  * Implementations using this profile shall derive TLS and X.509 capability
  * strictly from the resulting enabled primitive macros rather than from the
  * security-class name alone.
  *
  * Only one QSC_TLS_SECURITY_CLASS_X macro should be defined in a build.
  */
//#define QSC_TLS_SECURITY_CLASS_5

#if defined(QSC_TLS_SECURITY_CLASS_1)

   /*!
    * \def QSC_EDDH_S1EC25519
    * \brief Enable the EDDH S1EC25519 parameter set.
    */
#   define QSC_EDDH_S1EC25519

    /*!
    * \def QSC_KYBER_S3K3P768
    * \brief Enable the Kyber S3K3P768 parameter set.
    */
#   define QSC_KYBER_S3K3P768

    /*!
    * \def QSC_DILITHIUM_S3P65
    * \brief Enable the Dilithium S3P65 parameter set.
    */
#   define QSC_DILITHIUM_S3P65

   /*!
    * \def QSC_ECDSA_S1P256
    * \brief Enable the ECDSA S1EC256 (NIST P-256) parameter set.
    */
#   define QSC_ECDSA_S1P256

   /*!
    * \def QSC_EDDSA_S1EC25519
    * \brief Enable the EDDSA S1EC25519 parameter set.
    */
#   define QSC_EDDSA_S1EC25519

#elif defined(QSC_TLS_SECURITY_CLASS_3)

   /*!
    * \def QSC_EDDH_S1EC25519
    * \brief Enable the EDDH S1EC25519 parameter set.
    */
#   define QSC_EDDH_S1EC25519

    /*!
    * \def QSC_KYBER_S3K3P768
    * \brief Enable the Kyber S3K3P768 parameter set.
    */
#   define QSC_KYBER_S3K3P768

    /*!
    * \def QSC_DILITHIUM_S3P65
    * \brief Enable the Dilithium S3P65 parameter set.
    */
#   define QSC_DILITHIUM_S3P65

    /*!
     * \def QSC_ECDSA_S1P256
     * \brief Enable the ECDSA S1EC256 (NIST P-256) parameter set.
     */
#   define QSC_ECDSA_S1P256

     /*!
      * \def QSC_EDDSA_S1EC25519
      * \brief Enable the EDDSA S1EC25519 parameter set.
      */
#   define QSC_EDDSA_S1EC25519

#elif defined(QSC_TLS_SECURITY_CLASS_5)

   /*!
    * \def QSC_KYBER_S5K4P1024
    * \brief Enable the Kyber S5K4P1024 parameter set.
    */
#   define QSC_KYBER_S5K4P1024

   /*!
    * \def QSC_DILITHIUM_S5P87
    * \brief Enable the Dilithium S5P87 parameter set.
    */
#   define QSC_DILITHIUM_S5P87

#endif

/*** Asymmetric Ciphers ***/

/*** ECDH ***/

#if !defined(QSC_ECDH_S1P256) && !defined(QSC_ECDH_S3P384) && !defined(QSC_ECDH_S5P521)
/*!
 * \def QSC_ECDH_S1P256
 * \brief Enable the ECDH S1P256 parameter set (NIST P-256 / secp256r1).
 */
#define QSC_ECDH_S1P256
#endif

#if !defined(QSC_ECDH_S1P256) && !defined(QSC_ECDH_S3P384) && !defined(QSC_ECDH_S5P521)
 /*!
  * \def QSC_ECDH_S3P384
  * \brief Enable the ECDH S3P384 parameter set (NIST P-384 / secp384r1).
  */
#define QSC_ECDH_S3P384
#endif

#if !defined(QSC_ECDH_S1P256) && !defined(QSC_ECDH_S3P384) && !defined(QSC_ECDH_S5P521)
/*!
 * \def QSC_ECDH_S5P521
 * \brief Enable the ECDH S5P521 parameter set (NIST P-521 / secp521r1).
 */
#define QSC_ECDH_S5P521
#endif

/*** EDDH ***/

#if !defined(QSC_EDDH_S1EC25519) && !defined(QSC_EDDH_S3EC448)
/*!
 * \def QSC_EDDH_S1EC25519
 * \brief Enable the EDDH S1EC25519 parameter set.
 */
#define QSC_EDDH_S1EC25519
#endif

#if !defined(QSC_EDDH_S1EC25519) && !defined(QSC_EDDH_S3EC448)
/*!
 * \def QSC_EDDH_S3EC448
 * \brief Enable the EDDH S3EC448 parameter set.
 */
#define QSC_EDDH_S3EC448
#endif

/*** ML-KEM Kyber ***/

#if !defined(QSC_KYBER_S1K2P512) && !defined(QSC_KYBER_S3K3P768) && !defined(QSC_KYBER_S5K4P1024) && !defined(QSC_KYBER_S6K5P1280)
/*!
 * \def QSC_KYBER_S1K2P512
 * \brief Enable the Kyber S1K2P512 parameter set.
 */
#define QSC_KYBER_S1K2P512
#endif

#if !defined(QSC_KYBER_S1K2P512) && !defined(QSC_KYBER_S3K3P768) && !defined(QSC_KYBER_S5K4P1024) && !defined(QSC_KYBER_S6K5P1280)
/*!
 * \def QSC_KYBER_S3K3P768
 * \brief Enable the Kyber S3K3P768 parameter set.
 */
#define QSC_KYBER_S3K3P768
#endif

#if !defined(QSC_KYBER_S1K2P512) && !defined(QSC_KYBER_S3K3P768) && !defined(QSC_KYBER_S5K4P1024) && !defined(QSC_KYBER_S6K5P1280)
/*!
 * \def QSC_KYBER_S5K4P1024
 * \brief Enable the Kyber S5K4P1024 parameter set.
 */
#define QSC_KYBER_S5K4P1024
#endif

#if !defined(QSC_KYBER_S1K2P512) && !defined(QSC_KYBER_S3K3P768) && !defined(QSC_KYBER_S5K4P1024)
/*!
 * \def QSC_KYBER_S6K5P1280
 * \brief Enable the Kyber S6K5P1280 parameter set (experimental).
 */
#define QSC_KYBER_S6K5P1280
#endif

/*** HQC ***/

#if !defined(QSC_HQC_S3N4602) && !defined(QSC_HQC_S5N7333)
/*!
 * \def QSC_HQC_S1N2321
 * \brief Enable the HQC S1N17669 parameter set.
 */
#define QSC_HQC_S1N2321
#endif

#if !defined(QSC_HQC_S1N2321) && !defined(QSC_HQC_S5N7333)
/*!
 * \def QSC_HQC_S3N4602
 * \brief Enable the HQCS3N35851 parameter set.
 */
#define QSC_HQC_S3N4602
#endif

#if !defined(QSC_HQC_S1N2321) && !defined(QSC_HQC_S3N4602)
/*!
 * \def QSC_HQC_S5N7333
 * \brief Enable the HQC S5N57637 parameter set.
 */
#define QSC_HQC_S5N7333
#endif

/*** McEliece ***/

#if !defined(QSC_MCELIECE_S3N4608T96) && !defined(QSC_MCELIECE_S5N6688T128) && !defined(QSC_MCELIECE_S6N6960T119) && !defined(QSC_MCELIECE_S7N8192T128)
/*!
 * \def QSC_MCELIECE_S1N3488T64
 * \brief Enable the McEliece S1-N3488T64 parameter set.
 */
#define QSC_MCELIECE_S1N3488T64
#endif

#if !defined(QSC_MCELIECE_S1N3488T64) && !defined(QSC_MCELIECE_S5N6688T128) && !defined(QSC_MCELIECE_S6N6960T119) && !defined(QSC_MCELIECE_S7N8192T128)
/*!
 * \def QSC_MCELIECE_S3N4608T96
 * \brief Enable the McEliece S3-N4608T96 parameter set.
 */
#define QSC_MCELIECE_S3N4608T96
#endif

#if !defined(QSC_MCELIECE_S1N3488T64) && !defined(QSC_MCELIECE_S3N4608T96) && !defined(QSC_MCELIECE_S6N6960T119) && !defined(QSC_MCELIECE_S7N8192T128)
/*!
 * \def QSC_MCELIECE_S5N6688T128
 * \brief Enable the McEliece S5-N6688T128 parameter set.
 */
#define QSC_MCELIECE_S5N6688T128
#endif

#if !defined(QSC_MCELIECE_S1N3488T64) && !defined(QSC_MCELIECE_S3N4608T96) && !defined(QSC_MCELIECE_S5N6688T128) && !defined(QSC_MCELIECE_S7N8192T128)
/*!
 * \def QSC_MCELIECE_S6N6960T119
 * \brief Enable the McEliece S6-N6960T119 parameter set.
 */
#define QSC_MCELIECE_S6N6960T119
#endif

#if !defined(QSC_MCELIECE_S1N3488T64) && !defined(QSC_MCELIECE_S3N4608T96) && !defined(QSC_MCELIECE_S5N6688T128) && !defined(QSC_MCELIECE_S6N6960T119)
/*!
 * \def QSC_MCELIECE_S7N8192T128
 * \brief Enable the McEliece S7-N8192T128 parameter set.
 */
#define QSC_MCELIECE_S7N8192T128
#endif

/*** Signature Schemes ***/

#if !defined(QSC_DILITHIUM_S1P44) && !defined(QSC_DILITHIUM_S3P65) && !defined(QSC_DILITHIUM_S5P87)
/*!
 * \def QSC_DILITHIUM_S1P44
 * \brief Enable the Dilithium S1P44 parameter set.
 */
#define QSC_DILITHIUM_S1P44
#endif

#if !defined(QSC_DILITHIUM_S1P44) && !defined(QSC_DILITHIUM_S3P65) && !defined(QSC_DILITHIUM_S5P87)
/*!
 * \def QSC_DILITHIUM_S3P65
 * \brief Enable the Dilithium S3P65 parameter set.
 */
#define QSC_DILITHIUM_S3P65
#endif

#if !defined(QSC_DILITHIUM_S1P44) && !defined(QSC_DILITHIUM_S3P65) && !defined(QSC_DILITHIUM_S5P87)
/*!
 * \def QSC_DILITHIUM_S5P87
 * \brief Enable the Dilithium S5P87 parameter set.
 */
#define QSC_DILITHIUM_S5P87
#endif

 /*** ECDSA ***/

#if !defined(QSC_ECDSA_S1P256) && !defined(QSC_ECDSA_S3P384) && !defined(QSC_ECDSA_S5P521)
/*!
 * \def QSC_ECDSA_S1P256
 * \brief Enable the ECDSA S1EC256 (NIST P-256) parameter set.
 */
#define QSC_ECDSA_S1P256
#endif

#if !defined(QSC_ECDSA_S1P256) && !defined(QSC_ECDSA_S3P384) && !defined(QSC_ECDSA_S5P521)
/*!
 * \def QSC_ECDSA_S3P384
 * \brief Enable the ECDSA S1P384 (NIST P-384) parameter set.
 */
#define QSC_ECDSA_S3P384
#endif

#if !defined(QSC_ECDSA_S1P256) && !defined(QSC_ECDSA_S3P384) && !defined(QSC_ECDSA_S5P521)
/*!
 * \def QSC_ECDSA_S5P521
 * \brief Enable the ECDSA S1P521 (NIST P-521) parameter set.
 */
#define QSC_ECDSA_S5P521
#endif

/*** EDDSA ***/

#if !defined(QSC_EDDSA_S1EC25519) && !defined(QSC_EDDSA_S3EC448)
/*!
 * \def QSC_EDDSA_S1EC25519
 * \brief Enable the EDDSA S1EC25519 parameter set.
 */
#define QSC_EDDSA_S1EC25519
#endif

#if !defined(QSC_EDDSA_S1EC25519) && !defined(QSC_EDDSA_S3EC448)
/*!
 * \def QSC_EDDSA_S3EC448
 * \brief Enable the EDDSA S3EC448 parameter set.
 */
#define QSC_EDDSA_S3EC448
#endif

 /*** Falcon ***/

#if !defined(QSC_FALCON_S5SHAKE256F1024)
/*!
 * \def QSC_FALCON_S3SHAKE256F512
 * \brief Enable the Falcon S3SHAKE256F512 parameter set.
 */
#define QSC_FALCON_S3SHAKE256F512
#endif

#if !defined(QSC_FALCON_S3SHAKE256F512)
/*!
 * \def QSC_FALCON_S5SHAKE256F1024
 * \brief Enable the Falcon S5SHAKE256F1024 parameter set.
 */
#define QSC_FALCON_S5SHAKE256F1024
#endif

/*** SphincsPlus ***/

#if !defined(QSC_SPHINCSPLUS_S3S192SHAKERS) && !defined(QSC_SPHINCSPLUS_S5S256SHAKERS) && !defined(QSC_SPHINCSPLUS_S6S512SHAKERS)
/*!
 * \def QSC_SPHINCSPLUS_S1S128SHAKERS
 * \brief Enable the SphincsPlus S1S128SHAKERS robust small parameter set.
 */
#define QSC_SPHINCSPLUS_S1S128SHAKERS
#endif

#if !defined(QSC_SPHINCSPLUS_S1S128SHAKERS) && !defined(QSC_SPHINCSPLUS_S5S256SHAKERS) && !defined(QSC_SPHINCSPLUS_S6S512SHAKERS)
/*!
 * \def QSC_SPHINCSPLUS_S3S192SHAKERS
 * \brief Enable the SphincsPlus S3S192SHAKERS robust small parameter set.
 */
#define QSC_SPHINCSPLUS_S3S192SHAKERS
#endif

#if !defined(QSC_SPHINCSPLUS_S1S128SHAKERS) && !defined(QSC_SPHINCSPLUS_S3S192SHAKERS) && !defined(QSC_SPHINCSPLUS_S6S512SHAKERS)
/*!
 * \def QSC_SPHINCSPLUS_S5S256SHAKERS
 * \brief Enable the SphincsPlus S5S256SHAKERS robust small parameter set.
 */
#define QSC_SPHINCSPLUS_S5S256SHAKERS
#endif

#if !defined(QSC_SPHINCSPLUS_S1S128SHAKERS) && !defined(QSC_SPHINCSPLUS_S3S192SHAKERS) && !defined(QSC_SPHINCSPLUS_S5S256SHAKERS)
/*!
 * \def QSC_SPHINCSPLUS_S6S512SHAKERS
 * \brief Enable the SphincsPlus S6S512SHAKERS robust small parameter set.
 */
#define QSC_SPHINCSPLUS_S6S512SHAKERS
#endif

QSC_CPLUSPLUS_ENABLED_END

#endif
