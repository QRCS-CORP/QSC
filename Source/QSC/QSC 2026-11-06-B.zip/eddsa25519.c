/* 2020-2026 Quantum Resistant Cryptographic Solutions Corporation
 * All Rights Reserved.
 *
 * NOTICE:
 * This software and all accompanying materials are the exclusive property of
 * Quantum Resistant Cryptographic Solutions Corporation (QRCS). The intellectual
 * and technical concepts contained herein are proprietary to QRCS and are
 * protected under applicable Canadian, U.S., and international copyright,
 * patent, and trade secret laws.
 *
 * CRYPTOGRAPHIC ALGORITHMS AND IMPLEMENTATIONS:
 * - This software includes implementations of cryptographic primitives and
 *   algorithms that are standardized or in the public domain, such as AES
 *   and SHA-3, which are not proprietary to QRCS.
 * - This software also includes cryptographic primitives, constructions, and
 *   algorithms designed by QRCS, including but not limited to RCS, SCB, CSX, QMAC, and
 *   related components, which are proprietary to QRCS.
 * - All source code, implementations, protocol compositions, optimizations,
 *   parameter selections, and engineering work contained in this software are
 *   original works of QRCS and are protected under this license.
 *
 * LICENSE AND USE RESTRICTIONS:
 * - This software is licensed under the Quantum Resistant Cryptographic Solutions
 *   Public Research and Evaluation License (QRCS-PREL), 2025-2026.
 * - Permission is granted solely for non-commercial evaluation, academic research,
 *   cryptographic analysis, interoperability testing, and feasibility assessment.
 * - Commercial use, production deployment, commercial redistribution, or
 *   integration into products or services is strictly prohibited without a
 *   separate written license agreement executed with QRCS.
 * - Licensing and authorized distribution are solely at the discretion of QRCS.
 *
 * EXPERIMENTAL CRYPTOGRAPHY NOTICE:
 * Portions of this software may include experimental, novel, or evolving
 * cryptographic designs. Use of this software is entirely at the user's risk.
 *
 * DISCLAIMER:
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, SECURITY, OR NON-INFRINGEMENT. QRCS DISCLAIMS ALL
 * LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING FROM THE USE OR MISUSE OF THIS SOFTWARE.
 *
 * FULL LICENSE:
 * This software is subject to the Quantum Resistant Cryptographic Solutions
 * Public Research and Evaluation License (QRCS-PREL), 2025-2026. The complete license terms
 * are provided in the accompanying LICENSE file or at https://www.qrcscorp.ca.
 *
 * Written by: John G. Underhill
 * Contact: contact@qrcscorp.ca
 */

#include "eddsa25519.h"
#include "csp.h"
#include "ed25519.h"
#include "intutils.h"
#include "memutils.h"
#include "sha2.h"

static int32_t eddsa_ed25519_sign(uint8_t* sm, size_t* smlen, const uint8_t* m, size_t mlen, const uint8_t* sk)
{
	uint8_t az[64U] = { 0U };
	uint8_t nonce[64U] = { 0U };
	uint8_t hram[64U] = { 0U };
	qsc_sha512_state ctx;
	qsc_ge25519_p3 R;

	/* hash 1st half of sk to az */
	qsc_sha512_compute(az, sk, 32U);

	qsc_sha512_initialize(&ctx);
	/* update with 2nd half of az */
	qsc_sha512_update(&ctx, az + 32U, 32U);
	/* update hash with m */
	qsc_sha512_update(&ctx, m, mlen);
	/* finalize to nonce */
	qsc_sha512_finalize(&ctx, nonce);

	/* move 2nd half of sk to 2nd half of sig */
	qsc_memutils_copy(sm + 32U, sk + 32U, 32U);
	/* reduce nonce */
	qsc_sc25519_reduce(nonce);
	/* scalar on nonce */
	qsc_ge25519_scalarmult_base(&R, nonce);
	/* scalar to 1st half of sig */
	qsc_ge25519_p3_to_bytes(sm, &R);

	qsc_sha512_initialize(&ctx);
	/* update hash with sig */
	qsc_sha512_update(&ctx, sm, 64);
	/* update hash with message */
	qsc_sha512_update(&ctx, m, mlen);
	/* finalize to hram */
	qsc_sha512_finalize(&ctx, hram);
	/* reduce hram */
	qsc_sc25519_reduce(hram);
	/* clamp az */
	qsc_sc25519_clamp(az);
	/* muladd hram, az, nonce to 2nd half of sig */
	qsc_sc25519_muladd(sm + 32, hram, az, nonce);
	/* cleanup */
	qsc_memutils_secure_erase(az, sizeof(az));
	qsc_memutils_secure_erase(nonce, sizeof(nonce));

	if (smlen != NULL)
	{
		*smlen = 64U;
	}

	return 0;
}

static bool eddsa_ed25519_verify(const uint8_t* sig, const uint8_t* m, size_t mlen, const uint8_t* pk)
{
	qsc_sha512_state ctx;
	uint8_t h[64U] = { 0U };
	uint8_t rcheck[32U] = { 0U };
	qsc_ge25519_p3 A;
	qsc_ge25519_p2 R;
	bool res;

	if ((sig[63U] & 240) && qsc_sc25519_is_canonical(sig + 32U) == 0)
	{
		res = false;
	}
	else if (qsc_ge25519_has_small_order(sig) != 0) 
	{
		res = false;
	}
	else if (qsc_ge25519_is_canonical(pk) == 0 || qsc_ge25519_has_small_order(pk) != 0)
	{
		res = false;
	}
	else if (qsc_ge25519_from_bytes_negate_vartime(&A, pk) != 0)
	{
		res = false;
	}
	else
	{
		res = true;
	}

	if (res == true)
	{
		qsc_sha512_initialize(&ctx);
		qsc_sha512_update(&ctx, sig, 32U);
		qsc_sha512_update(&ctx, pk, 32U);
		qsc_sha512_update(&ctx, m, mlen);
		qsc_sha512_finalize(&ctx, h);
		qsc_sc25519_reduce(h);

		qsc_ge25519_double_scalarmult_vartime(&R, h, &A, sig + 32U);
		qsc_ge25519_to_bytes(rcheck, &R);

		if (qsc_sc25519_verify(rcheck, sig, 32U) || qsc_memutils_are_equal(sig, rcheck, 32U) == false)
		{
			res = false;
		}
	}

	return res;
}

/* public api */

void qsc_ed25519_generate_keypair(uint8_t* publickey, uint8_t* privatekey, bool (*rng_generate)(uint8_t*, size_t))
{
	QSC_ASSERT(publickey != NULL);
	QSC_ASSERT(privatekey != NULL);
	QSC_ASSERT(rng_generate != NULL);

	qsc_ge25519_p3 A = { 0 };
	uint8_t seed[ED25519_SEED_SIZE] = { 0U };

	if (rng_generate(seed, ED25519_SEED_SIZE) == true)
	{
		qsc_sha512_compute(privatekey, seed, ED25519_SEED_SIZE);
		qsc_sc25519_clamp(privatekey);

		qsc_ge25519_scalarmult_base(&A, privatekey);
		qsc_ge25519_p3_to_bytes(publickey, &A);

		qsc_memutils_copy(privatekey, seed, ED25519_SEED_SIZE);
		qsc_memutils_copy(privatekey + ED25519_SEED_SIZE, publickey, ED25519_PUBLICKEY_SIZE);
		qsc_memutils_secure_erase(seed, sizeof(seed));
	}
	else
	{
		qsc_memutils_secure_erase(publickey, ED25519_PUBLICKEY_SIZE);
		qsc_memutils_secure_erase(privatekey, ED25519_PRIVATEKEY_SIZE);
	}
}

void qsc_ed25519_generate_seeded_keypair(uint8_t* publickey, uint8_t* privatekey, const uint8_t* seed)
{
	QSC_ASSERT(publickey != NULL);
	QSC_ASSERT(privatekey != NULL);
	QSC_ASSERT(seed != NULL);

	qsc_ge25519_p3 A = { 0 };

	qsc_sha512_compute(privatekey, seed, ED25519_SEED_SIZE);
	qsc_sc25519_clamp(privatekey);

	qsc_ge25519_scalarmult_base(&A, privatekey);
	qsc_ge25519_p3_to_bytes(publickey, &A);

	qsc_memutils_copy(privatekey, seed, ED25519_SEED_SIZE);
	qsc_memutils_copy(privatekey + ED25519_SEED_SIZE, publickey, ED25519_PUBLICKEY_SIZE);
}

bool qsc_ed25519_sign(uint8_t* signedmsg, size_t* smsglen, const uint8_t* message, size_t msglen, const uint8_t* privatekey)
{
	QSC_ASSERT(signedmsg != NULL);
	QSC_ASSERT(smsglen != NULL);
	QSC_ASSERT(message != NULL);
	QSC_ASSERT(privatekey != NULL);

	size_t slen;
	bool res;

	res = false;

	qsc_memutils_copy(signedmsg + ED25519_SIGNATURE_SIZE, message, msglen);

	if (eddsa_ed25519_sign(signedmsg, &slen, signedmsg + ED25519_SIGNATURE_SIZE, msglen, privatekey) != 0 || slen != ED25519_SIGNATURE_SIZE)
	{
		if (smsglen != NULL)
		{
			*smsglen = 0;
		}

		qsc_memutils_secure_erase(signedmsg, msglen + ED25519_SIGNATURE_SIZE);
	}
	else
	{
		if (smsglen != NULL)
		{
			*smsglen = msglen + slen;
		}

		res = true;
	}

	return res;
}

bool qsc_ed25519_verify(uint8_t* message, size_t* msglen, const uint8_t* signedmsg, size_t smsglen, const uint8_t* publickey)
{
	QSC_ASSERT(message != NULL);
	QSC_ASSERT(msglen != NULL);
	QSC_ASSERT(signedmsg != NULL);
	QSC_ASSERT(publickey != NULL);
	QSC_ASSERT(smsglen >= ED25519_SIGNATURE_SIZE);
	QSC_ASSERT(smsglen - ED25519_SIGNATURE_SIZE < QSC_SIZE_MAX);

	size_t mlen;
	bool res;

	res = false;

	if (message != NULL && msglen != NULL && signedmsg != NULL && publickey != NULL && 
		smsglen >= ED25519_SIGNATURE_SIZE && smsglen - ED25519_SIGNATURE_SIZE < QSC_SIZE_MAX)
	{
		mlen = smsglen - ED25519_SIGNATURE_SIZE;

		if (eddsa_ed25519_verify(signedmsg, signedmsg + ED25519_SIGNATURE_SIZE, mlen, publickey) == false)
		{
			if (mlen > 0U)
			{
				qsc_memutils_secure_erase(message, mlen);
			}
			
			*msglen = 0;
		}
		else
		{
			if (mlen > 0U)
			{
				qsc_memutils_copy(message, signedmsg + ED25519_SIGNATURE_SIZE, mlen);
			}

			*msglen = mlen;
			res = true;
		}
	}

	return res;
}
