/* 2020-2026 Quantum Resistant Cryptographic Solutions Corporation
 * All Rights Reserved.
 *
 * NOTICE:
 * This software and all accompanying materials are the exclusive property of
 * Quantum Resistant Cryptographic Solutions Corporation (QRCS). The intellectual
 * and technical concepts contained herein are proprietary to QRCS and are
 * protected under applicable Canadian, U.S., and international copyright,
 * patent, and trade secret laws.
 *
 * CRYPTOGRAPHIC ALGORITHMS AND IMPLEMENTATIONS:
 * - This software includes implementations of cryptographic primitives and
 *   algorithms that are standardized or in the public domain, such as AES
 *   and SHA-3, which are not proprietary to QRCS.
 * - This software also includes cryptographic primitives, constructions, and
 *   algorithms designed by QRCS, including but not limited to RCS, SCB, CSX, QMAC, and
 *   related components, which are proprietary to QRCS.
 * - All source code, implementations, protocol compositions, optimizations,
 *   parameter selections, and engineering work contained in this software are
 *   original works of QRCS and are protected under this license.
 *
 * LICENSE AND USE RESTRICTIONS:
 * - This software is licensed under the Quantum Resistant Cryptographic Solutions
 *   Public Research and Evaluation License (QRCS-PREL), 2025-2026.
 * - Permission is granted solely for non-commercial evaluation, academic research,
 *   cryptographic analysis, interoperability testing, and feasibility assessment.
 * - Commercial use, production deployment, commercial redistribution, or
 *   integration into products or services is strictly prohibited without a
 *   separate written license agreement executed with QRCS.
 * - Licensing and authorized distribution are solely at the discretion of QRCS.
 *
 * EXPERIMENTAL CRYPTOGRAPHY NOTICE:
 * Portions of this software may include experimental, novel, or evolving
 * cryptographic designs. Use of this software is entirely at the user's risk.
 *
 * DISCLAIMER:
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, SECURITY, OR NON-INFRINGEMENT. QRCS DISCLAIMS ALL
 * LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING FROM THE USE OR MISUSE OF THIS SOFTWARE.
 *
 * FULL LICENSE:
 * This software is subject to the Quantum Resistant Cryptographic Solutions
 * Public Research and Evaluation License (QRCS-PREL), 2025-2026. The complete license terms
 * are provided in the accompanying LICENSE file or at https://www.qrcscorp.ca.
 *
 * Written by: John G. Underhill
 * Contact: contact@qrcscorp.ca
 */

#ifndef QSC_SOCKETBASE_H
#define QSC_SOCKETBASE_H

#include "qsccommon.h"
#include "intutils.h"
#include "ipinfo.h"
#include "memutils.h"
#include "socket.h"

QSC_CPLUSPLUS_ENABLED_START

/**
 * \file socketbase.h
 * \brief Socket function definitions.
 *
 * \details
 * This header provides the fundamental function definitions, enums, and structures for socket-based networking.
 * It abstracts the underlying system-specific implementations for network socket operations,
 * enabling a unified interface for both Windows and POSIX systems. The API supports the creation,
 * configuration, and management of sockets for TCP/IP communication, including both IPv4 and IPv6.
 * Functions provided in this module handle tasks such as opening, closing, binding, and listening
 * on sockets, as well as setting various socket options and error handling.
 *
 * \section socketbase_links Reference Links:
 * - <a href="https://docs.microsoft.com/en-us/windows/win32/winsock/windows-sockets-start-page">Windows Sockets (Winsock) Documentation</a>
 * - <a href="https://pubs.opengroup.org/onlinepubs/9699919799/functions/socket.html">POSIX Sockets Documentation</a>
 */

/* bogus winbase.h error */
QSC_SYSTEM_CONDITION_IGNORE(5105)

#if defined(QSC_SYSTEM_OS_WINDOWS)
#   include <WinSock2.h>
#elif defined(QSC_SYSTEM_OS_POSIX)
#   include <sys/select.h>
#endif

///*!
//\par Configuration macro: \c QSC_SOCKET_DUAL_IPV6_STACK
//  brief Enables a dual stack ipv4 and ipv6 listener.
// * end comment
//#if !defined(QSC_SOCKET_DUAL_IPV6_STACK)
//#	define QSC_SOCKET_DUAL_IPV6_STACK
//#endif

/*** Function State ***/

/*!
\def QSC_SOCKET_RECEIVE_BUFFER_SIZE
* \brief The socket receive buffer size
*/
#define QSC_SOCKET_RECEIVE_BUFFER_SIZE 1600U

/*!
\def QSC_SOCKET_DEFAULT_SNDBUF_SIZE
* \brief The default socket send buffer size
*/
#define QSC_SOCKET_DEFAULT_SNDBUF_SIZE 65536U  

/*! \enum qsc_socket_exceptions
* \brief Socket code enumeration names
*/
typedef enum
{
	qsc_socket_exception_success = 0,								/*!< The operation completed successfully */
	qsc_socket_exception_error = -1,								/*!< The operation has failed */
	qsc_socket_invalid_input = -2,									/*!< The input parameters are incorrect */
#if defined(QSC_SYSTEM_OS_WINDOWS)
	qsc_socket_exception_address_in_use = WSAEADDRINUSE,			/*!< The socket's local address is already in use and the socket was not marked to allow address reuse with SO_REUSEADDR */
	qsc_socket_exception_address_required = WSAEDESTADDRREQ,		/*!< A destination address is required */
	qsc_socket_exception_address_unsupported = WSAEAFNOSUPPORT,		/*!< The address family is not supported */
	qsc_socket_exception_already_in_use = WSAEISCONN,				/*!< The socket is already connected */
	qsc_socket_exception_blocking_cancelled = WSAEINTR,				/*!< A blocking sockets call was canceled */
	qsc_socket_exception_blocking_in_progress = WSAEINPROGRESS,		/*!< A blocking sockets call is in progress, or the service provider is still processing a callback function */
	qsc_socket_exception_broadcast_address = WSAEACCES,				/*!< The requested address is a broadcast address, but the appropriate flag was not set */
	qsc_socket_exception_buffer_fault = WSAEFAULT,					/*!< The buffer parameter is not completely contained in a valid part of the user address space */
	qsc_socket_exception_circuit_reset = WSAECONNRESET,				/*!< The virtual circuit was reset by the remote side executing a hard or abortive close. */
	qsc_socket_exception_circuit_terminated = WSAECONNABORTED,		/*!< The virtual circuit was terminated due to a time-out or other failure. The application should close the socket as it is no longer usable */
	qsc_socket_exception_circuit_timeout = WSAETIMEDOUT,			/*!< The connection has been dropped, because of a network failure or because the system on the other end went down without notice */
	qsc_socket_exception_connection_refused = WSAECONNREFUSED,		/*!< The connection was refused */
	qsc_socket_exception_descriptor_not_socket = WSAENOTSOCK,		/*!< The descriptor is not a socket */
	qsc_socket_exception_disk_quota_exceeded = WSAEDQUOT,			/*!< The disk quota is exceeded */
	qsc_socket_exception_dropped_connection = WSAENETRESET,			/*!< The connection has been broken due to the keep-alive activity detecting a failure while the operation was in progress */
	qsc_socket_exception_family_unsupported = WSAEPFNOSUPPORT,		/*!< The protocol family is not supported */
	qsc_socket_exception_host_is_down = WSAEHOSTDOWN,				/*!< The destination host is down */
	qsc_socket_exception_host_unreachable = WSAEHOSTUNREACH,		/*!< The remote host cannot be reached from this host at this time */
	qsc_socket_exception_in_progress = WSAEALREADY,					/*!< Operation in progress */
	qsc_socket_exception_invalid_address = WSAEADDRNOTAVAIL,		/*!< The address is not available */
	qsc_socket_exception_invalid_parameter = WSA_INVALID_PARAMETER,	/*!< One or more parameters are invalid */
	qsc_socket_exception_invalid_protocol = WSAEPROTOTYPE,			/*!< The protocol type is invalid for the socket */
	qsc_socket_exception_invalid_protocol_option = WSAENOPROTOOPT,	/*!< The protocol option is invalid */
	qsc_socket_exception_invalid_provider = WSAEINVALIDPROVIDER,	/*!< The service provider is invalid */
	qsc_socket_exception_item_is_remote = WSAEREMOTE,				/*!< The item is not available locally */
	qsc_socket_exception_message_too_long = WSAEMSGSIZE,			/*!< The message size is too long */
	qsc_socket_exception_name_too_long = WSAENAMETOOLONG,			/*!< The name is too long */
	qsc_socket_exception_network_failure = WSAENETDOWN,				/*!< The network subsystem has failed */
	qsc_socket_exception_network_unreachable = WSAENETUNREACH,		/*!< The network is unreachable */
	qsc_socket_exception_no_buffer_space = WSAENOBUFS,				/*!< No buffer space is available */
	qsc_socket_exception_no_descriptors = WSAEMFILE,				/*!< No more socket descriptors are available */
	qsc_socket_exception_no_memory = WSA_NOT_ENOUGH_MEMORY,			/*!< The system does not have enough memory available */
	qsc_socket_exception_not_bound = WSAEINVAL,						/*!< The socket has not been bound with bind, or an unknown flag was specified, or MSG_OOB was specified for a socket with SO_OOBINLINE enabled */
	qsc_socket_exception_not_connected = WSAENOTCONN,				/*!< The socket is not connected */
	qsc_socket_exception_not_initialized = WSANOTINITIALISED,		/*!< A successful WSAStartup call must occur before using this function */
	qsc_socket_exception_operation_unsupported = WSAEOPNOTSUPP,		/*!< The socket operation is not supported */
	qsc_socket_exception_protocol_unsupported = WSAEPROTONOSUPPORT,	/*!< The protocol is not supported */
	qsc_socket_exception_shut_down = WSAESHUTDOWN,					/*!< The socket has been shut down; it is not possible to send on a socket after shutdown has been invoked with how set to QSC_SOCKET_SD_SEND or QSC_SOCKET_SD_BOTH */
	qsc_socket_exception_socket_unsupported = WSAESOCKTNOSUPPORT,	/*!< The socket type is not supported */
	qsc_socket_exception_system_not_ready = WSASYSNOTREADY,			/*!< The subsystem is unavailable */
	qsc_socket_exception_too_many_processes = WSAEPROCLIM,			/*!< The host is using too many processes */
	qsc_socket_exception_too_many_users = WSAEUSERS,				/*!< The user quota is exceeded */
	qsc_socket_exception_translation_failed = WSAELOOP,				/*!< Can not translate name */
	qsc_socket_exception_would_block = WSAEWOULDBLOCK,				/*!< The socket is marked as nonblocking and the requested operation would block */
#else
	qsc_socket_exception_address_in_use = EADDRINUSE,				/*!< address already in use */
	qsc_socket_exception_address_required = EDESTADDRREQ,			/*!< Destination address required */
	qsc_socket_exception_address_unsupported = EAFNOSUPPORT,		/*!< The address family is not supported */
	qsc_socket_exception_already_in_use = EISCONN,					/*!< qsc_socket is already connected */
	qsc_socket_exception_blocking_cancelled = EINTR,				/*!< A blocking call was canceled */
	qsc_socket_exception_blocking_in_progress = EINPROGRESS,		/*!< A blocking sockets call is in progress, or the service provider is still processing a callback function */
	qsc_socket_exception_broadcast_address = EACCES,				/*!< The requested address is a broadcast address, but the appropriate flag was not set */
	qsc_socket_exception_buffer_fault = EFAULT,						/*!< The buffer parameter is not completely contained in a valid part of the user address space */
	qsc_socket_exception_circuit_terminated = ECONNABORTED,			/*!< Software caused connection abort */
	qsc_socket_exception_circuit_reset = ECONNRESET,				/*!< connection reset by peer */
	qsc_socket_exception_circuit_timeout = ETIMEDOUT,				/*!< connection timed out */
	qsc_socket_exception_connection_refused = ECONNREFUSED,			/*!< connection refused */
	qsc_socket_exception_descriptor_not_socket = ENOTSOCK,			/*!< qsc_socket operation on non-socket */
	qsc_socket_exception_disk_quota_exceeded = EDQUOT,				/*!< The disk quota is exceeded */
	qsc_socket_exception_dropped_connection = ENETRESET,			/*!< Network dropped connection on reset */
	qsc_socket_exception_family_unsupported = EPFNOSUPPORT,			/*!< Protocol family not supported */
	qsc_socket_exception_host_is_down = EHOSTDOWN,					/*!< The destination host is down */
	qsc_socket_exception_host_unreachable = EHOSTUNREACH,			/*!< The remote host cannot be reached from this host at this time */
	qsc_socket_exception_in_progress = EALREADY,					/*!< Operation already in progress */
	qsc_socket_exception_invalid_address = EADDRNOTAVAIL,			/*!< Can't assign requested address */
	//qsc_socket_exception_invalid_parameter = EOTHER,				/*!< One or more parameters are invalid */
	qsc_socket_exception_invalid_protocol = EPROTOTYPE,				/*!< Protocol wrong type for socket */
	qsc_socket_exception_invalid_protocol_option = ENOPROTOOPT,		/*!< Protocol not available */
	//qsc_socket_exception_invalid_provider = EINVALIDPROVIDER,		/*!< The service provider is invalid */
	qsc_socket_exception_item_is_remote = EREMOTE,					/*!< The item is not available locally */
	qsc_socket_exception_message_too_long = EMSGSIZE,				/*!< The message size is too long */
	qsc_socket_exception_name_too_long = ENAMETOOLONG,				/*!< The name is too long */
	qsc_socket_exception_network_failure = ENETDOWN,				/*!< Network is down */
	qsc_socket_exception_network_unreachable = ENETUNREACH,			/*!< Network is unreachable */
	qsc_socket_exception_no_buffer_space = ENOBUFS,					/*!< No buffer space available */
	qsc_socket_exception_no_descriptors = EMFILE,					/*!< No more socket descriptors are available */
	qsc_socket_exception_not_bound = EINVAL,						/*!< The socket has not been bound with bind, or an unknown flag was specified, or MSG_OOB was specified for a socket with SO_OOBINLINE enabled */
	qsc_socket_exception_not_connected = ENOTCONN,					/*!< qsc_socket is not connected */
	qsc_socket_exception_operation_unsupported = EOPNOTSUPP,		/*!< The socket operation is not supported */
	qsc_socket_exception_protocol_unsupported = EPROTONOSUPPORT,	/*!< Protocol not supported */
	qsc_socket_exception_socket_unsupported = ESOCKTNOSUPPORT,		/*!< qsc_socket type not supported */
	qsc_socket_exception_shut_down = ESHUTDOWN,						/*!< Can't send after socket shutdown */
	qsc_socket_exception_system_not_ready = ETXTBSY,				/*!< The subsystem is unavailable */
	//qsc_socket_exception_too_many_processes = EPROCLIM,			/*!< The host is using too many processes */
	qsc_socket_exception_too_many_users = EUSERS,					/*!< The user quota is exceeded */
	qsc_socket_exception_translation_failed = ELOOP,				/*!< Can not translate name */
	qsc_socket_exception_would_block = EWOULDBLOCK,					/*!< Operation would block */

#endif
} qsc_socket_exceptions;

/*! \brief The socket error strings array.
* \brief Error messages corresponding to the qsc_socket_exceptions enumeration.
*/
extern const char QSC_SOCKET_ERROR_STRINGS[48][128];

/*! \struct qsc_socket_receive_async_state
* \brief The socket async receive state structure.
* The structure contains pointers to the originating socket,
* message and error call-backs, and the message buffer.
*/
typedef struct
{
	void (*callback)(qsc_socket* sock, const uint8_t* message, size_t* msglen);	/*!< A pointer to a callback function */
	void (*error)(const qsc_socket* sock, qsc_socket_exceptions exception);		/*!< A pointer to an error function */
	qsc_socket* source;															/*!< A pointer to the originating socket */
	uint8_t buffer[QSC_SOCKET_RECEIVE_BUFFER_SIZE];								/*!< A pointer to the message buffer */
} qsc_socket_receive_async_state;

/*! \struct qsc_socket_receive_poll_state
* \brief The socket polling state structure.
* The structure contains an array of client sockets,
* and a socket counter with sockets that are ready to receive data.
*/
typedef struct
{
	qsc_socket** sockarr;														/*!< A pointer to an array of sockets */
	void (*callback)(qsc_socket* sock, size_t id);								/*!< A pointer to a callback function */
	void (*error)(qsc_socket* sock, qsc_socket_exceptions exception);			/*!< A pointer to an error function */
	uint32_t count;																/*!< The number of active sockets */
} qsc_socket_receive_poll_state;

/*! \def QSC_SOCKET_IOV_MAX_BUFFERS
 * \brief Maximum number of buffers accepted in one vectored operation.
 */
#define QSC_SOCKET_IOV_MAX_BUFFERS 16U

/*! \struct qsc_socket_const_buffer
 * \brief Immutable application-owned byte span for synchronous vectored sending.
 * \details The caller retains ownership and must keep each span alive until the call returns. Thread safety follows the socket.
 */
typedef struct
{
	const uint8_t* data; /*!< Pointer to a readable byte buffer; must not be NULL. */
	size_t length; /*!< Number of readable bytes; at most INT32_MAX per entry. */
} qsc_socket_const_buffer;

/*! \struct qsc_socket_buffer
 * \brief Mutable application-owned byte span for synchronous vectored receiving.
 * \details The caller retains ownership and must keep each span alive until the call returns. Thread safety follows the socket.
 */
typedef struct
{
	uint8_t* data; /*!< Pointer to a writable byte buffer; must not be NULL. */
	size_t length; /*!< Number of writable bytes; at most INT32_MAX per entry. */
} qsc_socket_buffer;

/*** Function Prototypes ***/

// **
//  brief The socket exception callback prototype
//*
//  param source: [qsc_socket*] The socket source
//  param error: [qsc_socket_exceptions] The socket exception
// * end comment
//QSC_EXPORT_API void qsc_socket_exception_callback(qsc_socket* source, qsc_socket_exceptions error);

// **
//  brief The socket receive asynchronous callback prototype
//*
//  param source:v[qsc_socket*] The socket source
//  param message:	[const uint8_t*] The socket message buffer
//  param msglen:v[size_t*] A pointer to the size of the message
// * end comment
//QSC_EXPORT_API void qsc_socket_receive_async_callback(qsc_socket* source, const uint8_t* message, size_t* msglen);

// **
//  brief The receive polling callback prototype
//*
//  param source: [const qsc_socket*] The socket source
//  param error: [size_t] The socket exception
// * end comment
//QSC_EXPORT_API void qsc_socket_receive_poll_callback(const qsc_socket* source, size_t error);

/*** Accessors ***/

/**
* \brief Detects if the string contains a valid IPV4 address
* \param address: [const char*] The IP address string
*
* \return [bool] Returns true if the address is a valid IPV4 address
*/
QSC_EXPORT_API bool qsc_socket_ipv4_valid_address(const char* address);

/**
* \brief Detects if the string contains a valid IPV6 address
* \param address: [const char*] The IP address string
*
* \return [bool] Returns true if the address is a valid IPV6 address
*/
QSC_EXPORT_API bool qsc_socket_ipv6_valid_address(const char* address);

/**
* \brief Determines if the socket is in blocking mode
*
* \param sock: [const qsc_socket*] The socket instance
*
* \return [bool] Returns true if the socket is blocking
*/
QSC_EXPORT_API bool qsc_socket_is_blocking(const qsc_socket* sock);

/**
* \brief Set the socket blocking mode.
*
* This function enables or disables blocking behavior on an initialized socket.
* A blocking socket waits for send, receive, accept, and connect operations to
* complete. A non-blocking socket returns immediately when an operation would block.
*
* \param sock: [const qsc_socket*] The socket instance
* \param enabled: [bool] Enable blocking mode when true, or non-blocking mode when false
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_set_blocking(const qsc_socket* sock, bool enabled);

/**
* \brief Determines if the socket is connected
*
* \param sock: [const qsc_socket*] The socket instance
*
* \return [bool] Returns true if the socket is connected
*/
QSC_EXPORT_API bool qsc_socket_is_connected(const qsc_socket* sock);

/**
* \brief The Accept function handles an incoming connection attempt on the socket
*
* \param source: [const qsc_socket*] The source listening socket instance
* \param target: [const qsc_socket*] The socket receiving the new socket
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_accept(const qsc_socket* source, qsc_socket* target);

/**
* \brief Copy a socket to the target socket
*
* \param source: [qsc_socket*] The source socket instance
* \param target: [qsc_socket*] The socket to attach
*/
QSC_EXPORT_API void qsc_socket_attach(qsc_socket* source, qsc_socket* target);

/**
* \brief The Bind function associates an IP address with a socket
*
* \param sock: [qsc_socket*] The socket instance
* \param address: [const char*] The IP address to bind to the socket
* \param port: [uint16_t] The service port number
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_bind(qsc_socket* sock, const char* address, uint16_t port);

/**
* \brief The Bind function associates an IPv4 address with a socket
*
* \param sock: [qsc_socket*] The socket instance
* \param address: [const qsc_ipinfo_ipv4_address*] The IPv4 address to bind to the socket
* \param port: [uint16_t] The service port number
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_bind_ipv4(qsc_socket* sock, const qsc_ipinfo_ipv4_address* address, uint16_t port);

/**
* \brief The Bind function associates an IPv6 address with a socket
*
* \param sock: [qsc_socket*] The socket instance
* \param address: [const qsc_ipinfo_ipv6_address*] The IPv6 address to bind to the socket
* \param port: [uint16_t] The service port number
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_bind_ipv6(qsc_socket* sock, const qsc_ipinfo_ipv6_address* address, uint16_t port);

/**
* \brief Erases the socket struture
*
* \param sock: [qsc_socket*] The socket instance
*/
QSC_EXPORT_API void qsc_socket_clear_socket(qsc_socket* sock);

/**
* \brief Closes and disposes of the socket
*
* \param sock: [qsc_socket*] The socket instance
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_close_socket(qsc_socket* sock);

/**
* \brief The Connect function establishes a connection to a remote host
*
* \param sock: [qsc_socket*] The socket instance
* \param address: [const char*] The remote hosts IP address
* \param port:		[uint16_t] The remote hosts service port number
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_connect(qsc_socket* sock, const char* address, uint16_t port);

/**
* \brief The Connect function establishes a connection to a remote host using IPv4 addressing
*
* \param sock: [qsc_socket*] The socket instance
* \param address: [const qsc_ipinfo_ipv4_address*] The remote hosts IPv4 address
* \param port: [uint16_t] The remote hosts service port number
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_connect_ipv4(qsc_socket* sock, const qsc_ipinfo_ipv4_address* address, uint16_t port);

/**
* \brief The Connect function establishes a connection to a remote host using IPv6 addressing
*
* \param sock: [qsc_socket*] The socket instance
* \param address: [const] The remote hosts IPv6 address
* \param port: [const qsc_ipinfo_ipv6_address*] The remote hosts service port number
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_connect_ipv6(qsc_socket* sock, const qsc_ipinfo_ipv6_address* address, uint16_t port);

/**
* \brief The Create function creates a socket that is bound to a specific transport provider
*
* \param sock: [qsc_socket*] The socket instance
* \param family: [qsc_socket_address_families] The address family
* \param transport:	[qsc_socket_transports] The transport layer
* \param protocol: [qsc_socket_protocols] The socket protocol
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_create(qsc_socket* sock, qsc_socket_address_families family, qsc_socket_transports transport, qsc_socket_protocols protocol);

/**
* \brief Places the socket in the listening state, waiting for a connection
*
* \param sock: [const qsc_socket*] The socket instance
* \param backlog: [int32_t] The maximum pending connections queue length
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_listen(const qsc_socket* sock, int32_t backlog);

/**
* \brief Get the maximum send buffer size for a socket
*
* \param sock: [const qsc_socket*] The socket instance
*
* \return [size_t] Returns the maximum length of a send buffer
*/
QSC_EXPORT_API size_t qsc_socket_max_send_buffer_size(const qsc_socket* sock);

/**
* \brief Receive data from a synchronous connected socket or a bound connection-less socket without downloading the entire message
*
* \param sock: [const qsc_socket*] The socket instance
* \param output: [uint8_t*] The output buffer that receives data
* \param otplen: [size_t] The length of the output received
*
* \return [size_t] Returns the number of bytes received from the remote host
*/
QSC_EXPORT_API size_t qsc_socket_peek(const qsc_socket* sock, uint8_t* output, size_t otplen);

/**
* \brief Receive data from a synchronous connected socket or a bound connection-less socket.
* Note: the receive buffer must be at least 1 byte larger than the expected size to accomodate a packet terminator.
* When calling receive with the wait-all flag, the receiver must include the terminator to empty the buffer.
*
* \param sock: [const qsc_socket*] The socket instance
* \param output: [uint8_t*] The output buffer that receives data
* \param otplen: [size_t] The length of the output received
* \param flag: [qsc_socket_receive_flags] Flags that influence the behavior of the receive function
*
* \return [size_t] Returns the number of bytes received from the remote host
*/
QSC_EXPORT_API size_t qsc_socket_receive(const qsc_socket* sock, uint8_t* output, size_t otplen, qsc_socket_receive_flags flag);

/**
* \brief Receive a block of data from a synchronous connected socket or a bound connection-less socket, and returns when buffer is full
*
* \param sock: [const qsc_socket*] The socket instance
* \param output: [uint8_t*] The output buffer that receives data
* \param otplen: [size_t] The length of the output received
* \param flag: [qsc_socket_receive_flags] Flags that influence the behavior of the receive function
*
* \return [size_t] Returns the number of bytes received from the remote host
*/
QSC_EXPORT_API size_t qsc_socket_receive_all(const qsc_socket* sock, uint8_t* output, size_t otplen, qsc_socket_receive_flags flag);

/**
 * \brief Receive exactly a requested byte count while exposing partial progress on failure.
 * \param sock Connected socket; must remain valid for the entire operation.
 * \param output Writable destination of at least otplen bytes.
 * \param otplen Exact number of bytes to receive.
 * \param flag Receive flags passed unchanged to the underlying socket API.
 * \param received Non-NULL output pointer; receives the number of bytes read even on failure.
 * \return Success when all bytes were received; not_connected on orderly EOF; otherwise an error code.
 * \details Blocking sockets may wait indefinitely; nonblocking sockets return would_block and progress.
 * Buffers are caller-owned; simultaneous reads on the same socket require external synchronization.
 */
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_receive_progress(const qsc_socket* sock, uint8_t* output, size_t otplen, qsc_socket_receive_flags flag, size_t* received);

/**
 * \brief Receive into multiple caller-owned buffers using one scatter I/O operation.
 * \param sock Socket receiving data.
 * \param buffers Array of count writable byte spans (each of at most INT32_MAX bytes).
 * \param count Number of spans, from 1 to QSC_SOCKET_IOV_MAX_BUFFERS.
 * \param flag Platform receive flags.
 * \return Bytes received, or zero for EOF/failure. Inspect qsc_socket_get_last_error on failure.
 * \details The call may return after a partial transfer. The caller owns all buffers; synchronize concurrent reads.
 */
QSC_EXPORT_API size_t qsc_socket_receive_vectored(const qsc_socket* sock, const qsc_socket_buffer* buffers, size_t count, qsc_socket_receive_flags flag);

/**
* \brief Receive data from a connected socket asynchronously
*
* \param state: [qsc_socket_receive_async_state*] A pointer to the async receive data structure
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_receive_async(qsc_socket_receive_async_state* state);

/**
* \brief Receive data from a synchronous connected socket or a bound connection-less socket
*
* \param sock: [qsc_socket*] The local socket
* \param dest: [char*] The destination IP address string
* \param destlen: [size_t] The length of the destination buffer
* \param port: [uint16_t] The port receiving the data
* \param output: [uint8_t*] The output buffer
* \param otplen: [size_t] The length of the output buffer
* \param flag: [qsc_socket_receive_flags] Flags that influence the behavior of the receive from function
*
* \return [size_t] Returns the number of bytes received from the remote host
*/
QSC_EXPORT_API size_t qsc_socket_receive_from(qsc_socket* sock, char* dest, size_t destlen, uint16_t port, uint8_t* output, size_t otplen, qsc_socket_receive_flags flag);

/**
* \brief Polls an array of sockets.
* Fires a callback if a socket is ready to receive data, or an error if socket is disconnected.
*
* \param state: [const qsc_socket_receive_poll_state*] The server state, containing a pointer to an array of sockets
*
* \return [uint32_t] Returns the number of sockets with data
*/
QSC_EXPORT_API uint32_t qsc_socket_receive_poll(const qsc_socket_receive_poll_state* state);

/**
* \brief Receive data from a synchronous connected socket with a temporary receive timeout.
*
* The function saves the socket's current receive timeout, applies the specified timeout,
* performs the receive operation, and restores the original timeout before returning.
* The timeout value is specified in milliseconds. A timeout value of zero disables the
* receive timeout and uses normal blocking behavior.
*
* \param sock: [const qsc_socket*] The socket instance
* \param output: [uint8_t*] The output buffer that receives data
* \param otplen: [size_t] The length of the output buffer
* \param flag: [qsc_socket_receive_flags] Flags that influence the behavior of the receive function
* \param timeout: [int32_t] The temporary receive timeout in milliseconds
*
* \return [size_t] Returns the number of bytes received from the remote host
*/
QSC_EXPORT_API size_t qsc_socket_receive_timeout(const qsc_socket* sock, uint8_t* output, size_t otplen, qsc_socket_receive_flags flag, int32_t timeout);

/**
* \brief Sends data on a TCP connected socket.
* Note: The input buffer must be at least 1 byte longer than the input length.
* The send function terminates the packet with a null character for simplified string termination.
*
* \param sock: [const qsc_socket*] The socket instance
* \param input: [const uint8_t*] The input buffer containing the data to be transmitted
* \param inplen: [size_t] The number of bytes to send
* \param flag: [qsc_socket_send_flags] Flags that influence the behavior of the send function
*
* \return [size_t] Returns the number of bytes sent to the remote host
*/
QSC_EXPORT_API size_t qsc_socket_send(const qsc_socket* sock, const uint8_t* input, size_t inplen, qsc_socket_send_flags flag);

/**
* \brief Sends data on a UDP socket
*
* \param sock: [const qsc_socket*] The socket instance
* \param input: [const uint8_t*] The input buffer containing the data to be transmitted
* \param inplen: [size_t] The number of bytes to send
* \param flag: [qsc_socket_send_flags] Flags that influence the behavior of the send function
*
* \return [size_t] Returns the number of bytes sent to the remote host
*/
QSC_EXPORT_API size_t qsc_socket_send_to(const qsc_socket* sock, const uint8_t* input, size_t inplen, qsc_socket_send_flags flag);

/**
* \brief Sends a block of data larger than a single packet size, on a TCP socket and returns when sent
*
* \param sock: [const qsc_socket*] The socket instance
* \param input: [const uint8_t*] The input buffer containing the data to be transmitted
* \param inplen: [size_t] The number of bytes to send
* \param flag: [qsc_socket_send_flags] Flags that influence the behavior of the send function
*
* \return [size_t] Returns the number of bytes sent to the remote host
*/
QSC_EXPORT_API size_t qsc_socket_send_all(const qsc_socket* sock, const uint8_t* input, size_t inplen, qsc_socket_send_flags flag);

/**
 * \brief Send exactly a requested byte count while exposing partial progress on failure.
 * \param sock Connected socket; must remain valid for the entire operation.
 * \param input Readable buffer containing at least inplen bytes.
 * \param inplen Exact number of bytes to transmit.
 * \param flag Send flags passed to the platform socket API.
 * \param sent Non-NULL output pointer; receives the number of bytes sent even on failure.
 * \return Success when the entire buffer is sent, not_connected for zero-byte send, or the platform error.
 * \details Blocking sockets may wait indefinitely; nonblocking sockets return would_block with progress.
 * The caller retains buffer ownership; serialize writes if preserving stream message order matters.
 */
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_send_progress(const qsc_socket* sock, const uint8_t* input, size_t inplen, qsc_socket_send_flags flag, size_t* sent);

/**
 * \brief Send from multiple caller-owned buffers using one gather I/O operation.
 * \param sock Socket transmitting data.
 * \param buffers Array of count readable byte spans (each of at most INT32_MAX bytes).
 * \param count Number of spans, from 1 to QSC_SOCKET_IOV_MAX_BUFFERS.
 * \param flag Platform send flags.
 * \return Bytes sent, or zero on failure; inspect qsc_socket_get_last_error on failure.
 * \details Short writes are possible. The caller owns all buffers; synchronize concurrent writes as needed.
 */
QSC_EXPORT_API size_t qsc_socket_send_vectored(const qsc_socket* sock, const qsc_socket_const_buffer* buffers, size_t count, qsc_socket_send_flags flag);

/**
* \brief Shuts down a socket
*
* \param sock: [qsc_socket*] The socket instance
* \param params: [qsc_socket_shut_down_flags] The shutdown parameters
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_shut_down(qsc_socket* sock, qsc_socket_shut_down_flags params);

/*~~~ Helper Functions ~~~*/

/*!
 * \brief Get the value of a socket option.
 *
 * \details
 * Retrieves the current value of a socket option from the operating system.
 * Socket timeout options are returned in milliseconds.
 *
 * \param sock: [const] A pointer to the socket structure.
 * \param level: The socket protocol level.
 * \param option: The socket option to query.
 * \param optval: A pointer receiving the option value.
 *
 * \return Returns the socket exception status.
 */
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_get_option(const qsc_socket* sock, qsc_socket_protocols level, qsc_socket_options option, int32_t* optval);

/**
* \brief Returns the error string associated with the exception code
* \param code: [qsc_socket_exceptions] The exception code
*
* \return [const char*] Returns the error string
*/
QSC_EXPORT_API const char* qsc_socket_error_to_string(qsc_socket_exceptions code);

/**
* \brief The last error generated by the internal socket library
*
* \return [qsc_socket_exceptions] Returns the last exception code
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_get_last_error(void);

/**
* \brief Sets the IO mode of the socket
*
* \param sock: [const qsc_socket*] [const] The socket instance
* \param command: [int32_t] The command to pass to the socket
* \param arguments:	[uint32_t*] The command arguments
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_ioctl(const qsc_socket* sock, int32_t command, uint32_t* arguments);

/**
* \brief Tests the socket to see if it is ready to receive data
*
* \param sock: [const qsc_socket*] The socket instance
* \param timeout: [const struct timeval*] The receive wait timeout
*
* \return [bool] Returns true if the socket is ready to receive data
*/
QSC_EXPORT_API bool qsc_socket_receive_ready(const qsc_socket* sock, const struct timeval* timeout);

/**
* \brief Tests the socket to see if it is ready to send data
*
* \param sock: [const qsc_socket*] The socket instance
* \param timeout: [const struct timeval*] The maximum time to wait for a response from the socket
*
* \return [bool] Returns true if the socket is ready to send data
*/
QSC_EXPORT_API bool qsc_socket_send_ready(const qsc_socket* sock, const struct timeval* timeout);

/**
* \brief Set the last error generated by the socket library
*
* \param error: [qsc_socket_exceptions] The error code
*/
QSC_EXPORT_API void qsc_socket_set_last_error(qsc_socket_exceptions error);

/**
* \brief Shut down the sockets library
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_shut_down_sockets(void);

/**
* \brief Send an option command to the socket.
* Options that use a boolean are format: 0=false, 1=true.
*
* \param sock: [const qsc_socket*] The socket instance
* \param level: [qsc_socket_protocols] The level at which the option is assigned
* \param option: [qsc_socket_options] The option command to send
* \param optval: [int32_t] The value of the option command
*
* \return [qsc_socket_exceptions] Returns an exception code on failure, or success(0)
*/
QSC_EXPORT_API qsc_socket_exceptions qsc_socket_set_option(const qsc_socket* sock, qsc_socket_protocols level, qsc_socket_options option, int32_t optval);

/**
* \brief Start the sockets library
*
* \return [bool] Returns true on success
*/
QSC_EXPORT_API bool qsc_socket_start_sockets(void);

/**
 * \defgroup qsc_socket_event Scalable socket event and completion interfaces
 * \brief Additive operating-system event backends; legacy socket interfaces are unchanged.
 * \details Readiness and completion are different contracts. POSIX readiness notifications
 * do not transfer bytes. Windows IOCP notifications report completed overlapped transfers.
 * Existing socket handles are borrowed; callers retain ownership of sockets and buffers.
 * Event loops may be woken from other threads; registration, waiting and destruction must
 * otherwise be serialized by the caller. Socket shutdown and closure require deregistration.
 * @{ 
 */

#if defined(QSC_SYSTEM_OS_POSIX)

/** \brief Socket readiness event bit flags, which may be combined. */
typedef enum
{
	qsc_socket_event_none = 0x00U,     /*!< No notification. */
	qsc_socket_event_read = 0x01U,     /*!< Reading or accepting may proceed without blocking. */
	qsc_socket_event_write = 0x02U,    /*!< Writing may proceed without blocking. */
	qsc_socket_event_error = 0x04U,    /*!< Socket error; inspect the socket error state. */
	qsc_socket_event_hangup = 0x08U,   /*!< Kernel-reported shutdown or peer closure; platform dependent; pending data may remain. */
	qsc_socket_event_wakeup = 0x10U    /*!< Explicit cross-thread wake request. */
} qsc_socket_event_type;

/** \brief One readiness notification; the socket descriptor remains caller-owned. */
typedef struct
{
	socket_t connection;  /*!< Registered socket descriptor, or QSC_UNINITIALIZED_SOCKET for wakeup. */
	uint32_t events;      /*!< Bitwise OR of qsc_socket_event_type values. */
} qsc_socket_event;

/** \brief Opaque scalable readiness multiplexer; allocated and owned by the caller. */
typedef struct qsc_socket_event_loop qsc_socket_event_loop;

/**
 * \brief Create a socket readiness loop using epoll (Linux), kqueue (BSD/macOS), or poll fallback.
 * \param capacity Maximum registered socket count; must be nonzero and at most INT32_MAX - 1.
 * \return Newly allocated loop, or NULL on allocation or operating-system failure.
 * \details On success release with qsc_socket_event_loop_destroy(). Does not own sockets.
 * Registration, waiting and destruction must not run concurrently; wakeup is thread-safe.
 */
QSC_EXPORT_API qsc_socket_event_loop* qsc_socket_event_loop_create(size_t capacity);

/**
 * \brief Register a socket for level-triggered readiness events.
 * \param loop Initialized loop, not NULL.
 * \param sock Valid caller-owned socket, not NULL.
 * \param events Interest flags, read and/or write only.
 * \return true if registered, otherwise false (including duplicate registration or full loop).
 * \details An active socket must be unregistered before close or descriptor reuse.
 */
QSC_EXPORT_API bool qsc_socket_event_loop_register(qsc_socket_event_loop* loop, const qsc_socket* sock, uint32_t events);

/**
 * \brief Replace the read/write interest mask for a previously registered socket.
 * \param loop Initialized loop.
 * \param sock Previously registered caller-owned socket.
 * \param events New interest mask, read and/or write.
 * \return true on success, false on invalid state or operating-system failure.
 */
QSC_EXPORT_API bool qsc_socket_event_loop_modify(qsc_socket_event_loop* loop, const qsc_socket* sock, uint32_t events);

/**
 * \brief Remove a socket from the loop without closing it.
 * \param loop Initialized loop.
 * \param sock Previously registered socket.
 * \return true on success, false otherwise.
 * \details Callers must synchronize this operation with waits and socket destruction.
 */
QSC_EXPORT_API bool qsc_socket_event_loop_unregister(qsc_socket_event_loop* loop, const qsc_socket* sock);

/**
 * \brief Collect available readiness notifications and cross-thread wake requests.
 * \param loop Initialized loop.
 * \param output Caller-owned array of at least capacity events.
 * \param capacity Number of writable output entries, from 1 through INT32_MAX - 1.
 * \param timeout_ms Wait limit in milliseconds: -1 forever, 0 nonblocking, positive bounded wait.
 * \return Number of events from 0 to capacity, or -1 on invalid input/operating-system failure.
 * \details Readiness is level triggered. Handle read/write without blocking until EAGAIN on
 * nonblocking sockets. EOF may be reported as read readiness without the hangup flag.
 * Wake events use QSC_UNINITIALIZED_SOCKET and the wakeup flag.
 * A single waiter is supported per loop. Output remains valid until the caller overwrites it.
 */
QSC_EXPORT_API int32_t qsc_socket_event_loop_wait(qsc_socket_event_loop* loop, qsc_socket_event* output, size_t capacity, int32_t timeout_ms);

/**
 * \brief Wake a blocked waiter from any thread without registering a socket.
 * \param loop Initialized loop that has not begun destruction.
 * \return true when a wake signal is queued; false on failure.
 * \details Consecutive wake requests may coalesce into a single notification.
 */
QSC_EXPORT_API bool qsc_socket_event_loop_wake(qsc_socket_event_loop* loop);

/**
 * \brief Destroy the loop and internal wake resources; never closes registered sockets.
 * \param loop Loop to free; NULL is allowed.
 * \details Call only after all active waiters and other users have stopped.
 */
QSC_EXPORT_API void qsc_socket_event_loop_destroy(qsc_socket_event_loop* loop);

#endif

#if defined(QSC_SYSTEM_OS_WINDOWS)

/** \brief Native Windows IOCP operation identifiers. */
typedef enum
{
	qsc_socket_iocp_receive = 1, /*!< Overlapped WSARecv completed. */
	qsc_socket_iocp_send = 2,    /*!< Overlapped WSASend completed. */
	qsc_socket_iocp_wakeup = 3  /*!< Cross-thread completion-port wakeup. */
} qsc_socket_iocp_operation;

/** \brief One completed Windows overlapped transfer or explicit wakeup. */
typedef struct
{
	socket_t connection;                 /*!< Borrowed socket handle, or QSC_UNINITIALIZED_SOCKET for wakeup. */
	uint64_t context;                    /*!< Caller-provided operation context identifier. */
	size_t transferred;                  /*!< Number of bytes actually transferred, including partial completions. */
	uint32_t error;                      /*!< Win32 completion error code, 0 on success. */
	qsc_socket_iocp_operation operation; /*!< Receive, send, or wakeup. */
} qsc_socket_iocp_result;

/** \brief Opaque Windows completion-port context with bounded in-flight operations. */
typedef struct qsc_socket_iocp qsc_socket_iocp;

/**
 * \brief Create a Windows IO completion port.
 * \param max_pending Maximum simultaneous submitted operations, between 1 and LONG_MAX.
 * \return Owned IOCP object, or NULL on failure; release with qsc_socket_iocp_destroy().
 * \details Requires Winsock startup. Supports multiple simultaneous waiting consumer threads.
 */
QSC_EXPORT_API qsc_socket_iocp* qsc_socket_iocp_create(uint32_t max_pending);

/**
 * \brief Associate a caller-owned overlapped Winsock socket with a completion port.
 * \param port Initialized completion-port context.
 * \param sock Socket created for overlapped I/O; caller retains its lifetime.
 * \return true on successful association; false on failure.
 * \details A socket cannot be reassociated with a different completion port.
 */
QSC_EXPORT_API bool qsc_socket_iocp_attach(qsc_socket_iocp* port, const qsc_socket* sock);

/**
 * \brief Submit a receive that completes through qsc_socket_iocp_wait().
 * \param port Initialized IOCP context.
 * \param sock Previously associated socket.
 * \param buffer Caller-owned writable buffer, at least length bytes.
 * \param length Maximum receive size, from 1 through ULONG_MAX bytes.
 * \param context Caller-chosen 64-bit identifier returned on completion.
 * \return true if submitted (including immediate completion), otherwise false.
 * \details buffer and sock MUST remain alive until a completion is consumed, even if the
 * submission completes immediately. No request is pending on a false return.
 * Do not enable FILE_SKIP_COMPLETION_PORT_ON_SUCCESS on attached sockets.
 */
QSC_EXPORT_API bool qsc_socket_iocp_submit_receive(qsc_socket_iocp* port, const qsc_socket* sock, uint8_t* buffer, size_t length, uint64_t context);

/**
 * \brief Submit a send that completes through qsc_socket_iocp_wait().
 * \param port Initialized IOCP context.
 * \param sock Previously associated socket.
 * \param buffer Caller-owned read-only buffer, at least length bytes.
 * \param length Maximum send size, from 1 through ULONG_MAX bytes.
 * \param context Caller-chosen 64-bit completion identifier.
 * \return true on successful submission (including immediate completion), otherwise false.
 * \details buffer and sock MUST remain alive until completion. Partial sends are possible.
 * Do not enable FILE_SKIP_COMPLETION_PORT_ON_SUCCESS on attached sockets.
 */
QSC_EXPORT_API bool qsc_socket_iocp_submit_send(qsc_socket_iocp* port, const qsc_socket* sock, const uint8_t* buffer, size_t length, uint64_t context);

/**
 * \brief Wait for one completed operation and reclaim its private OVERLAPPED state.
 * \param port Initialized IOCP context.
 * \param result Writable completion result, not NULL.
 * \param timeout_ms Milliseconds, -1 for indefinite, or a nonnegative timeout.
 * \return 1 for completion (including failed transfers), 0 on timeout, -1 on API failure.
 * \details A completed operation with an error returns 1 and sets result->error.
 * May be used by multiple consumer threads. The caller must serialize destruction.
 */
QSC_EXPORT_API int32_t qsc_socket_iocp_wait(qsc_socket_iocp* port, qsc_socket_iocp_result* result, int32_t timeout_ms);

/**
 * \brief Enqueue one wakeup completion from another thread.
 * \param port Initialized completion-port context.
 * \return true if queued, false on failure.
 */
QSC_EXPORT_API bool qsc_socket_iocp_wake(qsc_socket_iocp* port);

/**
 * \brief Request cancellation of pending I/O on an attached socket.
 * \param port Valid IOCP context (used for API validation, not ownership).
 * \param sock Valid socket associated with the port; caller retains ownership.
 * \return true if cancellation was requested or no pending kernel requests remained.
 * \details Windows CancelIoEx cancels ALL outstanding I/O issued on this socket,
 * including operations submitted outside this module. Each cancelled request still
 * produces a completion that MUST be consumed before buffers or IOCP can be freed.
 * Do not call concurrently with socket destruction.
 */
QSC_EXPORT_API bool qsc_socket_iocp_cancel(qsc_socket_iocp* port, const qsc_socket* sock);

/**
 * \brief Destroy an idle IOCP; refuses to free live overlapped I/O requests.
 * \param port Context to destroy, or NULL.
 * \return true if destroyed or NULL, false if operations remain outstanding.
 * \details For outstanding requests, call qsc_socket_iocp_cancel() and drain ALL resulting
 * completions before retrying. Callers must have stopped submissions and waiting threads.
 * Never closes attached sockets. No automatic cancellation is performed.
 */
QSC_EXPORT_API bool qsc_socket_iocp_destroy(qsc_socket_iocp* port);

#endif

/** @} */

QSC_CPLUSPLUS_ENABLED_END

#endif
