#include "tlsextensions.h"
#include "intutils.h"
#include "memutils.h"
#include "stringutils.h"
#include "tlscodec.h"
#include "tlsdefs.h"

static qsc_tls_status ext_begin(uint8_t* out, size_t outlen, size_t* offset, uint16_t type, size_t* hdrpos)
{
    qsc_tls_status status;

    status = qsc_tls_codec_write_u16(out, outlen, offset, type);

    if (status == qsc_tls_status_success)
    {
        status = qsc_tls_codec_vector_begin_u16(out, outlen, offset, hdrpos);
    }

    return status;
}

static qsc_tls_status ext_end(uint8_t* out, size_t outlen, size_t* offset, size_t hdrpos)
{
    return qsc_tls_codec_vector_end_u16(out, outlen, offset, hdrpos);
}

void qsc_tls_extensions_bitmap_initialize(qsc_tls_extension_bitmap* bitmap)
{
    QSC_ASSERT(bitmap != NULL);

    if (bitmap != NULL)
    { 
        qsc_memutils_clear(bitmap, sizeof(*bitmap)); 
    }
}

bool qsc_tls_extensions_bitmap_set(qsc_tls_extension_bitmap* bitmap, uint16_t extensiontype)
{
    QSC_ASSERT(bitmap != NULL);

    uint64_t* cell;
    uint64_t mask;
    bool added;

    added = false;

    if (bitmap != NULL)
    {
        if (extensiontype < 64U)
        {
            cell = &bitmap->lowmask;
            mask = (uint64_t)1 << extensiontype;
        }
        else if (extensiontype < 128U)
        {
            cell = &bitmap->highmask;
            mask = (uint64_t)1 << (extensiontype - 64U);
        }
        else if (extensiontype < 192U)
        {
            cell = &bitmap->psk_ke_mask;
            mask = (uint64_t)1 << (extensiontype - 128U);
        }
        else
        {
            cell = &bitmap->tailmask;
            mask = (uint64_t)1 << ((extensiontype - 192U) & 63U);
        }

        if ((*cell & mask) == 0U)
        {
            *cell |= mask;
            added = true;
        }
    }

    return added;
}

bool qsc_tls_extensions_is_permitted(qsc_tls_handshake_type message, qsc_tls_extension_type extensiontype)
{
    /* per RFC 9846 Section 4.3 extension-message applicability table */
    bool res;

    res = false;

    switch (extensiontype)
    {
        case qsc_tls_extension_server_name:
        {
            res = (message == qsc_tls_handshake_type_client_hello || message == qsc_tls_handshake_type_encrypted_extensions);
            break;
        }
        case qsc_tls_extension_supported_groups:
        {
            res = (message == qsc_tls_handshake_type_client_hello || message == qsc_tls_handshake_type_encrypted_extensions);
            break;
        }
        case qsc_tls_extension_signature_algorithms:
        case qsc_tls_extension_signature_algorithms_cert:
        {
            res = (message == qsc_tls_handshake_type_client_hello || message == qsc_tls_handshake_type_certificate_request);
            break;
        }
        case qsc_tls_extension_application_layer_protocol_negotiation:
        {
            res = (message == qsc_tls_handshake_type_client_hello || message == qsc_tls_handshake_type_encrypted_extensions);
            break;
        }
        case qsc_tls_extension_supported_versions:
        {
            /* in ClientHello + ServerHello (and HRR which is a pseudo-ServerHello) */
            res = (message == qsc_tls_handshake_type_client_hello || message == qsc_tls_handshake_type_server_hello);
            break;
        }
        case qsc_tls_extension_cookie:
        {
            /* ClientHello2 only; HRR is validated by its dedicated parser. */
            res = (message == qsc_tls_handshake_type_client_hello);
            break;
        }
        case qsc_tls_extension_psk_key_exchange_modes:
        {
            res = (message == qsc_tls_handshake_type_client_hello);
            break;
        }
        case qsc_tls_extension_key_share:
        {
            res = (message == qsc_tls_handshake_type_client_hello || message == qsc_tls_handshake_type_server_hello);
            break;
        }
        case qsc_tls_extension_pre_shared_key:
        {
            res = (message == qsc_tls_handshake_type_client_hello || message == qsc_tls_handshake_type_server_hello);
            break;
        }
        case qsc_tls_extension_early_data:
        {
            res = (message == qsc_tls_handshake_type_client_hello || message == qsc_tls_handshake_type_encrypted_extensions || message == qsc_tls_handshake_type_new_session_ticket);
            break;
        }
        default:
        {
            break;
        }
    }

    return res;
}

qsc_tls_status qsc_tls_extensions_encode_supported_versions_client(uint8_t* output, size_t outlen, size_t* offset)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);

    size_t hdr;
    size_t inner;
    qsc_tls_status status;

    inner = 0U;
    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_supported_versions, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_begin_u8(output, outlen, offset, &inner);
        }

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_write_u16(output, outlen, offset, QSC_TLS_PROTOCOL_VERSION_13);
        }

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_end_u8(output, outlen, offset, inner);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_supported_versions_server(uint8_t* output, size_t outlen, size_t* offset)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);

    size_t hdr;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_supported_versions, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_write_u16(output, outlen, offset, QSC_TLS_PROTOCOL_VERSION_13);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_cookie(uint8_t* output, size_t outlen, size_t* offset, const uint8_t* cookie, size_t cookielen)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);
    QSC_ASSERT(cookie != NULL);

    size_t hdr;
    qsc_tls_status status;

    hdr = 0U;
    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL && cookie != NULL && cookielen != 0U && cookielen <= UINT16_MAX)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_cookie, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_write_vector16(output, outlen, offset, cookie, cookielen);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_supported_groups(uint8_t* output, size_t outlen, size_t* offset, const qsc_tls_named_group* groups, size_t groupcount)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);

    size_t hdr;
    size_t i;
    size_t inner;
    qsc_tls_status status;

    inner = 0U;
    status = qsc_tls_status_invalid_input;

    if (groups != NULL && groupcount != 0U)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_supported_groups, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_begin_u16(output, outlen, offset, &inner);
        }

        for (i = 0U; i < groupcount && status == qsc_tls_status_success; ++i)
        {
            status = qsc_tls_codec_write_u16(output, outlen, offset, (uint16_t)groups[i]);
        }

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_end_u16(output, outlen, offset, inner);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_signature_algorithms(uint8_t* output, size_t outlen, size_t* offset, const qsc_tls_signature_scheme* schemes, size_t schemecount)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);
    QSC_ASSERT(schemes != NULL);

    size_t hdr;
    size_t inner;
    size_t i;
    qsc_tls_status status;

    inner = 0U;
    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL && schemes != NULL && schemecount != 0U)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_signature_algorithms, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_begin_u16(output, outlen, offset, &inner);
        }

        for (i = 0U; i < schemecount && status == qsc_tls_status_success; ++i)
        {
            status = qsc_tls_codec_write_u16(output, outlen, offset, (uint16_t)schemes[i]);
        }

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_end_u16(output, outlen, offset, inner);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_signature_algorithms_cert(uint8_t* output, size_t outlen, size_t* offset, const qsc_tls_signature_scheme* schemes, size_t schemecount)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);
    QSC_ASSERT(schemes != NULL);

    size_t hdr;
    size_t inner;
    size_t i;
    qsc_tls_status status;

    inner = 0U;
    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL && schemes != NULL && schemecount != 0U)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_signature_algorithms_cert, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_begin_u16(output, outlen, offset, &inner);
        }

        for (i = 0U; i < schemecount && status == qsc_tls_status_success; ++i)
        {
            status = qsc_tls_codec_write_u16(output, outlen, offset, (uint16_t)schemes[i]);
        }

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_end_u16(output, outlen, offset, inner);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_key_share_client(uint8_t* output, size_t outlen, size_t* offset, qsc_tls_named_group group, const uint8_t* publicshare, size_t publicsharelen)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);
    QSC_ASSERT(publicshare != NULL);

    size_t hdr;
    size_t listhdr;
    qsc_tls_status status;

    listhdr = 0U;
    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL && publicshare != NULL && publicsharelen != 0U)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_key_share, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_begin_u16(output, outlen, offset, &listhdr);
        }

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_write_u16(output, outlen, offset, (uint16_t)group);
        }

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_write_vector16(output, outlen, offset, publicshare, publicsharelen);
        }

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_end_u16(output, outlen, offset, listhdr);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_key_share_server(uint8_t* output, size_t outlen, size_t* offset, qsc_tls_named_group group, const uint8_t* publicshare, size_t publicsharelen)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);
    QSC_ASSERT(publicshare != NULL);

    size_t hdr;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL && publicshare != NULL && publicsharelen != 0U)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_key_share, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_write_u16(output, outlen, offset, (uint16_t)group);
        }

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_write_vector16(output, outlen, offset, publicshare, publicsharelen);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_key_share_hello_retry(uint8_t* output, size_t outlen, size_t* offset, qsc_tls_named_group group)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);

    size_t hdr;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_key_share, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_write_u16(output, outlen, offset, (uint16_t)group);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_server_name(uint8_t* output, size_t outlen, size_t* offset, const char* hostname)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);
    QSC_ASSERT(hostname != NULL);

    size_t hdr;
    size_t listhdr;
    size_t hostlen;
    qsc_tls_status status;

    listhdr = 0U;
    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL && hostname != NULL)
    {
        hostlen = qsc_stringutils_string_size(hostname);

        if (hostlen != 0U && hostlen <= QSC_TLS_MAX_HOSTNAME_SIZE)
        {
            status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_server_name, &hdr);

            if (status == qsc_tls_status_success)
            {
                status = qsc_tls_codec_vector_begin_u16(output, outlen, offset, &listhdr);
            }

            if (status == qsc_tls_status_success)
            {
                status = qsc_tls_codec_write_u8(output, outlen, offset, 0U);
            }

            if (status == qsc_tls_status_success)
            {
                status = qsc_tls_codec_write_vector16(output, outlen, offset, (const uint8_t*)hostname, hostlen);
            }

            if (status == qsc_tls_status_success)
            {
                status = qsc_tls_codec_vector_end_u16(output, outlen, offset, listhdr);
            }

            if (status == qsc_tls_status_success)
            {
                status = ext_end(output, outlen, offset, hdr);
            }
        }
        else
        {
            status = qsc_tls_status_invalid_length;
        }
    }

    return status;
}

static bool tls_extensions_alpn_protocol_equal(const uint8_t* left, size_t leftlen, const uint8_t* right, size_t rightlen)
{
    bool res;

    res = false;

    if (left != NULL && right != NULL && leftlen == rightlen)
    {
        res = (qsc_memutils_are_equal(left, right, leftlen) == true);
    }

    return res;
}

qsc_tls_status qsc_tls_extensions_encode_alpn(uint8_t* output, size_t outlen, size_t* offset, const qsc_tls_alpn_protocols* alpn)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);
    QSC_ASSERT(alpn != NULL);

    size_t hdr;
    size_t listhdr;
    size_t i;
    qsc_tls_status status;

    hdr = 0U;
    listhdr = 0U;
    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL && alpn != NULL && alpn->protocolcount != 0U && alpn->protocolcount <= QSC_TLS_MAX_ALPN_PROTOCOLS)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_application_layer_protocol_negotiation, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_begin_u16(output, outlen, offset, &listhdr);
        }

        for (i = 0U; i < alpn->protocolcount && status == qsc_tls_status_success; ++i)
        {
            if (alpn->protocollens[i] != 0U && alpn->protocollens[i] <= QSC_TLS_MAX_ALPN_SIZE)
            {
                status = qsc_tls_codec_write_vector8(output, outlen, offset, alpn->protocols[i], alpn->protocollens[i]);
            }
            else
            {
                status = qsc_tls_status_invalid_length;
            }
        }

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_end_u16(output, outlen, offset, listhdr);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_alpn(const uint8_t* input, size_t inplen, qsc_tls_alpn_protocols* alpn)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(alpn != NULL);

    const uint8_t* list;
    const uint8_t* proto;
    size_t listlen;
    size_t protolen;
    size_t off;
    size_t count;
    size_t i;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (input != NULL && alpn != NULL)
    {
        qsc_memutils_clear(alpn, sizeof(*alpn));
        off = 0U;
        count = 0U;
        status = qsc_tls_codec_read_vector16_span(input, inplen, &off, &list, &listlen);

        if (status == qsc_tls_status_success)
        {
            if (off != inplen || listlen == 0U)
            {
                status = qsc_tls_status_invalid_length;
            }
        }

        off = 0U;

        while (status == qsc_tls_status_success && off < listlen)
        {
            status = qsc_tls_codec_read_vector8_span(list, listlen, &off, &proto, &protolen);

            if (status == qsc_tls_status_success)
            {
                if (protolen == 0U || protolen > QSC_TLS_MAX_ALPN_SIZE || count >= QSC_TLS_MAX_ALPN_PROTOCOLS)
                {
                    status = qsc_tls_status_invalid_length;
                }
            }

            if (status == qsc_tls_status_success)
            {
                for (i = 0U; i < count; ++i)
                {
                    if (tls_extensions_alpn_protocol_equal(alpn->protocols[i], alpn->protocollens[i], proto, protolen) == true)
                    {
                        status = qsc_tls_status_invalid_message;
                        break;
                    }
                }
            }

            if (status == qsc_tls_status_success)
            {
                qsc_memutils_copy(alpn->protocols[count], proto, protolen);
                alpn->protocollens[count] = protolen;
                count += 1U;
            }
        }

        if (status == qsc_tls_status_success)
        {
            alpn->protocolcount = count;
            alpn->configured = (count != 0U);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_select_alpn(const qsc_tls_alpn_protocols* clientalpn, const qsc_tls_alpn_protocols* serveralpn, uint8_t* selected, size_t selectedcap, size_t* selectedlen)
{
    QSC_ASSERT(clientalpn != NULL);
    QSC_ASSERT(serveralpn != NULL);
    QSC_ASSERT(selected != NULL);
    QSC_ASSERT(selectedlen != NULL);

    size_t i;
    size_t j;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (clientalpn != NULL && serveralpn != NULL && selected != NULL && selectedlen != NULL)
    {
        *selectedlen = 0U;
        status = qsc_tls_status_not_supported;

        for (i = 0U; i < serveralpn->protocolcount && status != qsc_tls_status_success; ++i)
        {
            for (j = 0U; j < clientalpn->protocolcount; ++j)
            {
                if (tls_extensions_alpn_protocol_equal(serveralpn->protocols[i], serveralpn->protocollens[i], clientalpn->protocols[j], clientalpn->protocollens[j]) == true)
                {
                    if (serveralpn->protocollens[i] <= selectedcap)
                    {
                        qsc_memutils_copy(selected, serveralpn->protocols[i], serveralpn->protocollens[i]);
                        *selectedlen = serveralpn->protocollens[i];
                        status = qsc_tls_status_success;
                    }
                    else
                    {
                        status = qsc_tls_status_invalid_length;
                    }

                    break;
                }
            }
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_psk_key_exchange_modes(uint8_t* output, size_t outlen, size_t* offset, const uint8_t* modes, size_t modecount)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);
    QSC_ASSERT(modes != NULL);

    size_t hdr;
    size_t inner;
    size_t i;
    qsc_tls_status status;

    inner = 0U;
    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL && modes != NULL && modecount != 0U)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_psk_key_exchange_modes, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_begin_u8(output, outlen, offset, &inner);
        }

        for (i = 0U; i < modecount && status == qsc_tls_status_success; ++i)
        {
            status = qsc_tls_codec_write_u8(output, outlen, offset, modes[i]);
        }

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_vector_end_u8(output, outlen, offset, inner);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_supported_versions_client(const uint8_t* input, size_t inplen, bool* acceptstls13)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(acceptstls13 != NULL);

    const uint8_t* list;
    size_t listlen;
    size_t i;
    size_t off;
    uint16_t version;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (input != NULL && acceptstls13 != NULL)
    {
        *acceptstls13 = false;
        list = NULL;
        listlen = 0U;
        off = 0U;

        status = qsc_tls_codec_read_vector8_span(input, inplen, &off, &list, &listlen);

        if (status == qsc_tls_status_success)
        {
            if (off != inplen || list == NULL || listlen < 2U || listlen > 254U || (listlen % 2U) != 0U)
            {
                status = qsc_tls_status_invalid_length;
            }
            else
            {
                for (i = 0U; i < listlen; i += 2U)
                {
                    version = qsc_intutils_be8to16(list + i);

                    if (version == QSC_TLS_PROTOCOL_VERSION_13)
                    {
                        *acceptstls13 = true;
                        break;
                    }
                }
            }
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_supported_versions_server(const uint8_t* input, size_t inplen, uint16_t* selectedversion)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(selectedversion != NULL);

    size_t oft;
    qsc_tls_status status;

    oft = 0U;
    status = qsc_tls_status_invalid_input;

    if (input != NULL && selectedversion != NULL)
    {
        if (inplen == 2U)
        {
            status = qsc_tls_codec_read_u16(input, inplen, &oft, selectedversion);
        }
        else
        {
            status = qsc_tls_status_invalid_length;
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_cookie(const uint8_t* input, size_t inplen,
    const uint8_t** cookie, size_t* cookielen)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(cookie != NULL);
    QSC_ASSERT(cookielen != NULL);

    size_t off;
    qsc_tls_status status;

    off = 0U;
    status = qsc_tls_status_invalid_input;

    if (input != NULL && cookie != NULL && cookielen != NULL)
    {
        *cookie = NULL;
        *cookielen = 0U;
        status = qsc_tls_codec_read_vector16_span(input, inplen, &off, cookie, cookielen);

        if (status == qsc_tls_status_success)
        {
            if (off != inplen || *cookie == NULL || *cookielen == 0U)
            {
                status = qsc_tls_status_invalid_length;
            }
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_supported_groups(const uint8_t* input, size_t inplen, qsc_tls_named_group* groups, size_t groupcapacity, size_t* groupcount)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(groups != NULL);
    QSC_ASSERT(groupcount != NULL);

    const uint8_t* list;
    size_t listlen;
    size_t i;
    size_t n;
    size_t off;
    qsc_tls_status status;

    list = NULL;
    listlen = 0U;
    i = 0U;
    n = 0U;
    off = 0U;
    status = qsc_tls_status_invalid_input;

    if (input != NULL && groups != NULL && groupcount != NULL)
    {
        *groupcount = 0U;
        status = qsc_tls_codec_read_vector16_span(input, inplen, &off, &list, &listlen);

        if (status == qsc_tls_status_success)
        {
            if (off != inplen || list == NULL || listlen < 2U || (listlen % 2U) != 0U)
            {
                status = qsc_tls_status_invalid_length;
            }
            else
            {
                for (i = 0U; i < listlen && status == qsc_tls_status_success; i += 2U)
                {
                    if (n < groupcapacity)
                    {
                        groups[n] = (qsc_tls_named_group)qsc_intutils_be8to16(list + i);
                        ++n;
                    }
                    else
                    {
                        status = qsc_tls_status_invalid_length;
                    }
                }

                if (status == qsc_tls_status_success)
                {
                    *groupcount = n;
                }
            }
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_signature_algorithms(const uint8_t* input, size_t inplen, qsc_tls_signature_scheme* schemes, size_t schemecapacity, size_t* schemecount)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(schemes != NULL);
    QSC_ASSERT(schemecount != NULL);

    const uint8_t* list;
    size_t listlen;
    size_t i;
    size_t n;
    size_t off;
    qsc_tls_status status;

    list = NULL;
    listlen = 0U;
    i = 0U;
    n = 0U;
    off = 0U;
    status = qsc_tls_status_invalid_input;

    if (input != NULL && schemes != NULL && schemecount != NULL)
    {
        *schemecount = 0U;
        status = qsc_tls_codec_read_vector16_span(input, inplen, &off, &list, &listlen);

        if (status == qsc_tls_status_success)
        {
            if (off != inplen || list == NULL || listlen < 2U || (listlen % 2U) != 0U)
            {
                status = qsc_tls_status_invalid_length;
            }
            else
            {
                for (i = 0U; i < listlen && status == qsc_tls_status_success; i += 2U)
                {
                    if (n < schemecapacity)
                    {
                        schemes[n] = (qsc_tls_signature_scheme)qsc_intutils_be8to16(list + i);
                        ++n;
                    }
                    else
                    {
                        status = qsc_tls_status_invalid_length;
                    }
                }

                if (status == qsc_tls_status_success)
                {
                    *schemecount = n;
                }
            }
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_key_share_client_hello(const uint8_t* input, size_t inplen, qsc_tls_named_group* groups, const uint8_t** shares, size_t* sharelens, size_t capacity, size_t* count)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(groups != NULL);
    QSC_ASSERT(shares != NULL);
    QSC_ASSERT(sharelens != NULL);
    QSC_ASSERT(count != NULL);

    const uint8_t* list;
    size_t i;
    size_t j;
    size_t listlen;
    size_t n;
    size_t off;
    uint16_t gid;
    uint16_t sharelen;
    bool duplicate;
    qsc_tls_status status;

    list = NULL;
    i = 0U;
    j = 0U;
    listlen = 0U;
    n = 0U;
    off = 0U;
    gid = 0U;
    sharelen = 0U;
    duplicate = false;
    status = qsc_tls_status_invalid_input;

    if (input != NULL && groups != NULL && shares != NULL && sharelens != NULL && count != NULL)
    {
        *count = 0U;
        status = qsc_tls_codec_read_vector16_span(input, inplen, &off, &list, &listlen);

        if (status == qsc_tls_status_success && off != inplen)
        {
            status = qsc_tls_status_invalid_length;
        }

        i = 0U;

        while (status == qsc_tls_status_success && i < listlen)
        {
            if ((listlen - i) < 4U)
            {
                status = qsc_tls_status_invalid_length;
            }
            else
            {
                gid = qsc_intutils_be8to16(list + i);
                i += 2U;
                sharelen = qsc_intutils_be8to16(list + i);
                i += 2U;

                if (sharelen == 0U || (size_t)sharelen > (listlen - i))
                {
                    status = qsc_tls_status_invalid_length;
                }
                else if (n >= capacity)
                {
                    status = qsc_tls_status_invalid_length;
                }
                else
                {
                    duplicate = false;

                    for (j = 0U; j < n; ++j)
                    {
                        if ((uint16_t)groups[j] == gid)
                        {
                            duplicate = true;
                            break;
                        }
                    }

                    if (duplicate == true)
                    {
                        status = qsc_tls_status_invalid_message;
                    }
                    else
                    {
                        groups[n] = (qsc_tls_named_group)gid;
                        shares[n] = list + i;
                        sharelens[n] = (size_t)sharelen;
                        i += (size_t)sharelen;
                        ++n;
                    }
                }
            }
        }

        if (status == qsc_tls_status_success && i != listlen)
        {
            status = qsc_tls_status_invalid_length;
        }

        if (status == qsc_tls_status_success)
        {
            *count = n;
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_key_share_server_hello(const uint8_t* input, size_t inplen, qsc_tls_named_group* selectedgroup, const uint8_t** share, size_t* sharelen)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(selectedgroup != NULL);
    QSC_ASSERT(share != NULL);
    QSC_ASSERT(sharelen != NULL);

    size_t off;
    uint16_t gid;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (input != NULL && selectedgroup != NULL && share != NULL && sharelen != NULL)
    {
        *share = NULL;
        *sharelen = 0U;
        off = 0U;
        status = qsc_tls_codec_read_u16(input, inplen, &off, &gid);

        if (status == qsc_tls_status_success)
        {
            *selectedgroup = (qsc_tls_named_group)gid;
            status = qsc_tls_codec_read_vector16_span(input, inplen, &off, share, sharelen);

            if (status == qsc_tls_status_success && off != inplen)
            {
                status = qsc_tls_status_invalid_length;
            }
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_key_share_hello_retry(const uint8_t* input, size_t inplen, qsc_tls_named_group* requestedgroup)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(requestedgroup != NULL);

    size_t off;
    uint16_t gid;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (input != NULL && requestedgroup != NULL)
    {
        if (inplen == 2U)
        {
            off = 0U;
            status = qsc_tls_codec_read_u16(input, inplen, &off, &gid);

            if (status == qsc_tls_status_success)
            {
                *requestedgroup = (qsc_tls_named_group)gid;
            }
        }
        else
        {
            status = qsc_tls_status_invalid_length;
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_server_name(const uint8_t* input, size_t inplen, const char** hostname, size_t* hostnamelen)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(hostname != NULL);
    QSC_ASSERT(hostnamelen != NULL);

    const uint8_t* hostspan;
    const uint8_t* list;
    size_t hostspanlen;
    size_t i;
    size_t inneroff;
    size_t listlen;
    size_t off;
    uint8_t nametype;
    bool foundhost;
    qsc_tls_status status;

    hostspan = NULL;
    list = NULL;
    hostspanlen = 0U;
    i = 0U;
    inneroff = 0U;
    listlen = 0U;
    off = 0U;
    nametype = 0U;
    foundhost = false;
    status = qsc_tls_status_invalid_input;

    if (input != NULL && hostname != NULL && hostnamelen != NULL)
    {
        *hostname = NULL;
        *hostnamelen = 0U;
        status = qsc_tls_codec_read_vector16_span(input, inplen, &off, &list, &listlen);

        if (status == qsc_tls_status_success)
        {
            if (off != inplen || list == NULL || listlen == 0U)
            {
                status = qsc_tls_status_invalid_length;
            }
        }

        while (status == qsc_tls_status_success && inneroff < listlen)
        {
            status = qsc_tls_codec_read_u8(list, listlen, &inneroff, &nametype);

            if (status == qsc_tls_status_success)
            {
                status = qsc_tls_codec_read_vector16_span(list, listlen, &inneroff, &hostspan, &hostspanlen);
            }

            if (status == qsc_tls_status_success && nametype == 0U)
            {
                if (foundhost == true)
                {
                    status = qsc_tls_status_invalid_message;
                }
                else if (hostspan == NULL || hostspanlen == 0U || hostspanlen > QSC_TLS_MAX_HOSTNAME_SIZE)
                {
                    status = qsc_tls_status_invalid_length;
                }
                else
                {
                    for (i = 0U; i < hostspanlen; ++i)
                    {
                        if (hostspan[i] == 0U || hostspan[i] > 0x7FU)
                        {
                            status = qsc_tls_status_invalid_message;
                            break;
                        }
                    }

                    if (status == qsc_tls_status_success)
                    {
                        *hostname = (const char*)hostspan;
                        *hostnamelen = hostspanlen;
                        foundhost = true;
                    }
                }
            }
        }

        if (status == qsc_tls_status_success && inneroff != listlen)
        {
            status = qsc_tls_status_invalid_length;
        }

        if (status == qsc_tls_status_success && foundhost == false)
        {
            status = qsc_tls_status_not_supported;
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_select_cipher_suite(const uint8_t* clientsuites, size_t clientsuiteslen, const qsc_tls_cipher_suite* serverpreference, size_t serverpreferencecount, qsc_tls_cipher_suite* selected)
{
    QSC_ASSERT(clientsuites != NULL);
    QSC_ASSERT(serverpreference != NULL);
    QSC_ASSERT(selected != NULL);

    size_t i;
    size_t j;
    uint16_t v;
    qsc_tls_status status;

    status = qsc_tls_status_not_supported;

    if (clientsuites != NULL && serverpreference != NULL && selected != NULL)
    {
        if ((clientsuiteslen % 2U) == 0U)
        {
            *selected = qsc_tls_cipher_suite_none;

            for (i = 0U; i < serverpreferencecount; ++i)
            {
                for (j = 0U; j + 2U <= clientsuiteslen; j += 2U)
                {
                    v = qsc_intutils_be8to16(clientsuites + j);

                    if ((uint16_t)serverpreference[i] == v)
                    {
                        *selected = serverpreference[i];

                        return qsc_tls_status_success;
                    }
                }
            }
        }
        else
        {
            status = qsc_tls_status_invalid_length;
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_select_key_share(const qsc_tls_named_group* groups, size_t groupcount, const qsc_tls_named_group* serverpreference, size_t serverpreferencecount, qsc_tls_named_group* selected)
{
    size_t i;
    size_t j;

    if (groups == NULL || serverpreference == NULL || selected == NULL)
    {
        return qsc_tls_status_invalid_input;
    }

    *selected = qsc_tls_group_none;

    for (i = 0U; i < serverpreferencecount; ++i)
    {
        for (j = 0U; j < groupcount; ++j)
        {
            if (serverpreference[i] == groups[j])
            {
                *selected = serverpreference[i];
                return qsc_tls_status_success;
            }
        }
    }

    return qsc_tls_status_not_supported;
}

qsc_tls_status qsc_tls_extensions_encode_early_data_empty(uint8_t* output, size_t outlen, size_t* offset)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);

    size_t hdr;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_early_data, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_early_data_max(uint8_t* output, size_t outlen, size_t* offset, uint32_t maxearlydatasize)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);

    size_t hdr;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_early_data, &hdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_write_u32(output, outlen, offset, maxearlydatasize);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, hdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_early_data_max(const uint8_t* input, size_t inplen, uint32_t* maxearlydatasize)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(maxearlydatasize != NULL);

    size_t oft;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (input != NULL && maxearlydatasize != NULL)
    {
        if (inplen == 4U)
        {
            oft = 0U;
            status = qsc_tls_codec_read_u32(input, inplen, &oft, maxearlydatasize);
        }
        else
        {
            status = qsc_tls_status_invalid_length;
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_pre_shared_key_offer(uint8_t* output, size_t outlen, size_t* offset, const qsc_tls_psk_identity_view* identities, size_t identitycount, size_t binderlen, size_t* binderoffset)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);
    QSC_ASSERT(identities != NULL);
    QSC_ASSERT(binderoffset != NULL);

    size_t exthdr;
    size_t idhdr;
    size_t binderhdr;
    size_t i;
    qsc_tls_status status;
    bool identitiesvalid;

    i = 0U;
    identitiesvalid = true;
    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL && identities != NULL && identitycount != 0U && binderoffset != NULL)
    {
        for (i = 0U; i < identitycount && identitiesvalid == true; ++i)
        {
            identitiesvalid = (identities[i].identity != NULL && identities[i].identitylen != 0U && identities[i].identitylen <= UINT16_MAX);
        }

        if (identitiesvalid == true && binderlen >= 32U && binderlen <= 255U)
        {
            status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_pre_shared_key, &exthdr);

            if (status == qsc_tls_status_success)
            {
                status = qsc_tls_codec_vector_begin_u16(output, outlen, offset, &idhdr);

                for (i = 0U; status == qsc_tls_status_success && i < identitycount; ++i)
                {
                    status = qsc_tls_codec_write_vector16(output, outlen, offset, identities[i].identity, identities[i].identitylen);

                    if (status == qsc_tls_status_success)
                    {
                        status = qsc_tls_codec_write_u32(output, outlen, offset, identities[i].obfuscatedticketage);
                    }
                }

                if (status == qsc_tls_status_success)
                {
                    status = qsc_tls_codec_vector_end_u16(output, outlen, offset, idhdr);
                }

                if (status == qsc_tls_status_success)
                {
                    /* binders<33..2^16-1> - vector of opaque<1..255> Emit zero placeholders */
                    status = qsc_tls_codec_vector_begin_u16(output, outlen, offset, &binderhdr);

                    if (status == qsc_tls_status_success)
                    {
                        /* record offset of first binder byte Layout: 1-byte length + binderlen bytes */
                        *binderoffset = *offset + 1U;

                        for (i = 0U; status == qsc_tls_status_success && i < identitycount; ++i)
                        {
                            if (*offset + 1U + binderlen > outlen)
                            {
                                status = qsc_tls_status_buffer_too_small; break;
                            }

                            output[*offset] = (uint8_t)binderlen;
                            *offset += 1U;
                            qsc_memutils_clear(output + *offset, binderlen);
                            *offset += binderlen;
                        }

                        if (status == qsc_tls_status_success)
                        {
                            status = qsc_tls_codec_vector_end_u16(output, outlen, offset, binderhdr);
                        }

                        if (status == qsc_tls_status_success)
                        {
                            status = ext_end(output, outlen, offset, exthdr);
                        }
                    }
                }
            }
        }
        else
        {
            status = qsc_tls_status_invalid_length;
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_encode_pre_shared_key_server(uint8_t* output, size_t outlen, size_t* offset, uint16_t selidentity)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(offset != NULL);

    size_t exthdr;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (output != NULL && offset != NULL)
    {
        status = ext_begin(output, outlen, offset, (uint16_t)qsc_tls_extension_pre_shared_key, &exthdr);

        if (status == qsc_tls_status_success)
        {
            status = qsc_tls_codec_write_u16(output, outlen, offset, selidentity);
        }

        if (status == qsc_tls_status_success)
        {
            status = ext_end(output, outlen, offset, exthdr);
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_pre_shared_key_offer(const uint8_t* input, size_t inplen, qsc_tls_psk_identity_view* identities, const uint8_t** binders, size_t* binderlens, size_t capacity, size_t* count, size_t* binderblockoffset)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(identities != NULL);
    QSC_ASSERT(binders != NULL);
    QSC_ASSERT(binderlens != NULL);
    QSC_ASSERT(count != NULL);
    QSC_ASSERT(binderblockoffset != NULL);

    const uint8_t* binderblock;
    const uint8_t* idblock;
    size_t binderblocklen;
    size_t binderidx;
    size_t binderoft;
    size_t idblocklen;
    size_t ididx;
    size_t idoft;
    size_t oft;
    qsc_tls_status status;

    status = qsc_tls_status_invalid_input;

    if (input != NULL && identities != NULL && binders != NULL && binderlens != NULL && count != NULL && binderblockoffset != NULL)
    {
        *count = 0U;
        *binderblockoffset = 0U;
        oft = 0U;
        status = qsc_tls_codec_read_vector16_span(input, inplen, &oft, &idblock, &idblocklen);

        if (status == qsc_tls_status_success && idblocklen < 7U)
        {
            status = qsc_tls_status_invalid_length;
        }

        if (status == qsc_tls_status_success)
        {
            /* record absolute offset of the binder-block length prefix (2 bytes before binders) */
            *binderblockoffset = oft;
            status = qsc_tls_codec_read_vector16_span(input, inplen, &oft, &binderblock, &binderblocklen);

            if (status == qsc_tls_status_success && binderblocklen < 33U)
            {
                status = qsc_tls_status_invalid_length;
            }

            if (status == qsc_tls_status_success)
            {
                if (oft == inplen)
                {
                    /* walk identities */
                    ididx = 0U;
                    idoft = 0U;

                    while (idoft < idblocklen)
                    {
                        const uint8_t* id;
                        size_t idlen;
                        uint32_t age;

                        status = qsc_tls_codec_read_vector16_span(idblock, idblocklen, &idoft, &id, &idlen);

                        if (status != qsc_tls_status_success)
                        {
                            return status;
                        }

                        if (id == NULL || idlen == 0U)
                        {
                            return qsc_tls_status_invalid_length;
                        }

                        status = qsc_tls_codec_read_u32(idblock, idblocklen, &idoft, &age);

                        if (status != qsc_tls_status_success)
                        {
                            return status;
                        }

                        if (ididx >= capacity)
                        {
                            return qsc_tls_status_invalid_length;
                        }

                        identities[ididx].identity = id;
                        identities[ididx].identitylen = idlen;
                        identities[ididx].obfuscatedticketage = age;
                        ++ididx;
                    }

                    /* walk binders */
                    binderidx = 0U;
                    binderoft = 0U;

                    while (binderoft < binderblocklen)
                    {
                        const uint8_t* b;
                        size_t blen;

                        status = qsc_tls_codec_read_vector8_span(binderblock, binderblocklen, &binderoft, &b, &blen);

                        if (status != qsc_tls_status_success)
                        {
                            return status;
                        }

                        if (b == NULL || blen < 32U || blen > 255U)
                        {
                            return qsc_tls_status_invalid_length;
                        }

                        if (binderidx >= capacity)
                        {
                            return qsc_tls_status_invalid_length;
                        }

                        binders[binderidx] = b;
                        binderlens[binderidx] = blen;
                        ++binderidx;
                    }

                    if (ididx != binderidx)
                    {
                        return qsc_tls_status_invalid_message;
                    }

                    *count = ididx;
                }
                else
                {
                    status = qsc_tls_status_invalid_length;
                }
            }
        }
    }

    return status;
}

qsc_tls_status qsc_tls_extensions_decode_pre_shared_key_server(const uint8_t* input, size_t inplen, uint16_t* selidentity)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(selidentity != NULL);

    qsc_tls_status status;
    size_t oft;

    status = qsc_tls_status_invalid_input;

    if (input != NULL && selidentity != NULL)
    {
        if (inplen == 2U)
        {
            oft = 0U;
            status = qsc_tls_codec_read_u16(input, inplen, &oft, selidentity);
        }
        else
        {
            status = qsc_tls_status_invalid_length;
        }
    }

    return status;
}
