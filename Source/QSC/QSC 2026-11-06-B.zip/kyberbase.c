/* 2020-2026 Quantum Resistant Cryptographic Solutions Corporation
 * All Rights Reserved.
 *
 * NOTICE:
 * This software and all accompanying materials are the exclusive property of
 * Quantum Resistant Cryptographic Solutions Corporation (QRCS). The intellectual
 * and technical concepts contained herein are proprietary to QRCS and are
 * protected under applicable Canadian, U.S., and international copyright,
 * patent, and trade secret laws.
 *
 * CRYPTOGRAPHIC ALGORITHMS AND IMPLEMENTATIONS:
 * - This software includes implementations of cryptographic primitives and
 *   algorithms that are standardized or in the public domain, such as AES
 *   and SHA-3, which are not proprietary to QRCS.
 * - This software also includes cryptographic primitives, constructions, and
 *   algorithms designed by QRCS, including but not limited to RCS, SCB, CSX, QMAC, and
 *   related components, which are proprietary to QRCS.
 * - All source code, implementations, protocol compositions, optimizations,
 *   parameter selections, and engineering work contained in this software are
 *   original works of QRCS and are protected under this license.
 *
 * LICENSE AND USE RESTRICTIONS:
 * - This software is licensed under the Quantum Resistant Cryptographic Solutions
 *   Public Research and Evaluation License (QRCS-PREL), 2025-2026.
 * - Permission is granted solely for non-commercial evaluation, academic research,
 *   cryptographic analysis, interoperability testing, and feasibility assessment.
 * - Commercial use, production deployment, commercial redistribution, or
 *   integration into products or services is strictly prohibited without a
 *   separate written license agreement executed with QRCS.
 * - Licensing and authorized distribution are solely at the discretion of QRCS.
 *
 * EXPERIMENTAL CRYPTOGRAPHY NOTICE:
 * Portions of this software may include experimental, novel, or evolving
 * cryptographic designs. Use of this software is entirely at the user's risk.
 *
 * DISCLAIMER:
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, SECURITY, OR NON-INFRINGEMENT. QRCS DISCLAIMS ALL
 * LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING FROM THE USE OR MISUSE OF THIS SOFTWARE.
 *
 * FULL LICENSE:
 * This software is subject to the Quantum Resistant Cryptographic Solutions
 * Public Research and Evaluation License (QRCS-PREL), 2025-2026. The complete license terms
 * are provided in the accompanying LICENSE file or at https://www.qrcscorp.ca.
 *
 * Written by: John G. Underhill
 * Contact: contact@qrcscorp.ca
 */

#include "kyberbase.h"
#include "intutils.h"
#include "memutils.h"
#include "sha3.h"
#if defined(QSC_SYSTEM_ARM_INTRINSICS)
#	include "intrinsics.h"
#endif

#define KYBER_ZETA_SIZE 128
#define KYBER_MONT 2285U /* 2^16 mod q */
#define KYBER_QINV 62209U /* q^-1 mod 2^16 */
#define KYBER_GEN_MATRIX_NBLOCKS ((12 * QSC_KYBER_N / 8 * (1 << 12) / QSC_KYBER_Q + QSC_KECCAK_128_RATE) / QSC_KECCAK_128_RATE)

static const QSC_CACHE_ALIGNED uint16_t kyber_zetas[KYBER_ZETA_SIZE] =
{
    0xFBEC, 0xFD0A, 0xFE99, 0xFA13, 0x05D5, 0x058E, 0x011F, 0x00CA,
    0xFF55, 0x026E, 0x0629, 0x00B6, 0x03C2, 0xFB4E, 0xFA3E, 0x05BC,
    0x023D, 0xFAD3, 0x0108, 0x017F, 0xFCC3, 0x05B2, 0xF9BE, 0xFF7E,
    0xFD57, 0x03F9, 0x02DC, 0x0260, 0xF9FA, 0x019B, 0xFF33, 0xF9DD,
    0x04C7, 0x028C, 0xFDD8, 0x03F7, 0xFAF3, 0x05D3, 0xFEE6, 0xF9F8,
    0x0204, 0xFFF8, 0xFEC0, 0xFD66, 0xF9AE, 0xFB76, 0x007E, 0x05BD,
    0xFCAB, 0xFFA6, 0xFEF1, 0x033E, 0x006B, 0xFA73, 0xFF09, 0xFC49,
    0xFE72, 0x03C1, 0xFA1C, 0xFD2B, 0x01C0, 0xFBD7, 0x02A5, 0xFB05,
    0xFBB1, 0x01AE, 0x022B, 0x034B, 0xFB1D, 0x0367, 0x060E, 0x0069,
    0x01A6, 0x024B, 0x00B1, 0xFF15, 0xFEDD, 0xFE34, 0x0626, 0x0675,
    0xFF0A, 0x030A, 0x0487, 0xFF6D, 0xFCF7, 0x05CB, 0xFDA6, 0x045F,
    0xF9CA, 0x0284, 0xFC98, 0x015D, 0x01A2, 0x0149, 0xFF64, 0xFFB5,
    0x0331, 0x0449, 0x025B, 0x0262, 0x052A, 0xFAFB, 0xFA47, 0x0180,
    0xFB41, 0xFF78, 0x04C2, 0xFAC9, 0xFC96, 0x00DC, 0xFB5D, 0xF985,
    0xFB5F, 0xFA06, 0xFB02, 0x031A, 0xFA1A, 0xFCAA, 0xFC9A, 0x01DE,
    0xFF94, 0xFECC, 0x03E4, 0x03DF, 0x03BE, 0xFA4C, 0x05F2, 0x065C
};

/* reduce.c */

static int16_t kyber_montgomery_reduce(int32_t a)
{
    int16_t t;

    t = (int16_t)a * KYBER_QINV;
    t = (a - (int32_t)t * QSC_KYBER_Q) >> 16;

    return (int16_t)t;
}

static int16_t kyber_barrett_reduce(int16_t a)
{
    int16_t t;
    const int16_t v = ((1 << 26) + QSC_KYBER_Q / 2) / QSC_KYBER_Q;

    t = ((int32_t)v * a + (1 << 25)) >> 26;
    t *= QSC_KYBER_Q;

    return (a - t);
}

#if defined(QSC_SYSTEM_ARM_INTRINSICS)
/**
 * \brief Multiply eight signed coefficient pairs and apply Montgomery reduction.
 * \param a: [int16x8_t] First coefficient vector.
 * \param b: [int16x8_t] Second coefficient vector.
 * \return Eight products multiplied by 2^-16 modulo 3329, with scalar representatives.
 * \note Reentrant; owns no storage. Uses the arithmetic of pq-crystals/kyber
 * ref/reduce.c at commit 3edd5af5991927164edd4aacebfcbee00b8064e7.
 * https://github.com/pq-crystals/kyber/tree/3edd5af5991927164edd4aacebfcbee00b8064e7/ref
 */
static int16x8_t kyber_fqmul_arm(int16x8_t a, int16x8_t b)
{
	int32x4_t lo;
	int32x4_t hi;
	int16x8_t t;

	lo = vmull_s16(vget_low_s16(a), vget_low_s16(b));
	hi = vmull_s16(vget_high_s16(a), vget_high_s16(b));
	t = vmulq_n_s16(vcombine_s16(vmovn_s32(lo), vmovn_s32(hi)), (int16_t)KYBER_QINV);
	lo = vsubq_s32(lo, vmull_n_s16(vget_low_s16(t), QSC_KYBER_Q));
	hi = vsubq_s32(hi, vmull_n_s16(vget_high_s16(t), QSC_KYBER_Q));

	return vcombine_s16(vshrn_n_s32(lo, 16), vshrn_n_s32(hi, 16));
}

/**
 * \brief Barrett-reduce eight signed coefficients using the scalar rounding rule.
 * \param a: [int16x8_t] Eight signed 16-bit coefficients.
 * \return Centered representatives modulo 3329.
 * \note Reentrant; owns no storage. Follows the same official reference as fqmul.
 */
static int16x8_t kyber_barrett_arm(int16x8_t a)
{
	const int16_t v = ((1 << 26) + QSC_KYBER_Q / 2) / QSC_KYBER_Q;
	int32x4_t lo;
	int32x4_t hi;
	int16x8_t t;

	lo = vmlal_n_s16(vdupq_n_s32(1 << 25), vget_low_s16(a), v);
	hi = vmlal_n_s16(vdupq_n_s32(1 << 25), vget_high_s16(a), v);
	t = vcombine_s16(vmovn_s32(vshrq_n_s32(lo, 26)), vmovn_s32(vshrq_n_s32(hi, 26)));

	return vsubq_s16(a, vmulq_n_s16(t, QSC_KYBER_Q));
}
#endif

/* poly.h */

/**
* \struct qsc_kyber_poly
* \brief Contains an N sized array of 16bit coefficients. /n
* Elements of R_q = Z_q[X] / (X^n + 1). /n
* Represents polynomial coeffs[0] + X * coeffs[1] + X^2 * xoeffs[2] + ... + X^{n-1} * coeffs[n-1]
*
* \var qsc_kyber_poly::coeffs
* The array of 16bit coefficients
*/
typedef struct
{
    int16_t coeffs[QSC_KYBER_N];
} qsc_kyber_poly;

/**
* \struct qsc_kyber_polyvec
* \brief Contains a K sized vector of qsc_kyber_poly structures
*
* \var qsc_kyber_polyvec::vec
* The polynomial vector array
*/
typedef struct
{
    qsc_kyber_poly vec[QSC_KYBER_K];
} qsc_kyber_polyvec;

/* cbd.c */

static void kyber_cbd2(qsc_kyber_poly* r, const uint8_t buf[QSC_KYBER_ETA2 * QSC_KYBER_N / 4U])
{
    uint32_t t;
    uint32_t d;
    int16_t a;
    int16_t b;

    for (size_t i = 0U; i < QSC_KYBER_N / 8U; ++i)
    {
        t = qsc_intutils_le8to32(buf + (4U * i));
        d = t & 0x55555555UL;
        d += (t >> 1) & 0x55555555UL;

        for (size_t j = 0U; j < 8U; ++j)
        {
            a = (int16_t)((d >> (4U * j)) & 0x03U);
            b = (int16_t)((d >> ((4U * j) + 2U)) & 0x03U);
            r->coeffs[(8U * i) + j] = a - b;
        }
    }
}

#if QSC_KYBER_ETA1 == 3
static uint32_t kyber_load24le(const uint8_t x[3U])
{
    uint32_t r;

    r = (uint32_t)x[0U];
    r |= (uint32_t)x[1U] << 8;
    r |= (uint32_t)x[2U] << 16;

    return r;
}

static void kyber_cbd3(qsc_kyber_poly* r, const uint8_t buf[QSC_KYBER_ETA1 * QSC_KYBER_N / 4U])
{
    size_t i;
    size_t j;
    uint32_t t;
    uint32_t d;
    int16_t a;
    int16_t b;

    for (i = 0U; i < QSC_KYBER_N / 4U; i++)
    {
        t = kyber_load24le(buf + 3U * i);
        d = t & 0x00249249;
        d += (t >> 1) & 0x00249249;
        d += (t >> 2) & 0x00249249;

        for (j = 0U; j < 4U; ++j)
        {
            a = (d >> (6U * j)) & 0x07;
            b = (d >> (6U * j + 3U)) & 0x07;
            r->coeffs[4U * i + j] = a - b;
        }
    }
}
#endif

/* kyber_ntt.c */

static int16_t kyber_fqmul(int16_t a, int16_t b)
{
    return kyber_montgomery_reduce((int32_t)a * b);
}

static void kyber_ntt(int16_t r[QSC_KYBER_N])
{
    size_t j;
    size_t k;
    int16_t t;
    int16_t zeta;

    k = 1U;

    for (size_t len = 128U; len >= 2U; len >>= 1U)
    {
        for (size_t start = 0; start < QSC_KYBER_N; start = (j + len))
        {
            zeta = (int16_t)kyber_zetas[k];
            ++k;

			j = start;
#if defined(QSC_SYSTEM_ARM_INTRINSICS)
			for (; j + 8U <= start + len; j += 8U)
			{
				int16x8_t a;
				int16x8_t b;
				int16x8_t c;

				a = vld1q_s16(r + j);
				b = vld1q_s16(r + j + len);
				c = kyber_fqmul_arm(vdupq_n_s16(zeta), b);
				vst1q_s16(r + j + len, vsubq_s16(a, c));
				vst1q_s16(r + j, vaddq_s16(a, c));
			}
#endif
			for (; j < start + len; ++j)
            {
                t = kyber_fqmul(zeta, r[j + len]);
                r[j + len] = r[j] - t;
                r[j] = r[j] + t;
            }
        }
    }
}

static void kyber_invntt(int16_t r[256U])
{
    size_t j;
    size_t k;
    int16_t t;
    int16_t zeta;
    const int16_t F = 1441;

    k = 127U;

    for (size_t len = 2U; len <= 128U; len <<= 1U)
    {
        for (size_t start = 0U; start < 256U; start = j + len)
        {
            zeta = (int16_t)kyber_zetas[k];
            --k;

			j = start;
#if defined(QSC_SYSTEM_ARM_INTRINSICS)
			for (; j + 8U <= start + len; j += 8U)
			{
				int16x8_t a;
				int16x8_t b;
				int16x8_t c;

				a = vld1q_s16(r + j);
				b = vld1q_s16(r + j + len);
				c = kyber_barrett_arm(vaddq_s16(a, b));
				b = kyber_fqmul_arm(vdupq_n_s16(zeta), vsubq_s16(b, a));
				vst1q_s16(r + j, c);
				vst1q_s16(r + j + len, b);
			}
#endif
			for (; j < start + len; ++j)
            {
                t = r[j];
                r[j] = kyber_barrett_reduce(t + r[j + len]);
                r[j + len] = r[j + len] - t;
                r[j + len] = kyber_fqmul(zeta, r[j + len]);
            }
        }
    }

#if defined(QSC_SYSTEM_ARM_INTRINSICS)
	for (j = 0U; j < QSC_KYBER_N; j += 8U)
	{
		vst1q_s16(r + j, kyber_fqmul_arm(vld1q_s16(r + j), vdupq_n_s16(F)));
	}
#else
    for (j = 0U; j < 256U; ++j)
    {
        r[j] = kyber_fqmul(r[j], F);
    }
#endif
}

#if !defined(QSC_SYSTEM_ARM_INTRINSICS)
static void kyber_basemul(int16_t r[2U], const int16_t a[2U], const int16_t b[2U], int16_t zeta)
{
    r[0U] = kyber_fqmul(a[1U], b[1U]);
    r[0U] = kyber_fqmul(r[0U], zeta);
    r[0U] += kyber_fqmul(a[0U], b[0U]);
    r[1U] = kyber_fqmul(a[0U], b[1U]);
    r[1U] += kyber_fqmul(a[1U], b[0U]);
}

#endif

/* poly.c */

static void kyber_poly_cbd_eta1(qsc_kyber_poly* r, const uint8_t buf[QSC_KYBER_ETA1 * QSC_KYBER_N / 4U])
{
#if QSC_KYBER_ETA1 == 2
    kyber_cbd2(r, buf);
#elif QSC_KYBER_ETA1 == 3
    kyber_cbd3(r, buf);
#endif
}

static void kyber_poly_cbd_eta2(qsc_kyber_poly* r, const uint8_t* buf)
{
    kyber_cbd2(r, buf);
}

static void kyber_poly_compress(uint8_t* r, const qsc_kyber_poly* a)
{
    uint8_t t[8U];
    int16_t u;

#if (QSC_KYBER_POLYCOMPRESSED_BYTES == 128)
    for (size_t i = 0U; i < QSC_KYBER_N / 8U; ++i)
    {
        for (size_t j = 0U; j < 8U; ++j)
        {
            /* map to positive standard representatives */
            u = a->coeffs[(8U * i) + j];
            u += (u >> 15) & QSC_KYBER_Q;
            t[j] = (uint8_t)(((((uint16_t)u << 4) + QSC_KYBER_Q / 2U) / QSC_KYBER_Q) & 0x000F);
        }

        r[0U] = (uint8_t)(t[0U] | (t[1U] << 4));
        r[1U] = (uint8_t)(t[2U] | (t[3U] << 4));
        r[2U] = (uint8_t)(t[4U] | (t[5U] << 4));
        r[3U] = (uint8_t)(t[6U] | (t[7U] << 4));
        r += 4U;
    }
#elif (QSC_KYBER_POLYCOMPRESSED_BYTES == 160)
    for (size_t i = 0U; i < QSC_KYBER_N / 8U; ++i)
    {
        for (size_t j = 0U; j < 8U; ++j)
        {
            /* map to positive standard representatives */
            u = a->coeffs[(8U * i) + j];
            u += (u >> 15) & QSC_KYBER_Q;
            t[j] = ((((uint32_t)u << 5) + QSC_KYBER_Q / 2U) / QSC_KYBER_Q) & 31;
        }

        r[0U] = (uint8_t)(t[0U] | (t[1U] << 5));
        r[1U] = (uint8_t)((t[1U] >> 3) | (t[2U] << 2) | (t[3U] << 7));
        r[2U] = (uint8_t)((t[3U] >> 1) | (t[4U] << 4));
        r[3U] = (uint8_t)((t[4U] >> 4) | (t[5U] << 1) | (t[6U] << 6));
        r[4U] = (uint8_t)((t[6U] >> 2) | (t[7U] << 3));
        r += 5U;
    }
#endif
}

static void kyber_poly_decompress(qsc_kyber_poly* r, const uint8_t* a)
{
#if (QSC_KYBER_POLYCOMPRESSED_BYTES == 128)
    for (size_t i = 0U; i < QSC_KYBER_N / 2U; ++i)
    {
        r->coeffs[2U * i] = (int16_t)((((uint16_t)(a[0U] & 15) * QSC_KYBER_Q) + 8U) >> 4);
        r->coeffs[(2U * i) + 1U] = (int16_t)((((uint16_t)(a[0U] >> 4) * QSC_KYBER_Q) + 8U) >> 4);
        a += 1;
    }
#elif (QSC_KYBER_POLYCOMPRESSED_BYTES == 160)
    uint8_t t[8U];

    for (size_t i = 0U; i < QSC_KYBER_N / 8U; ++i)
    {
        t[0U] = (uint8_t)(a[0U] >> 0);
        t[1U] = (uint8_t)((a[0U] >> 5) | (a[1U] << 3));
        t[2U] = (uint8_t)(a[1U] >> 2);
        t[3U] = (uint8_t)((a[1U] >> 7) | (a[2U] << 1));
        t[4U] = (uint8_t)((a[2U] >> 4) | (a[3U] << 4));
        t[5U] = (uint8_t)(a[3U] >> 1);
        t[6U] = (uint8_t)((a[3U] >> 6) | (a[4U] << 2));
        t[7U] = (uint8_t)(a[4U] >> 3);
        a += 5U;

        for (size_t j = 0U; j < 8U; ++j)
        {
            r->coeffs[(8U * i) + j] = (uint16_t)(((uint32_t)(t[j] & 31) * QSC_KYBER_Q + 16U) >> 5);
        }
    }
#endif
}

static void kyber_poly_to_bytes(uint8_t r[QSC_KYBER_POLYBYTES], const qsc_kyber_poly* a)
{
    /* Serialise a polynomial to 384 bytes (3 bytes per pair of 12-bit coefficients).
     *
     * Coefficients are in [-Q+1, Q-1] as int16_t.  Before packing they are
     * mapped to [0, Q-1] by adding Q to any negative value.
     *
     * The conditional add uses a portable unsigned mask in place of a
     * signed arithmetic right-shift, which is implementation-defined
     * behaviour before C23:
     *
     *   mask = -(t >> 15)       -- 0x0000 if t >= 0, 0xFFFF if t < 0
     *   t   += mask & Q         -- adds Q iff the coefficient was negative
     *
     * t >> 15 is an unsigned right-shift (t is uint16_t), always 0 or 1,
     * so the negation wraps predictably under unsigned two's-complement. */

    uint16_t t0;
    uint16_t t1;
    uint16_t mask;

    for (size_t i = 0U; i < QSC_KYBER_N / 2U; ++i)
    {
        t0 = (uint16_t)a->coeffs[2U * i];
        mask = (uint16_t)(-(t0 >> 15));
        t0 += mask & (uint16_t)QSC_KYBER_Q;

        t1 = (uint16_t)a->coeffs[(2U * i) + 1U];
        mask = (uint16_t)(-(t1 >> 15));
        t1 += mask & (uint16_t)QSC_KYBER_Q;

        r[3U * i] = (uint8_t)t0;
        r[(3U * i) + 1U] = (uint8_t)((t0 >> 8) | (t1 << 4));
        r[(3U * i) + 2U] = (uint8_t)(t1 >> 4);
    }
}

static void kyber_poly_from_bytes(qsc_kyber_poly* r, const uint8_t a[QSC_KYBER_POLYBYTES])
{
    for (size_t i = 0U; i < QSC_KYBER_N / 2U; ++i)
    {
        r->coeffs[2U * i] = (((a[3U * i] >> 0U) | ((uint16_t)a[3U * i + 1U] << 8)) & 0x0FFF);
        r->coeffs[(2U * i) + 1U] = (((a[(3U * i) + 1U] >> 4) | ((uint16_t)a[(3U * i) + 2U] << 4)) & 0x0FFF);
    }
}

static void kyber_poly_from_msg(qsc_kyber_poly* r, const uint8_t msg[QSC_KYBER_SYMBYTES])
{
    int16_t mask;

    for (size_t i = 0U; i < QSC_KYBER_N / 8U; ++i)
    {
        for (size_t j = 0U; j < 8U; ++j)
        {
            mask = -(int16_t)((msg[i] >> j) & 1);
            r->coeffs[(8U * i) + j] = mask & ((int16_t)(QSC_KYBER_Q + 1U) / 2U);
        }
    }
}

static void kyber_poly_to_msg(uint8_t msg[QSC_KYBER_SYMBYTES], const qsc_kyber_poly* a)
{
    uint16_t t;

    for (size_t i = 0U; i < QSC_KYBER_N / 8U; ++i)
    {
        msg[i] = 0;

        for (size_t j = 0U; j < 8U; ++j)
        {
            t = a->coeffs[(8U * i) + j];
            t += ((int16_t)t >> 15) & QSC_KYBER_Q;
            t = (((t << 1) + QSC_KYBER_Q / 2U) / QSC_KYBER_Q) & 1;
            msg[i] |= (uint8_t)(t << j);
        }
    }
}

static void kyber_poly_get_noise_eta1(qsc_kyber_poly* r, const uint8_t seed[QSC_KYBER_SYMBYTES], uint8_t nonce)
{
    uint8_t buf[QSC_KYBER_ETA1 * QSC_KYBER_N / 4U];
    uint8_t extkey[QSC_KYBER_SYMBYTES + 1U];

    qsc_memutils_copy(extkey, seed, QSC_KYBER_SYMBYTES);
    extkey[QSC_KYBER_SYMBYTES] = nonce;
    qsc_shake256_compute(buf, sizeof(buf), extkey, sizeof(extkey));
    qsc_memutils_secure_erase(extkey, sizeof(extkey));

    kyber_poly_cbd_eta1(r, buf);
    qsc_memutils_secure_erase(buf, sizeof(buf));
}

static void kyber_poly_get_noise_eta2(qsc_kyber_poly* r, const uint8_t seed[QSC_KYBER_SYMBYTES], uint8_t nonce)
{
    uint8_t buf[QSC_KYBER_ETA2 * QSC_KYBER_N / 4U];
    uint8_t extkey[QSC_KYBER_SYMBYTES + 1U];

    qsc_memutils_copy(extkey, seed, QSC_KYBER_SYMBYTES);
    extkey[QSC_KYBER_SYMBYTES] = nonce;
    qsc_shake256_compute(buf, sizeof(buf), extkey, sizeof(extkey));
    qsc_memutils_secure_erase(extkey, sizeof(extkey));

    kyber_poly_cbd_eta2(r, buf);
    qsc_memutils_secure_erase(buf, sizeof(buf));
}

static void kyber_poly_reduce(qsc_kyber_poly* r)
{
#if defined(QSC_SYSTEM_ARM_INTRINSICS)
	for (size_t i = 0U; i < QSC_KYBER_N; i += 8U)
	{
		vst1q_s16(r->coeffs + i, kyber_barrett_arm(vld1q_s16(r->coeffs + i)));
	}
#else
    for (size_t i = 0U; i < QSC_KYBER_N; ++i)
    {
        r->coeffs[i] = kyber_barrett_reduce(r->coeffs[i]);
    }
#endif
}

static void kyber_poly_ntt(qsc_kyber_poly* r)
{
    kyber_ntt(r->coeffs);
    kyber_poly_reduce(r);
}

static void kyber_poly_invntt_to_mont(qsc_kyber_poly* r)
{
    kyber_invntt(r->coeffs);
}

static void kyber_poly_basemul_montgomery(qsc_kyber_poly* r, const qsc_kyber_poly* a, const qsc_kyber_poly* b)
{
#if defined(QSC_SYSTEM_ARM_INTRINSICS)
	for (size_t i = 0U; i < QSC_KYBER_N; i += 16U)
	{
		int16_t zeta[8U];
		int16x8x2_t av;
		int16x8x2_t bv;
		int16x8x2_t rv;

		for (size_t j = 0U; j < 4U; ++j)
		{
			zeta[2U * j] = (int16_t)kyber_zetas[64U + (i / 4U) + j];
			zeta[(2U * j) + 1U] = -zeta[2U * j];
		}

		av = vld2q_s16(a->coeffs + i);
		bv = vld2q_s16(b->coeffs + i);
		rv.val[0U] = kyber_fqmul_arm(kyber_fqmul_arm(av.val[1U], bv.val[1U]), vld1q_s16(zeta));
		rv.val[0U] = vaddq_s16(rv.val[0U], kyber_fqmul_arm(av.val[0U], bv.val[0U]));
		rv.val[1U] = vaddq_s16(kyber_fqmul_arm(av.val[0U], bv.val[1U]), kyber_fqmul_arm(av.val[1U], bv.val[0U]));
		vst2q_s16(r->coeffs + i, rv);
	}
#else
    for (size_t i = 0U; i < QSC_KYBER_N / 4U; ++i)
    {
        kyber_basemul(&r->coeffs[4U * i], &a->coeffs[4U * i], &b->coeffs[4U * i], (int16_t)kyber_zetas[64U + i]);
        kyber_basemul(&r->coeffs[(4U * i) + 2U], &a->coeffs[(4U * i) + 2U], &b->coeffs[(4U * i) + 2U], -(int16_t)kyber_zetas[64U + i]);
    }
#endif
}

static void kyber_poly_to_mont(qsc_kyber_poly* r)
{
#if defined(QSC_SYSTEM_ARM_INTRINSICS)
	const int16_t F = (1ULL << 32) % QSC_KYBER_Q;

	for (size_t i = 0U; i < QSC_KYBER_N; i += 8U)
	{
		vst1q_s16(r->coeffs + i, kyber_fqmul_arm(vld1q_s16(r->coeffs + i), vdupq_n_s16(F)));
	}
#else
    const int16_t F = (1ULL << 32) % QSC_KYBER_Q;

    for (size_t i = 0U; i < QSC_KYBER_N; ++i)
    {
        r->coeffs[i] = kyber_montgomery_reduce((int32_t)r->coeffs[i] * F);
    }
#endif
}

static void kyber_poly_add(qsc_kyber_poly* r, const qsc_kyber_poly* a, const qsc_kyber_poly* b)
{
#if defined(QSC_SYSTEM_ARM_INTRINSICS)
	for (size_t i = 0U; i < QSC_KYBER_N; i += 8U)
	{
		vst1q_s16(r->coeffs + i, vaddq_s16(vld1q_s16(a->coeffs + i), vld1q_s16(b->coeffs + i)));
	}
#else
    for (size_t i = 0U; i < QSC_KYBER_N; ++i)
    {
        r->coeffs[i] = a->coeffs[i] + b->coeffs[i];
    }
#endif
}

static void kyber_poly_sub(qsc_kyber_poly* r, const qsc_kyber_poly* a, const qsc_kyber_poly* b)
{
#if defined(QSC_SYSTEM_ARM_INTRINSICS)
	for (size_t i = 0U; i < QSC_KYBER_N; i += 8U)
	{
		vst1q_s16(r->coeffs + i, vsubq_s16(vld1q_s16(a->coeffs + i), vld1q_s16(b->coeffs + i)));
	}
#else
    for (size_t i = 0U; i < QSC_KYBER_N; ++i)
    {
        r->coeffs[i] = a->coeffs[i] - b->coeffs[i];
    }
#endif
}

/* polyvec.c */

static void kyber_polyvec_compress(uint8_t r[QSC_KYBER_POLYVEC_COMPRESSED_BYTES], const qsc_kyber_polyvec* a)
{
#if (QSC_KYBER_K == 4 || QSC_KYBER_K == 5)
	uint16_t t[8U];

    for (size_t i = 0U; i < QSC_KYBER_K; ++i)
    {
        for (size_t j = 0U; j < QSC_KYBER_N / 8U; ++j)
        {
            for (size_t k = 0U; k < 8U; ++k)
            {
                t[k] = (uint16_t)a->vec[i].coeffs[(8U * j) + k];
                t[k] += (uint16_t)(((int16_t)t[k] >> 15) & QSC_KYBER_Q);
                t[k] = (uint16_t)(((((uint32_t)t[k] << 11) + QSC_KYBER_Q / 2U) / QSC_KYBER_Q) & 0x07FF);
            }

            r[0U] = (uint8_t)(t[0U] >> 0);
            r[1U] = (uint8_t)((t[0U] >> 8) | (t[1U] << 3));
            r[2U] = (uint8_t)((t[1U] >> 5) | (t[2U] << 6));
            r[3U] = (uint8_t)(t[2U] >> 2);
            r[4U] = (uint8_t)((t[2U] >> 10) | (t[3U] << 1));
            r[5U] = (uint8_t)((t[3U] >> 7) | (t[4U] << 4));
            r[6U] = (uint8_t)((t[4U] >> 4) | (t[5U] << 7));
            r[7U] = (uint8_t)(t[5U] >> 1);
            r[8U] = (uint8_t)((t[5U] >> 9) | (t[6U] << 2));
            r[9U] = (uint8_t)((t[6U] >> 6) | (t[7U] << 5));
            r[10U] = (uint8_t)(t[7U] >> 3);
            r += 11U;
        }
    }
#elif (QSC_KYBER_K == 2 || QSC_KYBER_K == 3)
	uint16_t t[4U];

    for (size_t i = 0U; i < QSC_KYBER_K; ++i)
    {
        for (size_t j = 0U; j < QSC_KYBER_N / 4U; ++j)
        {
            for (size_t k = 0U; k < 4U; ++k)
            {
                t[k] = (uint16_t)a->vec[i].coeffs[(4U * j) + k];
                t[k] += (uint16_t)(((int16_t)t[k] >> 15) & QSC_KYBER_Q);
                t[k] = (uint16_t)(((((uint32_t)t[k] << 10) + QSC_KYBER_Q / 2U) / QSC_KYBER_Q) & 0x03FF);
            }

            r[0U] = (uint8_t)(t[0U] >> 0);
            r[1U] = (uint8_t)((t[0U] >> 8) | (t[1U] << 2));
            r[2U] = (uint8_t)((t[1U] >> 6) | (t[2U] << 4));
            r[3U] = (uint8_t)((t[2U] >> 4) | (t[3U] << 6));
            r[4U] = (uint8_t)(t[3U] >> 2);
            r += 5U;
        }
    }
#endif
}

static void kyber_polyvec_decompress(qsc_kyber_polyvec* r, const uint8_t a[QSC_KYBER_POLYVEC_COMPRESSED_BYTES])
{
#if (QSC_KYBER_K == 4 || QSC_KYBER_K == 5)

    uint16_t t[8U];

    for (size_t i = 0U; i < QSC_KYBER_K; ++i)
    {
        for (size_t j = 0U; j < QSC_KYBER_N / 8U; ++j)
        {
            t[0U] = (uint16_t)a[0U] | (uint16_t)(a[1U] << 8);
            t[1U] = (uint16_t)(a[1U] >> 3) | (uint16_t)(a[2U] << 5);
            t[2U] = (uint16_t)(a[2U] >> 6) | (uint16_t)(a[3U] << 2) | (uint16_t)(a[4U] << 10);
            t[3U] = (uint16_t)(a[4U] >> 1) | (uint16_t)(a[5U] << 7);
            t[4U] = (uint16_t)(a[5U] >> 4) | (uint16_t)(a[6U] << 4);
            t[5U] = (uint16_t)(a[6U] >> 7) | (uint16_t)(a[7U] << 1) | (uint16_t)(a[8U] << 9);
            t[6U] = (uint16_t)(a[8U] >> 2) | (uint16_t)(a[9U] << 6);
            t[7U] = (uint16_t)(a[9U] >> 5) | (uint16_t)(a[10U] << 3);
            a += 11U;

            for (size_t k = 0U; k < 8U; ++k)
            {
                r->vec[i].coeffs[(8U * j) + k] = (int16_t)(((uint32_t)(t[k] & 0x7FF) * QSC_KYBER_Q + 1024) >> 11);
            }
        }
    }

#elif (QSC_KYBER_K == 2 || QSC_KYBER_K == 3)

	uint16_t t[4U];

    for (size_t i = 0U; i < QSC_KYBER_K; ++i)
    {
        for (size_t j = 0U; j < QSC_KYBER_N / 4U; ++j)
        {
            t[0U] = (uint16_t)(a[0U] | ((uint16_t)a[1U] << 8));
            t[1U] = (uint16_t)((a[1U] >> 2) | ((uint16_t)a[2U] << 6));
            t[2U] = (uint16_t)((a[2U] >> 4) | ((uint16_t)a[3U] << 4));
            t[3U] = (uint16_t)((a[3U] >> 6) | ((uint16_t)a[4U] << 2));
            a += 5U;

            for (size_t k = 0U; k < 4U; ++k)
            {
                r->vec[i].coeffs[(4U * j) + k] = (int16_t)(((uint32_t)(t[k] & 0x3FF) * QSC_KYBER_Q + 512) >> 10);
            }
        }
    }

#endif
}

static void kyber_polyvec_to_bytes(uint8_t r[QSC_KYBER_POLYVEC_BYTES], const qsc_kyber_polyvec* a)
{
    for (size_t i = 0U; i < QSC_KYBER_K; ++i)
    {
        kyber_poly_to_bytes(r + (i * QSC_KYBER_POLYBYTES), &a->vec[i]);
    }
}

static void kyber_polyvec_from_bytes(qsc_kyber_polyvec* r, const uint8_t a[QSC_KYBER_POLYVEC_BYTES])
{
    for (size_t i = 0U; i < QSC_KYBER_K; ++i)
    {
        kyber_poly_from_bytes(&r->vec[i], a + (i * QSC_KYBER_POLYBYTES));
    }
}

static void kyber_polyvec_ntt(qsc_kyber_polyvec* r)
{
    for (size_t i = 0U; i < QSC_KYBER_K; ++i)
    {
        kyber_poly_ntt(&r->vec[i]);
    }
}

static void kyber_polyvec_invntt_to_mont(qsc_kyber_polyvec* r)
{
    for (size_t i = 0U; i < QSC_KYBER_K; ++i)
    {
        kyber_poly_invntt_to_mont(&r->vec[i]);
    }
}

static void kyber_polyvec_basemul_acc_montgomery(qsc_kyber_poly* r, const qsc_kyber_polyvec* a, const qsc_kyber_polyvec* b)
{
    qsc_kyber_poly t;

    kyber_poly_basemul_montgomery(r, &a->vec[0U], &b->vec[0U]);

    for (size_t i = 1U; i < QSC_KYBER_K; ++i)
    {
        kyber_poly_basemul_montgomery(&t, &a->vec[i], &b->vec[i]);
        kyber_poly_add(r, r, &t);
    }

    kyber_poly_reduce(r);
}

static void kyber_polyvec_reduce(qsc_kyber_polyvec* r)
{
    for (size_t i = 0U; i < QSC_KYBER_K; ++i)
    {
        kyber_poly_reduce(&r->vec[i]);
    }
}

static void kyber_polyvec_add(qsc_kyber_polyvec* r, const qsc_kyber_polyvec* a, const qsc_kyber_polyvec* b)
{
    for (size_t i = 0U; i < QSC_KYBER_K; ++i)
    {
        kyber_poly_add(&r->vec[i], &a->vec[i], &b->vec[i]);
    }
}

/* indcpa.c */

static void kyber_pack_pk(uint8_t r[QSC_KYBER_INDCPA_PUBLICKEY_BYTES], const qsc_kyber_polyvec* pk, const uint8_t seed[QSC_KYBER_SYMBYTES])
{
    kyber_polyvec_to_bytes(r, pk);
    qsc_memutils_copy((r + QSC_KYBER_POLYVEC_BYTES), seed, QSC_KYBER_SYMBYTES);
}

static void kyber_unpack_pk(qsc_kyber_polyvec* pk, uint8_t seed[QSC_KYBER_SYMBYTES], const uint8_t packedpk[QSC_KYBER_INDCPA_PUBLICKEY_BYTES])
{
    kyber_polyvec_from_bytes(pk, packedpk);
    qsc_memutils_copy(seed, (packedpk + QSC_KYBER_POLYVEC_BYTES), QSC_KYBER_SYMBYTES);
}

static void kyber_pack_sk(uint8_t r[QSC_KYBER_INDCPA_SECRETKEY_BYTES], const qsc_kyber_polyvec* sk)
{
    kyber_polyvec_to_bytes(r, sk);
}

static void kyber_unpack_sk(qsc_kyber_polyvec* sk, const uint8_t packedsk[QSC_KYBER_INDCPA_SECRETKEY_BYTES])
{
    kyber_polyvec_from_bytes(sk, packedsk);
}

static void kyber_pack_ciphertext(uint8_t r[QSC_KYBER_INDCPA_BYTES], const qsc_kyber_polyvec* b, const qsc_kyber_poly* v)
{
    kyber_polyvec_compress(r, b);
    kyber_poly_compress(r + QSC_KYBER_POLYVEC_COMPRESSED_BYTES, v);
}

static void kyber_unpack_ciphertext(qsc_kyber_polyvec* b, qsc_kyber_poly* v, const uint8_t c[QSC_KYBER_INDCPA_BYTES])
{
    kyber_polyvec_decompress(b, c);
    kyber_poly_decompress(v, c + QSC_KYBER_POLYVEC_COMPRESSED_BYTES);
}

static uint32_t kyber_rej_uniform(int16_t* r, uint32_t len, const uint8_t* buf, uint32_t buflen)
{
    uint32_t ctr;
    uint32_t pos;
    uint16_t val0;
    uint16_t val1;

    ctr = 0U;
    pos = 0U;

    while (ctr < len && pos + 3U <= buflen)
    {
        val0 = (uint16_t)(((buf[pos] >> 0) | ((uint16_t)buf[pos + 1U] << 8)) & 0x0FFF);
        val1 = (uint16_t)(((buf[pos + 1] >> 4) | ((uint16_t)buf[pos + 2U] << 4)) & 0x0FFF);
        pos += 3;

        if (val0 < QSC_KYBER_Q)
        {
            r[ctr] = val0;
            ++ctr;
        }

        if (ctr < len && val1 < QSC_KYBER_Q)
        {
            r[ctr] = val1;
            ++ctr;
        }
    }

    return ctr;
}

static void kyber_gen_matrix(qsc_kyber_polyvec* a, const uint8_t seed[QSC_KYBER_SYMBYTES], int32_t transposed)
{
    QSC_ASSERT(seed != NULL);

    qsc_keccak_state state;
    uint8_t buf[KYBER_GEN_MATRIX_NBLOCKS * QSC_KECCAK_128_RATE + 2U];
    uint8_t extseed[QSC_KYBER_SYMBYTES + 2U];
    uint32_t buflen;
    uint32_t ctr;
    uint32_t off;

    qsc_memutils_copy(extseed, seed, QSC_KYBER_SYMBYTES);

    for (size_t i = 0U; i < QSC_KYBER_K; ++i)
    {
        for (size_t j = 0U; j < QSC_KYBER_K; ++j)
        {
            if (transposed != 0)
            {
                extseed[QSC_KYBER_SYMBYTES] = (uint8_t)i;
                extseed[QSC_KYBER_SYMBYTES + 1U] = (uint8_t)j;
            }
            else
            {
                extseed[QSC_KYBER_SYMBYTES] = (uint8_t)j;
                extseed[QSC_KYBER_SYMBYTES + 1U] = (uint8_t)i;
            }

            qsc_shake_initialize(&state, QSC_KECCAK_128_RATE, extseed, sizeof(extseed));
            qsc_shake_squeezeblocks(&state, QSC_KECCAK_128_RATE, buf, KYBER_GEN_MATRIX_NBLOCKS);

            buflen = KYBER_GEN_MATRIX_NBLOCKS * QSC_KECCAK_128_RATE;
            ctr = kyber_rej_uniform(a[i].vec[j].coeffs, QSC_KYBER_N, buf, buflen);

            while (ctr < QSC_KYBER_N)
            {
                off = buflen % 3U;

                for (size_t k = 0; k < off; ++k)
                {
                    buf[k] = buf[buflen - off + k];
                }

                qsc_shake_squeezeblocks(&state, QSC_KECCAK_128_RATE, buf + off, 1U);
                buflen = off + QSC_KECCAK_128_RATE;
                ctr += kyber_rej_uniform(a[i].vec[j].coeffs + ctr, QSC_KYBER_N - ctr, buf, buflen);
            }


        }
    }

    qsc_memutils_secure_erase(buf, sizeof(buf));
    qsc_memutils_secure_erase(extseed, sizeof(extseed));
    qsc_keccak_dispose(&state);
}

static void kyber_indcpa_enc(uint8_t c[QSC_KYBER_INDCPA_BYTES], const uint8_t m[QSC_KYBER_MSGBYTES],
    const uint8_t pk[QSC_KYBER_INDCPA_PUBLICKEY_BYTES], const uint8_t coins[QSC_KYBER_SYMBYTES])
{
    qsc_kyber_polyvec sp;
    qsc_kyber_polyvec pkpv;
    qsc_kyber_polyvec ep;
    qsc_kyber_polyvec at[QSC_KYBER_K];
    qsc_kyber_polyvec b;
    qsc_kyber_poly v;
    qsc_kyber_poly k;
    qsc_kyber_poly epp;
    uint8_t seed[QSC_KYBER_SYMBYTES];
    size_t i;
    uint8_t nonce;

    nonce = 0U;
    kyber_unpack_pk(&pkpv, seed, pk);
    kyber_poly_from_msg(&k, m);
    kyber_gen_matrix(at, seed, 1);
    qsc_memutils_secure_erase(seed, sizeof(seed));

    for (i = 0U; i < QSC_KYBER_K; ++i)
    {
        kyber_poly_get_noise_eta1(sp.vec + i, coins, nonce);
        ++nonce;
    }

    for (i = 0; i < QSC_KYBER_K; ++i)
    {
        kyber_poly_get_noise_eta2(ep.vec + i, coins, nonce);
        ++nonce;
    }

    kyber_poly_get_noise_eta2(&epp, coins, nonce);
    kyber_polyvec_ntt(&sp);

    for (i = 0; i < QSC_KYBER_K; ++i)
    {
        kyber_polyvec_basemul_acc_montgomery(&b.vec[i], &at[i], &sp);
    }

    kyber_polyvec_basemul_acc_montgomery(&v, &pkpv, &sp);
    kyber_polyvec_invntt_to_mont(&b);
    kyber_poly_invntt_to_mont(&v);

    kyber_polyvec_add(&b, &b, &ep);
    kyber_poly_add(&v, &v, &epp);
    kyber_poly_add(&v, &v, &k);

    kyber_polyvec_reduce(&b);
    kyber_poly_reduce(&v);

    kyber_pack_ciphertext(c, &b, &v);
}

static void kyber_indcpa_dec(uint8_t m[QSC_KYBER_MSGBYTES], const uint8_t c[QSC_KYBER_INDCPA_BYTES], const uint8_t sk[QSC_KYBER_INDCPA_SECRETKEY_BYTES])
{
    qsc_kyber_polyvec b;
    qsc_kyber_polyvec skpv;
    qsc_kyber_poly v;
    qsc_kyber_poly mp;

    kyber_unpack_ciphertext(&b, &v, c);
    kyber_unpack_sk(&skpv, sk);
    kyber_polyvec_ntt(&b);
    kyber_polyvec_basemul_acc_montgomery(&mp, &skpv, &b);
    kyber_poly_invntt_to_mont(&mp);
    kyber_poly_sub(&mp, &v, &mp);
    kyber_poly_reduce(&mp);
    kyber_poly_to_msg(m, &mp);
}

/* kem.c */

static void kyber_indcpa_keypair(uint8_t pk[QSC_KYBER_INDCPA_PUBLICKEY_BYTES], uint8_t sk[QSC_KYBER_INDCPA_SECRETKEY_BYTES], const uint8_t* coins)
{
    qsc_kyber_polyvec a[QSC_KYBER_K];
    qsc_kyber_polyvec e;
    qsc_kyber_polyvec pkpv;
    qsc_kyber_polyvec skpv;
    uint8_t buf[2U * QSC_KYBER_SYMBYTES];
    const uint8_t* publicseed = buf;
    const uint8_t* noiseseed = buf + QSC_KYBER_SYMBYTES;
    size_t i;
    uint8_t nonce;

    nonce = 0U;
    
    qsc_memutils_copy(buf, coins, QSC_KYBER_SYMBYTES);
    buf[QSC_KYBER_SYMBYTES] = QSC_KYBER_K;

    qsc_sha3_compute512(buf, buf, QSC_KYBER_SYMBYTES + 1U);

    kyber_gen_matrix(a, publicseed, 0);

    for (i = 0U; i < QSC_KYBER_K; ++i)
    {
        kyber_poly_get_noise_eta1(&skpv.vec[i], noiseseed, nonce);
        ++nonce;
    }

    for (i = 0U; i < QSC_KYBER_K; ++i)
    {
        kyber_poly_get_noise_eta1(&e.vec[i], noiseseed, nonce);
        ++nonce;
    }

    kyber_polyvec_ntt(&skpv);
    kyber_polyvec_ntt(&e);

    for (i = 0; i < QSC_KYBER_K; ++i)
    {
        kyber_polyvec_basemul_acc_montgomery(&pkpv.vec[i], &a[i], &skpv);
        kyber_poly_to_mont(&pkpv.vec[i]);
    }

    kyber_polyvec_add(&pkpv, &pkpv, &e);
    kyber_polyvec_reduce(&pkpv);

    kyber_pack_sk(sk, &skpv);
    kyber_pack_pk(pk, &pkpv, publicseed);
    qsc_memutils_secure_erase(buf, sizeof(buf));
}

bool qsc_kyber_ref_generate_keypair(uint8_t pk[QSC_KYBER_PUBLICKEY_BYTES], uint8_t sk[QSC_KYBER_SECRETKEY_BYTES], bool (*rng_generate)(uint8_t*, size_t))
{
    uint8_t coins[2U * QSC_KYBER_SYMBYTES];
    
    bool res;

    res = false;

    if (rng_generate(coins, 2U * QSC_KYBER_SYMBYTES))
    {
        kyber_indcpa_keypair(pk, sk, coins);
        qsc_memutils_copy((sk + QSC_KYBER_INDCPA_SECRETKEY_BYTES), pk, QSC_KYBER_INDCPA_PUBLICKEY_BYTES);

        qsc_sha3_compute256(sk + QSC_KYBER_SECRETKEY_BYTES - (2U * QSC_KYBER_SYMBYTES), pk, QSC_KYBER_PUBLICKEY_BYTES);
        /* Value z for pseudo-random output on reject */
        qsc_memutils_copy(sk + QSC_KYBER_SECRETKEY_BYTES - QSC_KYBER_SYMBYTES, coins + QSC_KYBER_SYMBYTES, QSC_KYBER_SYMBYTES);
        qsc_memutils_secure_erase(coins, sizeof(coins));
        res = true;
    }

    return res;
}

void qsc_kyber_ref_generate_seeded_keypair(uint8_t pk[QSC_KYBER_PUBLICKEY_BYTES], uint8_t sk[QSC_KYBER_SECRETKEY_BYTES], uint8_t d[QSC_KYBER_SYMBYTES], uint8_t z[QSC_KYBER_SYMBYTES])
{
    kyber_indcpa_keypair(pk, sk, d);
    qsc_memutils_copy((sk + QSC_KYBER_INDCPA_SECRETKEY_BYTES), pk, QSC_KYBER_INDCPA_PUBLICKEY_BYTES);

    qsc_sha3_compute256(sk + QSC_KYBER_SECRETKEY_BYTES - (2U * QSC_KYBER_SYMBYTES), pk, QSC_KYBER_PUBLICKEY_BYTES);
    /* Value z for pseudo-random output on reject */
    qsc_memutils_copy(sk + QSC_KYBER_SECRETKEY_BYTES - QSC_KYBER_SYMBYTES, z, QSC_KYBER_SYMBYTES);
}

bool qsc_kyber_ref_encapsulate(uint8_t ct[QSC_KYBER_CIPHERTEXT_BYTES], uint8_t ss[QSC_KYBER_MSGBYTES], const uint8_t pk[QSC_KYBER_PUBLICKEY_BYTES], bool (*rng_generate)(uint8_t*, size_t))
{
    uint8_t buf[2U * QSC_KYBER_SYMBYTES];
    uint8_t kr[2U * QSC_KYBER_SYMBYTES];

    bool res;

    res = false;

    if (rng_generate(buf, QSC_KYBER_SYMBYTES))
    {
        /* Multitarget countermeasure for coins + contributory KEM */
        qsc_sha3_compute256(buf + QSC_KYBER_SYMBYTES, pk, QSC_KYBER_PUBLICKEY_BYTES);
        qsc_sha3_compute512(kr, buf, 2U * QSC_KYBER_SYMBYTES);

        /* coins are in kr+QSC_KYBER_SYMBYTES */
        kyber_indcpa_enc(ct, buf, pk, kr + QSC_KYBER_SYMBYTES);
        qsc_memutils_secure_erase(buf, sizeof(buf));

        qsc_memutils_copy(ss, kr, QSC_KYBER_SYMBYTES);
        qsc_memutils_secure_erase(kr, sizeof(kr));
        res = true;
    }

    return res;
}

void qsc_kyber_ref_seeded_encapsulate(uint8_t ct[QSC_KYBER_CIPHERTEXT_BYTES], uint8_t ss[QSC_KYBER_MSGBYTES], const uint8_t pk[QSC_KYBER_PUBLICKEY_BYTES], const uint8_t m[QSC_KYBER_SYMBYTES])
{
    uint8_t buf[2U * QSC_KYBER_SYMBYTES];
    uint8_t kr[2U * QSC_KYBER_SYMBYTES];

    qsc_memutils_copy(buf, m, QSC_KYBER_SYMBYTES);

    /* multitarget countermeasure for coins + contributory KEM */
    qsc_sha3_compute256(buf + QSC_KYBER_SYMBYTES, pk, QSC_KYBER_PUBLICKEY_BYTES);
    qsc_sha3_compute512(kr, buf, 2U * QSC_KYBER_SYMBYTES);

    /* coins are in kr + QSC_KYBER_SYMBYTES */
    kyber_indcpa_enc(ct, buf, pk, kr + QSC_KYBER_SYMBYTES);
    qsc_memutils_secure_erase(buf, sizeof(buf));

    qsc_memutils_copy(ss, kr, QSC_KYBER_SYMBYTES);
    qsc_memutils_secure_erase(kr, sizeof(kr));

}

bool qsc_kyber_ref_decapsulate(uint8_t ss[QSC_KYBER_MSGBYTES], const uint8_t ct[QSC_KYBER_CIPHERTEXT_BYTES], const uint8_t sk[QSC_KYBER_SECRETKEY_BYTES])
{
    uint8_t buf[2U * QSC_KYBER_SYMBYTES];
    uint8_t cmp[QSC_KYBER_SYMBYTES + QSC_KYBER_CIPHERTEXT_BYTES];
    uint8_t kr[2U * QSC_KYBER_SYMBYTES];
    qsc_keccak_state kctx = { 0U };
    const uint8_t *pk = sk + QSC_KYBER_INDCPA_SECRETKEY_BYTES;
    int32_t fail;

    kyber_indcpa_dec(buf, ct, sk);

    /* Multitarget countermeasure for coins + contributory KEM */
    qsc_memutils_copy((buf + QSC_KYBER_SYMBYTES), (sk + QSC_KYBER_SECRETKEY_BYTES - (2U * QSC_KYBER_SYMBYTES)), QSC_KYBER_SYMBYTES);
    qsc_sha3_compute512(kr, buf, 2U * QSC_KYBER_SYMBYTES);

    /* coins are in kr+QSC_KYBER_SYMBYTES */
    kyber_indcpa_enc(cmp + QSC_KYBER_SYMBYTES, buf, pk, kr + QSC_KYBER_SYMBYTES);
    qsc_memutils_secure_erase(buf, sizeof(buf));

    fail = qsc_intutils_verify(ct, cmp + QSC_KYBER_SYMBYTES, QSC_KYBER_CIPHERTEXT_BYTES);

    qsc_memutils_copy(cmp, sk + QSC_KYBER_SECRETKEY_BYTES - QSC_KYBER_SYMBYTES, QSC_KYBER_SYMBYTES);
    qsc_memutils_copy(cmp + QSC_KYBER_SYMBYTES, ct, QSC_KYBER_CIPHERTEXT_BYTES);
    qsc_keccak_absorb(&kctx, qsc_keccak_rate_256, cmp, sizeof(cmp), QSC_KECCAK_SHAKE_DOMAIN_ID, QSC_KECCAK_PERMUTATION_ROUNDS);
    qsc_memutils_secure_erase(cmp, sizeof(cmp));
    qsc_keccak_permute(&kctx, QSC_KECCAK_PERMUTATION_ROUNDS);

#if defined(QSC_SYSTEM_IS_LITTLE_ENDIAN)
	qsc_memutils_copy(ss, (const uint8_t*)kctx.state, QSC_KYBER_SYMBYTES);
#else
	for (size_t i = 0U; i < QSC_KYBER_SYMBYTES / sizeof(uint64_t); ++i)
	{
		qsc_intutils_le64to8(ss + (i * sizeof(uint64_t)), kctx.state[i]);
	}
#endif

    qsc_intutils_cmov(ss, kr, QSC_KYBER_SYMBYTES, (uint8_t)!fail);
    qsc_memutils_secure_erase(kr, sizeof(kr));

    /* FIPS 203 implicit rejection keeps ciphertext validity private.
     * Both valid and invalid ciphertexts produce a shared secret. */
    return true;
}
