#include "sha2.h"
#include "intrinsics.h"
#include "intutils.h"
#include "memutils.h"

#define SHA2_256_ROUNDS_COUNT 64U
#define SHA2_384_ROUNDS_COUNT 80U
#define SHA2_512_ROUNDS_COUNT 80U

/* SHA2-256 */

static const uint32_t sha256_iv[8U] =
{
	0x6A09E667UL,
	0xBB67AE85UL,
	0x3C6EF372UL,
	0xA54FF53AUL,
	0x510E527FUL,
	0x9B05688CUL,
	0x1F83D9ABUL,
	0x5BE0CD19UL
};

static void sha256_increase(qsc_sha256_state* ctx, size_t msglen)
{
	QSC_ASSERT(ctx != NULL);

	ctx->t += msglen;
}

void qsc_sha256_dispose(qsc_sha256_state* ctx)
{
	QSC_ASSERT(ctx != NULL);

	if (ctx != NULL)
	{
		qsc_memutils_secure_erase(ctx->state, sizeof(ctx->state));
		qsc_memutils_secure_erase(ctx->buffer, sizeof(ctx->buffer));
		ctx->t = 0U;
		ctx->position = 0U;
	}
}

#if defined(QSC_SHA2_SHANI_ENABLED) && defined(__GNUC__) && !defined(__clang__) && !defined(QSC_SYSTEM_ARM_SHA256_ENABLED)
/** 
* \brief Compress a sequence of SHA-256 message blocks without changing the public ABI. 
*/
static void sha256_compress_blocks(uint32_t* state, const uint8_t* message, size_t nblocks);
#endif

static void sha256_oneshot_small(uint8_t* output, const uint8_t* message, size_t msglen)
{
	/* one-rate SHA-256 one-shot hashing without general-purpose state buffering */
    uint32_t state[8U];
    uint8_t block[128U] = { 0U };
    size_t i;
    size_t blockcount;

    qsc_memutils_copy((uint8_t*)state, (const uint8_t*)sha256_iv, sizeof(state));
    if (msglen != 0U)
    {
        qsc_memutils_copy(block, message, msglen);
    }
    block[msglen] = 0x80U;
    blockcount = msglen <= 55U ? 1U : 2U;
    qsc_intutils_be32to8(block + (blockcount * 64U) - 4U, (uint32_t)(msglen * 8U));

#if defined(QSC_SHA2_SHANI_ENABLED) && defined(__GNUC__) && !defined(__clang__) && !defined(QSC_SYSTEM_ARM_SHA256_ENABLED)
    sha256_compress_blocks(state, block, blockcount);
#else
    for (i = 0U; i < blockcount; ++i)
    {
        qsc_sha256_permute(state, block + (i * 64U));
    }
#endif

    for (i = 0U; i < 32U; i += 4U)
    {
        qsc_intutils_be32to8(output + i, state[i / 4U]);
    }

    qsc_memutils_secure_erase(state, sizeof(state));
    qsc_memutils_secure_erase(block, sizeof(block));
}

void qsc_sha256_compute(uint8_t* output, const uint8_t* message, size_t msglen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);

	qsc_sha256_state ctx;

	if (output != NULL && (message != NULL || msglen == 0U))
	{
		if (msglen <= QSC_SHA2_256_RATE)
		{
			sha256_oneshot_small(output, message, msglen);
		}
		else
		{
			qsc_sha256_initialize(&ctx);
			qsc_sha256_update(&ctx, message, msglen);
			qsc_sha256_finalize(&ctx, output);
		}
	}
}

void qsc_sha256_finalize(qsc_sha256_state* ctx, uint8_t* output)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(output != NULL);

	uint8_t pad[QSC_SHA2_256_RATE] = { 0U };
	uint64_t bitLen;

	if (ctx != NULL && output != NULL)
	{
		qsc_memutils_copy(pad, ctx->buffer, ctx->position);
		sha256_increase(ctx, ctx->position);
		bitLen = (ctx->t << 3);

		if (ctx->position == QSC_SHA2_256_RATE)
		{
			qsc_sha256_permute(ctx->state, pad);
			ctx->position = 0U;
		}

		pad[ctx->position] = 128U;
		++ctx->position;

		/* padding */
		if (ctx->position < QSC_SHA2_256_RATE)
		{
			qsc_memutils_clear((pad + ctx->position), QSC_SHA2_256_RATE - ctx->position);
		}

		if (ctx->position > 56U)
		{
			qsc_sha256_permute(ctx->state, pad);
			qsc_memutils_clear(pad, QSC_SHA2_256_RATE);
		}

		/* finalize state with counter and last compression */
		qsc_intutils_be32to8((pad + 56U), (uint32_t)(bitLen >> 32U));
		qsc_intutils_be32to8((pad + 60U), (uint32_t)bitLen);
		qsc_sha256_permute(ctx->state, pad);

#if defined(QSC_SYSTEM_IS_BIG_ENDIAN)
		qsc_memutils_copy(output, (const uint8_t*)ctx->state, QSC_SHA2_256_HASH_SIZE);
#else
		for (size_t i = 0U; i < QSC_SHA2_256_HASH_SIZE; i += sizeof(uint32_t))
		{
			qsc_intutils_be32to8((output + i), ctx->state[i / sizeof(uint32_t)]);
		}
#endif

		qsc_memutils_secure_erase(pad, sizeof(pad));
		qsc_sha256_dispose(ctx);
	}
}

void qsc_sha256_initialize(qsc_sha256_state* ctx)
{
	QSC_ASSERT(ctx != NULL);

	if (ctx != NULL)
	{
		qsc_memutils_copy((uint8_t*)ctx->state, (const uint8_t*)sha256_iv, sizeof(ctx->state));
		qsc_memutils_secure_erase(ctx->buffer, sizeof(ctx->buffer));
		ctx->t = 0U;
		ctx->position = 0U;
	}
}

#if defined(QSC_SYSTEM_ARM_SHA256_ENABLED)
/** 
* \brief Standard SHA-2 round constants in ascending round order. 
*/
static const uint32_t sha256_round_constants_arm[64U] =
{
	0x428a2f98UL, 0x71374491UL, 0xb5c0fbcfUL, 0xe9b5dba5UL,
	0x3956c25bUL, 0x59f111f1UL, 0x923f82a4UL, 0xab1c5ed5UL,
	0xd807aa98UL, 0x12835b01UL, 0x243185beUL, 0x550c7dc3UL,
	0x72be5d74UL, 0x80deb1feUL, 0x9bdc06a7UL, 0xc19bf174UL,
	0xe49b69c1UL, 0xefbe4786UL, 0x0fc19dc6UL, 0x240ca1ccUL,
	0x2de92c6fUL, 0x4a7484aaUL, 0x5cb0a9dcUL, 0x76f988daUL,
	0x983e5152UL, 0xa831c66dUL, 0xb00327c8UL, 0xbf597fc7UL,
	0xc6e00bf3UL, 0xd5a79147UL, 0x06ca6351UL, 0x14292967UL,
	0x27b70a85UL, 0x2e1b2138UL, 0x4d2c6dfcUL, 0x53380d13UL,
	0x650a7354UL, 0x766a0abbUL, 0x81c2c92eUL, 0x92722c85UL,
	0xa2bfe8a1UL, 0xa81a664bUL, 0xc24b8b70UL, 0xc76c51a3UL,
	0xd192e819UL, 0xd6990624UL, 0xf40e3585UL, 0x106aa070UL,
	0x19a4c116UL, 0x1e376c08UL, 0x2748774cUL, 0x34b0bcb5UL,
	0x391c0cb3UL, 0x4ed8aa4aUL, 0x5b9cca4fUL, 0x682e6ff3UL,
	0x748f82eeUL, 0x78a5636fUL, 0x84c87814UL, 0x8cc70208UL,
	0x90befffaUL, 0xa4506cebUL, 0xbef9a3f7UL, 0xc67178f2UL
};

void qsc_sha256_permute(uint32_t* output, const uint8_t* message)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL);

	if (output != NULL && message != NULL)
	{
		uint32x4_t schedule[4U];
		uint32x4_t abcd;
		uint32x4_t efgh;
		uint32x4_t saved;
		uint32x4_t words;

		abcd = vld1q_u32(output);
		efgh = vld1q_u32(output + 4U);

		for (size_t i = 0U; i < 4U; ++i)
		{
			words = vreinterpretq_u32_u8(vld1q_u8(message + (i * 16U)));
#if defined(QSC_SYSTEM_IS_LITTLE_ENDIAN)
			words = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(words)));
#endif
			schedule[i] = words;
		}

		for (size_t i = 0U; i < 16U; ++i)
		{
			const size_t j = i & 3U;

			if (i >= 4U)
			{
				schedule[j] = vsha256su1q_u32(vsha256su0q_u32(schedule[j], schedule[(j + 1U) & 3U]),
					schedule[(j + 2U) & 3U], schedule[(j + 3U) & 3U]);
			}

			words = vaddq_u32(schedule[j], vld1q_u32(sha256_round_constants_arm + (i * 4U)));
			saved = abcd;
			abcd = vsha256hq_u32(abcd, efgh, words);
			efgh = vsha256h2q_u32(efgh, saved, words);
		}

		vst1q_u32(output, vaddq_u32(abcd, vld1q_u32(output)));
		vst1q_u32(output + 4U, vaddq_u32(efgh, vld1q_u32(output + 4U)));
		qsc_memutils_secure_erase(schedule, sizeof(schedule));
	}
}
#elif defined(QSC_SHA2_SHANI_ENABLED) && defined(__GNUC__) && !defined(__clang__)

static void sha256_shani_compress_blocks(uint32_t* output, const uint8_t* message, size_t nblocks)
{
	/* SHA-NI multi-block compression with register-resident chaining state */
	__m128i s0;
	__m128i s1;
	__m128i t0;
	__m128i t1;
	__m128i pmsg;
	__m128i m0;
	__m128i m1;
	__m128i m2;
	__m128i m3;
	__m128i mask;
	__m128i ptmp;


	if (nblocks != 0U)
	{
		/* load initial values */
		ptmp = _mm_loadu_si128((const __m128i*)output);
		s1 = _mm_loadu_si128((const __m128i*)(uint32_t*)(output + 4U));
		mask = _mm_set_epi64x(0x0C0D0E0F08090A0BULL, 0x0405060700010203ULL);
		ptmp = _mm_shuffle_epi32(ptmp, 0xB1);
		s1 = _mm_shuffle_epi32(s1, 0x1B);
		s0 = _mm_alignr_epi8(ptmp, s1, 8);
		s1 = _mm_blend_epi16(s1, ptmp, 0xF0);

		while (nblocks != 0U)
		{
			t0 = s0;
			t1 = s1;
			/* rounds 0-3 */
			pmsg = _mm_loadu_si128((const __m128i*)message);
			m0 = _mm_shuffle_epi8(pmsg, mask);
			pmsg = _mm_add_epi32(m0, _mm_set_epi64x(0xE9B5DBA5B5C0FBCFULL, 0x71374491428A2F98ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			/* rounds 4-7 */
			m1 = _mm_loadu_si128((const __m128i*)(uint8_t*)(message + 16U));
			m1 = _mm_shuffle_epi8(m1, mask);
			pmsg = _mm_add_epi32(m1, _mm_set_epi64x(0xAB1C5ED5923F82A4ULL, 0x59F111F13956C25BULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m0 = _mm_sha256msg1_epu32(m0, m1);
			/* rounds 8-11 */
			m2 = _mm_loadu_si128((const __m128i*)(uint8_t*)(message + 32U));
			m2 = _mm_shuffle_epi8(m2, mask);
			pmsg = _mm_add_epi32(m2, _mm_set_epi64x(0x550C7DC3243185BEULL, 0x12835B01D807AA98ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m1 = _mm_sha256msg1_epu32(m1, m2);
			/* rounds 12-15 */
			m3 = _mm_loadu_si128((const __m128i*)(uint8_t*)(message + 48U));
			m3 = _mm_shuffle_epi8(m3, mask);
			pmsg = _mm_add_epi32(m3, _mm_set_epi64x(0xC19BF1749BDC06A7ULL, 0x80DEB1FE72BE5D74ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m3, m2, 4);
			m0 = _mm_add_epi32(m0, ptmp);
			m0 = _mm_sha256msg2_epu32(m0, m3);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m2 = _mm_sha256msg1_epu32(m2, m3);
			/* rounds 16-19 */
			pmsg = _mm_add_epi32(m0, _mm_set_epi64x(0x240CA1CC0FC19DC6ULL, 0xEFBE4786E49B69C1ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m0, m3, 4);
			m1 = _mm_add_epi32(m1, ptmp);
			m1 = _mm_sha256msg2_epu32(m1, m0);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m3 = _mm_sha256msg1_epu32(m3, m0);
			/* rounds 20-23 */
			pmsg = _mm_add_epi32(m1, _mm_set_epi64x(0x76F988DA5CB0A9DCULL, 0x4A7484AA2DE92C6FULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m1, m0, 4);
			m2 = _mm_add_epi32(m2, ptmp);
			m2 = _mm_sha256msg2_epu32(m2, m1);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m0 = _mm_sha256msg1_epu32(m0, m1);
			/* rounds 24-27 */
			pmsg = _mm_add_epi32(m2, _mm_set_epi64x(0xBF597FC7B00327C8ULL, 0xA831C66D983E5152ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m2, m1, 4);
			m3 = _mm_add_epi32(m3, ptmp);
			m3 = _mm_sha256msg2_epu32(m3, m2);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m1 = _mm_sha256msg1_epu32(m1, m2);
			/* rounds 28-31 */
			pmsg = _mm_add_epi32(m3, _mm_set_epi64x(0x1429296706CA6351ULL, 0xD5A79147C6E00BF3ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m3, m2, 4);
			m0 = _mm_add_epi32(m0, ptmp);
			m0 = _mm_sha256msg2_epu32(m0, m3);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m2 = _mm_sha256msg1_epu32(m2, m3);
			/* rounds 32-35 */
			pmsg = _mm_add_epi32(m0, _mm_set_epi64x(0x53380D134D2C6DFCULL, 0x2E1B213827B70A85ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m0, m3, 4);
			m1 = _mm_add_epi32(m1, ptmp);
			m1 = _mm_sha256msg2_epu32(m1, m0);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m3 = _mm_sha256msg1_epu32(m3, m0);
			/* rounds 36-39 */
			pmsg = _mm_add_epi32(m1, _mm_set_epi64x(0x92722C8581C2C92EULL, 0x766A0ABB650A7354ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m1, m0, 4);
			m2 = _mm_add_epi32(m2, ptmp);
			m2 = _mm_sha256msg2_epu32(m2, m1);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m0 = _mm_sha256msg1_epu32(m0, m1);
			/* rounds 40-43 */
			pmsg = _mm_add_epi32(m2, _mm_set_epi64x(0xC76C51A3C24B8B70ULL, 0xA81A664BA2BFE8A1ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m2, m1, 4);
			m3 = _mm_add_epi32(m3, ptmp);
			m3 = _mm_sha256msg2_epu32(m3, m2);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m1 = _mm_sha256msg1_epu32(m1, m2);
			/* rounds 44-47 */
			pmsg = _mm_add_epi32(m3, _mm_set_epi64x(0x106AA070F40E3585ULL, 0xD6990624D192E819ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m3, m2, 4);
			m0 = _mm_add_epi32(m0, ptmp);
			m0 = _mm_sha256msg2_epu32(m0, m3);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m2 = _mm_sha256msg1_epu32(m2, m3);
			/* rounds 48-51 */
			pmsg = _mm_add_epi32(m0, _mm_set_epi64x(0x34B0BCB52748774CULL, 0x1E376C0819A4C116ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m0, m3, 4);
			m1 = _mm_add_epi32(m1, ptmp);
			m1 = _mm_sha256msg2_epu32(m1, m0);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			m3 = _mm_sha256msg1_epu32(m3, m0);
			/* rounds 52-55 */
			pmsg = _mm_add_epi32(m1, _mm_set_epi64x(0x682E6FF35B9CCA4FULL, 0x4ED8AA4A391C0CB3ULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m1, m0, 4);
			m2 = _mm_add_epi32(m2, ptmp);
			m2 = _mm_sha256msg2_epu32(m2, m1);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			/* rounds 56-59 */
			pmsg = _mm_add_epi32(m2, _mm_set_epi64x(0x8CC7020884C87814ULL, 0x78A5636F748F82EEULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			ptmp = _mm_alignr_epi8(m2, m1, 4);
			m3 = _mm_add_epi32(m3, ptmp);
			m3 = _mm_sha256msg2_epu32(m3, m2);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
			/* rounds 60-63 */
			pmsg = _mm_add_epi32(m3, _mm_set_epi64x(0xC67178F2BEF9A3F7ULL, 0xA4506CEB90BEFFFAULL));
			s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
			pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
			s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);

			s0 = _mm_add_epi32(s0, t0);
			s1 = _mm_add_epi32(s1, t1);
			message += QSC_SHA2_256_RATE;
			--nblocks;
		}

		ptmp = _mm_shuffle_epi32(s0, 0x1B);
		s1 = _mm_shuffle_epi32(s1, 0xB1);
		s0 = _mm_blend_epi16(ptmp, s1, 0xF0);
		s1 = _mm_alignr_epi8(s1, ptmp, 8);
		_mm_storeu_si128((__m128i*)output, s0);
		_mm_storeu_si128((__m128i*)(output + 4U), s1);
	}
}

void qsc_sha256_permute(uint32_t* output, const uint8_t* message)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL);

	if (output != NULL && message != NULL)
	{
		sha256_shani_compress_blocks(output, message, 1U);
	}
}

#elif defined(QSC_SHA2_SHANI_ENABLED)

void qsc_sha256_permute(uint32_t* output, const uint8_t* message)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL);

	__m128i s0;
	__m128i s1;
	__m128i t0;
	__m128i t1;
	__m128i pmsg;
	__m128i m0;
	__m128i m1;
	__m128i m2;
	__m128i m3;
	__m128i mask;
	__m128i ptmp;

	if (output != NULL && message != NULL)
	{
		/* load initial values */
		ptmp = _mm_loadu_si128((const __m128i*)output);
		s1 = _mm_loadu_si128((const __m128i*)(uint32_t*)(output + 4U));
		mask = _mm_set_epi64x(0x0C0D0E0F08090A0BULL, 0x0405060700010203ULL);
		ptmp = _mm_shuffle_epi32(ptmp, 0xB1);
		s1 = _mm_shuffle_epi32(s1, 0x1B);
		s0 = _mm_alignr_epi8(ptmp, s1, 8);
		s1 = _mm_blend_epi16(s1, ptmp, 0xF0);
		t0 = s0;
		t1 = s1;

		/* rounds 0-3 */
		pmsg = _mm_loadu_si128((const __m128i*)message);
		m0 = _mm_shuffle_epi8(pmsg, mask);
		pmsg = _mm_add_epi32(m0, _mm_set_epi64x(0xE9B5DBA5B5C0FBCFULL, 0x71374491428A2F98ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		/* rounds 4-7 */
		m1 = _mm_loadu_si128((const __m128i*)(uint8_t*)(message + 16U));
		m1 = _mm_shuffle_epi8(m1, mask);
		pmsg = _mm_add_epi32(m1, _mm_set_epi64x(0xAB1C5ED5923F82A4ULL, 0x59F111F13956C25BULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m0 = _mm_sha256msg1_epu32(m0, m1);
		/* rounds 8-11 */
		m2 = _mm_loadu_si128((const __m128i*)(uint8_t*)(message + 32U));
		m2 = _mm_shuffle_epi8(m2, mask);
		pmsg = _mm_add_epi32(m2, _mm_set_epi64x(0x550C7DC3243185BEULL, 0x12835B01D807AA98ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m1 = _mm_sha256msg1_epu32(m1, m2);
		/* rounds 12-15 */
		m3 = _mm_loadu_si128((const __m128i*)(uint8_t*)(message + 48U));
		m3 = _mm_shuffle_epi8(m3, mask);
		pmsg = _mm_add_epi32(m3, _mm_set_epi64x(0xC19BF1749BDC06A7ULL, 0x80DEB1FE72BE5D74ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m3, m2, 4);
		m0 = _mm_add_epi32(m0, ptmp);
		m0 = _mm_sha256msg2_epu32(m0, m3);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m2 = _mm_sha256msg1_epu32(m2, m3);
		/* rounds 16-19 */
		pmsg = _mm_add_epi32(m0, _mm_set_epi64x(0x240CA1CC0FC19DC6ULL, 0xEFBE4786E49B69C1ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m0, m3, 4);
		m1 = _mm_add_epi32(m1, ptmp);
		m1 = _mm_sha256msg2_epu32(m1, m0);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m3 = _mm_sha256msg1_epu32(m3, m0);
		/* rounds 20-23 */
		pmsg = _mm_add_epi32(m1, _mm_set_epi64x(0x76F988DA5CB0A9DCULL, 0x4A7484AA2DE92C6FULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m1, m0, 4);
		m2 = _mm_add_epi32(m2, ptmp);
		m2 = _mm_sha256msg2_epu32(m2, m1);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m0 = _mm_sha256msg1_epu32(m0, m1);
		/* rounds 24-27 */
		pmsg = _mm_add_epi32(m2, _mm_set_epi64x(0xBF597FC7B00327C8ULL, 0xA831C66D983E5152ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m2, m1, 4);
		m3 = _mm_add_epi32(m3, ptmp);
		m3 = _mm_sha256msg2_epu32(m3, m2);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m1 = _mm_sha256msg1_epu32(m1, m2);
		/* rounds 28-31 */
		pmsg = _mm_add_epi32(m3, _mm_set_epi64x(0x1429296706CA6351ULL, 0xD5A79147C6E00BF3ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m3, m2, 4);
		m0 = _mm_add_epi32(m0, ptmp);
		m0 = _mm_sha256msg2_epu32(m0, m3);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m2 = _mm_sha256msg1_epu32(m2, m3);
		/* rounds 32-35 */
		pmsg = _mm_add_epi32(m0, _mm_set_epi64x(0x53380D134D2C6DFCULL, 0x2E1B213827B70A85ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m0, m3, 4);
		m1 = _mm_add_epi32(m1, ptmp);
		m1 = _mm_sha256msg2_epu32(m1, m0);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m3 = _mm_sha256msg1_epu32(m3, m0);
		/* rounds 36-39 */
		pmsg = _mm_add_epi32(m1, _mm_set_epi64x(0x92722C8581C2C92EULL, 0x766A0ABB650A7354ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m1, m0, 4);
		m2 = _mm_add_epi32(m2, ptmp);
		m2 = _mm_sha256msg2_epu32(m2, m1);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m0 = _mm_sha256msg1_epu32(m0, m1);
		/* rounds 40-43 */
		pmsg = _mm_add_epi32(m2, _mm_set_epi64x(0xC76C51A3C24B8B70ULL, 0xA81A664BA2BFE8A1ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m2, m1, 4);
		m3 = _mm_add_epi32(m3, ptmp);
		m3 = _mm_sha256msg2_epu32(m3, m2);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m1 = _mm_sha256msg1_epu32(m1, m2);
		/* rounds 44-47 */
		pmsg = _mm_add_epi32(m3, _mm_set_epi64x(0x106AA070F40E3585ULL, 0xD6990624D192E819ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m3, m2, 4);
		m0 = _mm_add_epi32(m0, ptmp);
		m0 = _mm_sha256msg2_epu32(m0, m3);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m2 = _mm_sha256msg1_epu32(m2, m3);
		/* rounds 48-51 */
		pmsg = _mm_add_epi32(m0, _mm_set_epi64x(0x34B0BCB52748774CULL, 0x1E376C0819A4C116ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m0, m3, 4);
		m1 = _mm_add_epi32(m1, ptmp);
		m1 = _mm_sha256msg2_epu32(m1, m0);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		m3 = _mm_sha256msg1_epu32(m3, m0);
		/* rounds 52-55 */
		pmsg = _mm_add_epi32(m1, _mm_set_epi64x(0x682E6FF35B9CCA4FULL, 0x4ED8AA4A391C0CB3ULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m1, m0, 4);
		m2 = _mm_add_epi32(m2, ptmp);
		m2 = _mm_sha256msg2_epu32(m2, m1);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		/* rounds 56-59 */
		pmsg = _mm_add_epi32(m2, _mm_set_epi64x(0x8CC7020884C87814ULL, 0x78A5636F748F82EEULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		ptmp = _mm_alignr_epi8(m2, m1, 4);
		m3 = _mm_add_epi32(m3, ptmp);
		m3 = _mm_sha256msg2_epu32(m3, m2);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);
		/* rounds 60-63 */
		pmsg = _mm_add_epi32(m3, _mm_set_epi64x(0xC67178F2BEF9A3F7ULL, 0xA4506CEB90BEFFFAULL));
		s1 = _mm_sha256rnds2_epu32(s1, s0, pmsg);
		pmsg = _mm_shuffle_epi32(pmsg, 0x0E);
		s0 = _mm_sha256rnds2_epu32(s0, s1, pmsg);

		/* combine state */
		s0 = _mm_add_epi32(s0, t0);
		s1 = _mm_add_epi32(s1, t1);
		ptmp = _mm_shuffle_epi32(s0, 0x1B);
		s1 = _mm_shuffle_epi32(s1, 0xB1);
		s0 = _mm_blend_epi16(ptmp, s1, 0xF0);
		s1 = _mm_alignr_epi8(s1, ptmp, 8);

		/* store */
		_mm_storeu_si128((__m128i*)output, s0);
		_mm_storeu_si128((__m128i*)(uint32_t*)(output + 4U), s1);
	}
}

#else

void qsc_sha256_permute(uint32_t* output, const uint8_t* message)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL);

	uint32_t a;
	uint32_t b;
	uint32_t c;
	uint32_t d;
	uint32_t e;
	uint32_t f;
	uint32_t g;
	uint32_t h;
	uint32_t r;
	uint32_t w0;
	uint32_t w1;
	uint32_t w2;
	uint32_t w3;
	uint32_t w4;
	uint32_t w5;
	uint32_t w6;
	uint32_t w7;
	uint32_t w8;
	uint32_t w9;
	uint32_t w10;
	uint32_t w11;
	uint32_t w12;
	uint32_t w13;
	uint32_t w14;
	uint32_t w15;

	if (output != NULL && message != NULL)
	{
		a = output[0U];
		b = output[1U];
		c = output[2U];
		d = output[3U];
		e = output[4U];
		f = output[5U];
		g = output[6U];
		h = output[7U];

		w0 = qsc_intutils_be8to32(message);
		w1 = qsc_intutils_be8to32(message + 4U);
		w2 = qsc_intutils_be8to32(message + 8U);
		w3 = qsc_intutils_be8to32(message + 12U);
		w4 = qsc_intutils_be8to32(message + 16U);
		w5 = qsc_intutils_be8to32(message + 20U);
		w6 = qsc_intutils_be8to32(message + 24U);
		w7 = qsc_intutils_be8to32(message + 28U);
		w8 = qsc_intutils_be8to32(message + 32U);
		w9 = qsc_intutils_be8to32(message + 36U);
		w10 = qsc_intutils_be8to32(message + 40U);
		w11 = qsc_intutils_be8to32(message + 44U);
		w12 = qsc_intutils_be8to32(message + 48U);
		w13 = qsc_intutils_be8to32(message + 52U);
		w14 = qsc_intutils_be8to32(message + 56U);
		w15 = qsc_intutils_be8to32(message + 60U);

		r = h + (((e >> 6) | (e << 26)) ^ ((e >> 11) | (e << 21)) ^ ((e >> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + w0 + 0x428a2f98UL;
		d += r;
		h = r + ((((a >> 2) | (a << 30)) ^ ((a >> 13) | (a << 19)) ^ ((a >> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c)));
		r = g + (((d >> 6) | (d << 26)) ^ ((d >> 11) | (d << 21)) ^ ((d >> 25) | (d << 7))) + ((d & e) ^ (~d & f)) + w1 + 0x71374491UL;
		c += r;
		g = r + ((((h >> 2) | (h << 30)) ^ ((h >> 13) | (h << 19)) ^ ((h >> 22) | (h << 10))) + ((h & a) ^ (h & b) ^ (a & b)));
		r = f + (((c >> 6) | (c << 26)) ^ ((c >> 11) | (c << 21)) ^ ((c >> 25) | (c << 7))) + ((c & d) ^ (~c & e)) + w2 + 0xb5c0fbcfUL;
		b += r;
		f = r + ((((g >> 2) | (g << 30)) ^ ((g >> 13) | (g << 19)) ^ ((g >> 22) | (g << 10))) + ((g & h) ^ (g & a) ^ (h & a)));
		r = e + (((b >> 6) | (b << 26)) ^ ((b >> 11) | (b << 21)) ^ ((b >> 25) | (b << 7))) + ((b & c) ^ (~b & d)) + w3 + 0xe9b5dba5UL;
		a += r;
		e = r + ((((f >> 2) | (f << 30)) ^ ((f >> 13) | (f << 19)) ^ ((f >> 22) | (f << 10))) + ((f & g) ^ (f & h) ^ (g & h)));
		r = d + (((a >> 6) | (a << 26)) ^ ((a >> 11) | (a << 21)) ^ ((a >> 25) | (a << 7))) + ((a & b) ^ (~a & c)) + w4 + 0x3956c25bUL;
		h += r;
		d = r + ((((e >> 2) | (e << 30)) ^ ((e >> 13) | (e << 19)) ^ ((e >> 22) | (e << 10))) + ((e & f) ^ (e & g) ^ (f & g)));
		r = c + (((h >> 6) | (h << 26)) ^ ((h >> 11) | (h << 21)) ^ ((h >> 25) | (h << 7))) + ((h & a) ^ (~h & b)) + w5 + 0x59f111f1UL;
		g += r;
		c = r + ((((d >> 2) | (d << 30)) ^ ((d >> 13) | (d << 19)) ^ ((d >> 22) | (d << 10))) + ((d & e) ^ (d & f) ^ (e & f)));
		r = b + (((g >> 6) | (g << 26)) ^ ((g >> 11) | (g << 21)) ^ ((g >> 25) | (g << 7))) + ((g & h) ^ (~g & a)) + w6 + 0x923f82a4UL;
		f += r;
		b = r + ((((c >> 2) | (c << 30)) ^ ((c >> 13) | (c << 19)) ^ ((c >> 22) | (c << 10))) + ((c & d) ^ (c & e) ^ (d & e)));
		r = a + (((f >> 6) | (f << 26)) ^ ((f >> 11) | (f << 21)) ^ ((f >> 25) | (f << 7))) + ((f & g) ^ (~f & h)) + w7 + 0xab1c5ed5UL;
		e += r;
		a = r + ((((b >> 2) | (b << 30)) ^ ((b >> 13) | (b << 19)) ^ ((b >> 22) | (b << 10))) + ((b & c) ^ (b & d) ^ (c & d)));
		r = h + (((e >> 6) | (e << 26)) ^ ((e >> 11) | (e << 21)) ^ ((e >> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + w8 + 0xd807aa98UL;
		d += r;
		h = r + ((((a >> 2) | (a << 30)) ^ ((a >> 13) | (a << 19)) ^ ((a >> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c)));
		r = g + (((d >> 6) | (d << 26)) ^ ((d >> 11) | (d << 21)) ^ ((d >> 25) | (d << 7))) + ((d & e) ^ (~d & f)) + w9 + 0x12835b01UL;
		c += r;
		g = r + ((((h >> 2) | (h << 30)) ^ ((h >> 13) | (h << 19)) ^ ((h >> 22) | (h << 10))) + ((h & a) ^ (h & b) ^ (a & b)));
		r = f + (((c >> 6) | (c << 26)) ^ ((c >> 11) | (c << 21)) ^ ((c >> 25) | (c << 7))) + ((c & d) ^ (~c & e)) + w10 + 0x243185beUL;
		b += r;
		f = r + ((((g >> 2) | (g << 30)) ^ ((g >> 13) | (g << 19)) ^ ((g >> 22) | (g << 10))) + ((g & h) ^ (g & a) ^ (h & a)));
		r = e + (((b >> 6) | (b << 26)) ^ ((b >> 11) | (b << 21)) ^ ((b >> 25) | (b << 7))) + ((b & c) ^ (~b & d)) + w11 + 0x550c7dc3UL;
		a += r;
		e = r + ((((f >> 2) | (f << 30)) ^ ((f >> 13) | (f << 19)) ^ ((f >> 22) | (f << 10))) + ((f & g) ^ (f & h) ^ (g & h)));
		r = d + (((a >> 6) | (a << 26)) ^ ((a >> 11) | (a << 21)) ^ ((a >> 25) | (a << 7))) + ((a & b) ^ (~a & c)) + w12 + 0x72be5d74UL;
		h += r;
		d = r + ((((e >> 2) | (e << 30)) ^ ((e >> 13) | (e << 19)) ^ ((e >> 22) | (e << 10))) + ((e & f) ^ (e & g) ^ (f & g)));
		r = c + (((h >> 6) | (h << 26)) ^ ((h >> 11) | (h << 21)) ^ ((h >> 25) | (h << 7))) + ((h & a) ^ (~h & b)) + w13 + 0x80deb1feUL;
		g += r;
		c = r + ((((d >> 2) | (d << 30)) ^ ((d >> 13) | (d << 19)) ^ ((d >> 22) | (d << 10))) + ((d & e) ^ (d & f) ^ (e & f)));
		r = b + (((g >> 6) | (g << 26)) ^ ((g >> 11) | (g << 21)) ^ ((g >> 25) | (g << 7))) + ((g & h) ^ (~g & a)) + w14 + 0x9bdc06a7UL;
		f += r;
		b = r + ((((c >> 2) | (c << 30)) ^ ((c >> 13) | (c << 19)) ^ ((c >> 22) | (c << 10))) + ((c & d) ^ (c & e) ^ (d & e)));
		r = a + (((f >> 6) | (f << 26)) ^ ((f >> 11) | (f << 21)) ^ ((f >> 25) | (f << 7))) + ((f & g) ^ (~f & h)) + w15 + 0xc19bf174UL;
		e += r;
		a = r + ((((b >> 2) | (b << 30)) ^ ((b >> 13) | (b << 19)) ^ ((b >> 22) | (b << 10))) + ((b & c) ^ (b & d) ^ (c & d)));

		w0 += (((w14 >> 17) | (w14 << 15)) ^ ((w14 >> 19) | (w14 << 13)) ^ (w14 >> 10)) + w9 + (((w1 >> 7) | (w1 << 25)) ^ ((w1 >> 18) | (w1 << 14)) ^ (w1 >> 3));
		r = h + (((e >> 6) | (e << 26)) ^ ((e >> 11) | (e << 21)) ^ ((e >> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + w0 + 0xe49b69c1UL;
		d += r;
		h = r + ((((a >> 2) | (a << 30)) ^ ((a >> 13) | (a << 19)) ^ ((a >> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c)));
		w1 += (((w15 >> 17) | (w15 << 15)) ^ ((w15 >> 19) | (w15 << 13)) ^ (w15 >> 10)) + w10 + (((w2 >> 7) | (w2 << 25)) ^ ((w2 >> 18) | (w2 << 14)) ^ (w2 >> 3));
		r = g + (((d >> 6) | (d << 26)) ^ ((d >> 11) | (d << 21)) ^ ((d >> 25) | (d << 7))) + ((d & e) ^ (~d & f)) + w1 + 0xefbe4786UL;
		c += r;
		g = r + ((((h >> 2) | (h << 30)) ^ ((h >> 13) | (h << 19)) ^ ((h >> 22) | (h << 10))) + ((h & a) ^ (h & b) ^ (a & b)));
		w2 += (((w0 >> 17) | (w0 << 15)) ^ ((w0 >> 19) | (w0 << 13)) ^ (w0 >> 10)) + w11 + (((w3 >> 7) | (w3 << 25)) ^ ((w3 >> 18) | (w3 << 14)) ^ (w3 >> 3));
		r = f + (((c >> 6) | (c << 26)) ^ ((c >> 11) | (c << 21)) ^ ((c >> 25) | (c << 7))) + ((c & d) ^ (~c & e)) + w2 + 0x0fc19dc6UL;
		b += r;
		f = r + ((((g >> 2) | (g << 30)) ^ ((g >> 13) | (g << 19)) ^ ((g >> 22) | (g << 10))) + ((g & h) ^ (g & a) ^ (h & a)));
		w3 += (((w1 >> 17) | (w1 << 15)) ^ ((w1 >> 19) | (w1 << 13)) ^ (w1 >> 10)) + w12 + (((w4 >> 7) | (w4 << 25)) ^ ((w4 >> 18) | (w4 << 14)) ^ (w4 >> 3));
		r = e + (((b >> 6) | (b << 26)) ^ ((b >> 11) | (b << 21)) ^ ((b >> 25) | (b << 7))) + ((b & c) ^ (~b & d)) + w3 + 0x240ca1ccUL;
		a += r;
		e = r + ((((f >> 2) | (f << 30)) ^ ((f >> 13) | (f << 19)) ^ ((f >> 22) | (f << 10))) + ((f & g) ^ (f & h) ^ (g & h)));
		w4 += (((w2 >> 17) | (w2 << 15)) ^ ((w2 >> 19) | (w2 << 13)) ^ (w2 >> 10)) + w13 + (((w5 >> 7) | (w5 << 25)) ^ ((w5 >> 18) | (w5 << 14)) ^ (w5 >> 3));
		r = d + (((a >> 6) | (a << 26)) ^ ((a >> 11) | (a << 21)) ^ ((a >> 25) | (a << 7))) + ((a & b) ^ (~a & c)) + w4 + 0x2de92c6fUL;
		h += r;
		d = r + ((((e >> 2) | (e << 30)) ^ ((e >> 13) | (e << 19)) ^ ((e >> 22) | (e << 10))) + ((e & f) ^ (e & g) ^ (f & g)));
		w5 += (((w3 >> 17) | (w3 << 15)) ^ ((w3 >> 19) | (w3 << 13)) ^ (w3 >> 10)) + w14 + (((w6 >> 7) | (w6 << 25)) ^ ((w6 >> 18) | (w6 << 14)) ^ (w6 >> 3));
		r = c + (((h >> 6) | (h << 26)) ^ ((h >> 11) | (h << 21)) ^ ((h >> 25) | (h << 7))) + ((h & a) ^ (~h & b)) + w5 + 0x4a7484aaUL;
		g += r;
		c = r + ((((d >> 2) | (d << 30)) ^ ((d >> 13) | (d << 19)) ^ ((d >> 22) | (d << 10))) + ((d & e) ^ (d & f) ^ (e & f)));
		w6 += (((w4 >> 17) | (w4 << 15)) ^ ((w4 >> 19) | (w4 << 13)) ^ (w4 >> 10)) + w15 + (((w7 >> 7) | (w7 << 25)) ^ ((w7 >> 18) | (w7 << 14)) ^ (w7 >> 3));
		r = b + (((g >> 6) | (g << 26)) ^ ((g >> 11) | (g << 21)) ^ ((g >> 25) | (g << 7))) + ((g & h) ^ (~g & a)) + w6 + 0x5cb0a9dcUL;
		f += r;
		b = r + ((((c >> 2) | (c << 30)) ^ ((c >> 13) | (c << 19)) ^ ((c >> 22) | (c << 10))) + ((c & d) ^ (c & e) ^ (d & e)));
		w7 += (((w5 >> 17) | (w5 << 15)) ^ ((w5 >> 19) | (w5 << 13)) ^ (w5 >> 10)) + w0 + (((w8 >> 7) | (w8 << 25)) ^ ((w8 >> 18) | (w8 << 14)) ^ (w8 >> 3));
		r = a + (((f >> 6) | (f << 26)) ^ ((f >> 11) | (f << 21)) ^ ((f >> 25) | (f << 7))) + ((f & g) ^ (~f & h)) + w7 + 0x76f988daUL;
		e += r;
		a = r + ((((b >> 2) | (b << 30)) ^ ((b >> 13) | (b << 19)) ^ ((b >> 22) | (b << 10))) + ((b & c) ^ (b & d) ^ (c & d)));
		w8 += (((w6 >> 17) | (w6 << 15)) ^ ((w6 >> 19) | (w6 << 13)) ^ (w6 >> 10)) + w1 + (((w9 >> 7) | (w9 << 25)) ^ ((w9 >> 18) | (w9 << 14)) ^ (w9 >> 3));
		r = h + (((e >> 6) | (e << 26)) ^ ((e >> 11) | (e << 21)) ^ ((e >> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + w8 + 0x983e5152UL;
		d += r;
		h = r + ((((a >> 2) | (a << 30)) ^ ((a >> 13) | (a << 19)) ^ ((a >> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c)));
		w9 += (((w7 >> 17) | (w7 << 15)) ^ ((w7 >> 19) | (w7 << 13)) ^ (w7 >> 10)) + w2 + (((w10 >> 7) | (w10 << 25)) ^ ((w10 >> 18) | (w10 << 14)) ^ (w10 >> 3));
		r = g + (((d >> 6) | (d << 26)) ^ ((d >> 11) | (d << 21)) ^ ((d >> 25) | (d << 7))) + ((d & e) ^ (~d & f)) + w9 + 0xa831c66dUL;
		c += r;
		g = r + ((((h >> 2) | (h << 30)) ^ ((h >> 13) | (h << 19)) ^ ((h >> 22) | (h << 10))) + ((h & a) ^ (h & b) ^ (a & b)));
		w10 += (((w8 >> 17) | (w8 << 15)) ^ ((w8 >> 19) | (w8 << 13)) ^ (w8 >> 10)) + w3 + (((w11 >> 7) | (w11 << 25)) ^ ((w11 >> 18) | (w11 << 14)) ^ (w11 >> 3));
		r = f + (((c >> 6) | (c << 26)) ^ ((c >> 11) | (c << 21)) ^ ((c >> 25) | (c << 7))) + ((c & d) ^ (~c & e)) + w10 + 0xb00327c8UL;
		b += r;
		f = r + ((((g >> 2) | (g << 30)) ^ ((g >> 13) | (g << 19)) ^ ((g >> 22) | (g << 10))) + ((g & h) ^ (g & a) ^ (h & a)));
		w11 += (((w9 >> 17) | (w9 << 15)) ^ ((w9 >> 19) | (w9 << 13)) ^ (w9 >> 10)) + w4 + (((w12 >> 7) | (w12 << 25)) ^ ((w12 >> 18) | (w12 << 14)) ^ (w12 >> 3));
		r = e + (((b >> 6) | (b << 26)) ^ ((b >> 11) | (b << 21)) ^ ((b >> 25) | (b << 7))) + ((b & c) ^ (~b & d)) + w11 + 0xbf597fc7UL;
		a += r;
		e = r + ((((f >> 2) | (f << 30)) ^ ((f >> 13) | (f << 19)) ^ ((f >> 22) | (f << 10))) + ((f & g) ^ (f & h) ^ (g & h)));
		w12 += (((w10 >> 17) | (w10 << 15)) ^ ((w10 >> 19) | (w10 << 13)) ^ (w10 >> 10)) + w5 + (((w13 >> 7) | (w13 << 25)) ^ ((w13 >> 18) | (w13 << 14)) ^ (w13 >> 3));
		r = d + (((a >> 6) | (a << 26)) ^ ((a >> 11) | (a << 21)) ^ ((a >> 25) | (a << 7))) + ((a & b) ^ (~a & c)) + w12 + 0xc6e00bf3UL;
		h += r;
		d = r + ((((e >> 2) | (e << 30)) ^ ((e >> 13) | (e << 19)) ^ ((e >> 22) | (e << 10))) + ((e & f) ^ (e & g) ^ (f & g)));
		w13 += (((w11 >> 17) | (w11 << 15)) ^ ((w11 >> 19) | (w11 << 13)) ^ (w11 >> 10)) + w6 + (((w14 >> 7) | (w14 << 25)) ^ ((w14 >> 18) | (w14 << 14)) ^ (w14 >> 3));
		r = c + (((h >> 6) | (h << 26)) ^ ((h >> 11) | (h << 21)) ^ ((h >> 25) | (h << 7))) + ((h & a) ^ (~h & b)) + w13 + 0xd5a79147UL;
		g += r;
		c = r + ((((d >> 2) | (d << 30)) ^ ((d >> 13) | (d << 19)) ^ ((d >> 22) | (d << 10))) + ((d & e) ^ (d & f) ^ (e & f)));
		w14 += (((w12 >> 17) | (w12 << 15)) ^ ((w12 >> 19) | (w12 << 13)) ^ (w12 >> 10)) + w7 + (((w15 >> 7) | (w15 << 25)) ^ ((w15 >> 18) | (w15 << 14)) ^ (w15 >> 3));
		r = b + (((g >> 6) | (g << 26)) ^ ((g >> 11) | (g << 21)) ^ ((g >> 25) | (g << 7))) + ((g & h) ^ (~g & a)) + w14 + 0x06ca6351UL;
		f += r;
		b = r + ((((c >> 2) | (c << 30)) ^ ((c >> 13) | (c << 19)) ^ ((c >> 22) | (c << 10))) + ((c & d) ^ (c & e) ^ (d & e)));
		w15 += (((w13 >> 17) | (w13 << 15)) ^ ((w13 >> 19) | (w13 << 13)) ^ (w13 >> 10)) + w8 + (((w0 >> 7) | (w0 << 25)) ^ ((w0 >> 18) | (w0 << 14)) ^ (w0 >> 3));
		r = a + (((f >> 6) | (f << 26)) ^ ((f >> 11) | (f << 21)) ^ ((f >> 25) | (f << 7))) + ((f & g) ^ (~f & h)) + w15 + 0x14292967UL;
		e += r;
		a = r + ((((b >> 2) | (b << 30)) ^ ((b >> 13) | (b << 19)) ^ ((b >> 22) | (b << 10))) + ((b & c) ^ (b & d) ^ (c & d)));

		w0 += (((w14 >> 17) | (w14 << 15)) ^ ((w14 >> 19) | (w14 << 13)) ^ (w14 >> 10)) + w9 + (((w1 >> 7) | (w1 << 25)) ^ ((w1 >> 18) | (w1 << 14)) ^ (w1 >> 3));
		r = h + (((e >> 6) | (e << 26)) ^ ((e >> 11) | (e << 21)) ^ ((e >> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + w0 + 0x27b70a85UL;
		d += r;
		h = r + ((((a >> 2) | (a << 30)) ^ ((a >> 13) | (a << 19)) ^ ((a >> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c)));
		w1 += (((w15 >> 17) | (w15 << 15)) ^ ((w15 >> 19) | (w15 << 13)) ^ (w15 >> 10)) + w10 + (((w2 >> 7) | (w2 << 25)) ^ ((w2 >> 18) | (w2 << 14)) ^ (w2 >> 3));
		r = g + (((d >> 6) | (d << 26)) ^ ((d >> 11) | (d << 21)) ^ ((d >> 25) | (d << 7))) + ((d & e) ^ (~d & f)) + w1 + 0x2e1b2138UL;
		c += r;
		g = r + ((((h >> 2) | (h << 30)) ^ ((h >> 13) | (h << 19)) ^ ((h >> 22) | (h << 10))) + ((h & a) ^ (h & b) ^ (a & b)));
		w2 += (((w0 >> 17) | (w0 << 15)) ^ ((w0 >> 19) | (w0 << 13)) ^ (w0 >> 10)) + w11 + (((w3 >> 7) | (w3 << 25)) ^ ((w3 >> 18) | (w3 << 14)) ^ (w3 >> 3));
		r = f + (((c >> 6) | (c << 26)) ^ ((c >> 11) | (c << 21)) ^ ((c >> 25) | (c << 7))) + ((c & d) ^ (~c & e)) + w2 + 0x4d2c6dfcUL;
		b += r;
		f = r + ((((g >> 2) | (g << 30)) ^ ((g >> 13) | (g << 19)) ^ ((g >> 22) | (g << 10))) + ((g & h) ^ (g & a) ^ (h & a)));
		w3 += (((w1 >> 17) | (w1 << 15)) ^ ((w1 >> 19) | (w1 << 13)) ^ (w1 >> 10)) + w12 + (((w4 >> 7) | (w4 << 25)) ^ ((w4 >> 18) | (w4 << 14)) ^ (w4 >> 3));
		r = e + (((b >> 6) | (b << 26)) ^ ((b >> 11) | (b << 21)) ^ ((b >> 25) | (b << 7))) + ((b & c) ^ (~b & d)) + w3 + 0x53380d13UL;
		a += r;
		e = r + ((((f >> 2) | (f << 30)) ^ ((f >> 13) | (f << 19)) ^ ((f >> 22) | (f << 10))) + ((f & g) ^ (f & h) ^ (g & h)));
		w4 += (((w2 >> 17) | (w2 << 15)) ^ ((w2 >> 19) | (w2 << 13)) ^ (w2 >> 10)) + w13 + (((w5 >> 7) | (w5 << 25)) ^ ((w5 >> 18) | (w5 << 14)) ^ (w5 >> 3));
		r = d + (((a >> 6) | (a << 26)) ^ ((a >> 11) | (a << 21)) ^ ((a >> 25) | (a << 7))) + ((a & b) ^ (~a & c)) + w4 + 0x650a7354UL;
		h += r;
		d = r + ((((e >> 2) | (e << 30)) ^ ((e >> 13) | (e << 19)) ^ ((e >> 22) | (e << 10))) + ((e & f) ^ (e & g) ^ (f & g)));
		w5 += (((w3 >> 17) | (w3 << 15)) ^ ((w3 >> 19) | (w3 << 13)) ^ (w3 >> 10)) + w14 + (((w6 >> 7) | (w6 << 25)) ^ ((w6 >> 18) | (w6 << 14)) ^ (w6 >> 3));
		r = c + (((h >> 6) | (h << 26)) ^ ((h >> 11) | (h << 21)) ^ ((h >> 25) | (h << 7))) + ((h & a) ^ (~h & b)) + w5 + 0x766a0abbUL;
		g += r;
		c = r + ((((d >> 2) | (d << 30)) ^ ((d >> 13) | (d << 19)) ^ ((d >> 22) | (d << 10))) + ((d & e) ^ (d & f) ^ (e & f)));
		w6 += (((w4 >> 17) | (w4 << 15)) ^ ((w4 >> 19) | (w4 << 13)) ^ (w4 >> 10)) + w15 + (((w7 >> 7) | (w7 << 25)) ^ ((w7 >> 18) | (w7 << 14)) ^ (w7 >> 3));
		r = b + (((g >> 6) | (g << 26)) ^ ((g >> 11) | (g << 21)) ^ ((g >> 25) | (g << 7))) + ((g & h) ^ (~g & a)) + w6 + 0x81c2c92eUL;
		f += r;
		b = r + ((((c >> 2) | (c << 30)) ^ ((c >> 13) | (c << 19)) ^ ((c >> 22) | (c << 10))) + ((c & d) ^ (c & e) ^ (d & e)));
		w7 += (((w5 >> 17) | (w5 << 15)) ^ ((w5 >> 19) | (w5 << 13)) ^ (w5 >> 10)) + w0 + (((w8 >> 7) | (w8 << 25)) ^ ((w8 >> 18) | (w8 << 14)) ^ (w8 >> 3));
		r = a + (((f >> 6) | (f << 26)) ^ ((f >> 11) | (f << 21)) ^ ((f >> 25) | (f << 7))) + ((f & g) ^ (~f & h)) + w7 + 0x92722c85UL;
		e += r;
		a = r + ((((b >> 2) | (b << 30)) ^ ((b >> 13) | (b << 19)) ^ ((b >> 22) | (b << 10))) + ((b & c) ^ (b & d) ^ (c & d)));
		w8 += (((w6 >> 17) | (w6 << 15)) ^ ((w6 >> 19) | (w6 << 13)) ^ (w6 >> 10)) + w1 + (((w9 >> 7) | (w9 << 25)) ^ ((w9 >> 18) | (w9 << 14)) ^ (w9 >> 3));
		r = h + (((e >> 6) | (e << 26)) ^ ((e >> 11) | (e << 21)) ^ ((e >> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + w8 + 0xa2bfe8a1UL;
		d += r;
		h = r + ((((a >> 2) | (a << 30)) ^ ((a >> 13) | (a << 19)) ^ ((a >> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c)));
		w9 += (((w7 >> 17) | (w7 << 15)) ^ ((w7 >> 19) | (w7 << 13)) ^ (w7 >> 10)) + w2 + (((w10 >> 7) | (w10 << 25)) ^ ((w10 >> 18) | (w10 << 14)) ^ (w10 >> 3));
		r = g + (((d >> 6) | (d << 26)) ^ ((d >> 11) | (d << 21)) ^ ((d >> 25) | (d << 7))) + ((d & e) ^ (~d & f)) + w9 + 0xa81a664bUL;
		c += r;
		g = r + ((((h >> 2) | (h << 30)) ^ ((h >> 13) | (h << 19)) ^ ((h >> 22) | (h << 10))) + ((h & a) ^ (h & b) ^ (a & b)));
		w10 += (((w8 >> 17) | (w8 << 15)) ^ ((w8 >> 19) | (w8 << 13)) ^ (w8 >> 10)) + w3 + (((w11 >> 7) | (w11 << 25)) ^ ((w11 >> 18) | (w11 << 14)) ^ (w11 >> 3));
		r = f + (((c >> 6) | (c << 26)) ^ ((c >> 11) | (c << 21)) ^ ((c >> 25) | (c << 7))) + ((c & d) ^ (~c & e)) + w10 + 0xc24b8b70UL;
		b += r;
		f = r + ((((g >> 2) | (g << 30)) ^ ((g >> 13) | (g << 19)) ^ ((g >> 22) | (g << 10))) + ((g & h) ^ (g & a) ^ (h & a)));
		w11 += (((w9 >> 17) | (w9 << 15)) ^ ((w9 >> 19) | (w9 << 13)) ^ (w9 >> 10)) + w4 + (((w12 >> 7) | (w12 << 25)) ^ ((w12 >> 18) | (w12 << 14)) ^ (w12 >> 3));
		r = e + (((b >> 6) | (b << 26)) ^ ((b >> 11) | (b << 21)) ^ ((b >> 25) | (b << 7))) + ((b & c) ^ (~b & d)) + w11 + 0xc76c51a3UL;
		a += r;
		e = r + ((((f >> 2) | (f << 30)) ^ ((f >> 13) | (f << 19)) ^ ((f >> 22) | (f << 10))) + ((f & g) ^ (f & h) ^ (g & h)));
		w12 += (((w10 >> 17) | (w10 << 15)) ^ ((w10 >> 19) | (w10 << 13)) ^ (w10 >> 10)) + w5 + (((w13 >> 7) | (w13 << 25)) ^ ((w13 >> 18) | (w13 << 14)) ^ (w13 >> 3));
		r = d + (((a >> 6) | (a << 26)) ^ ((a >> 11) | (a << 21)) ^ ((a >> 25) | (a << 7))) + ((a & b) ^ (~a & c)) + w12 + 0xd192e819UL;
		h += r;
		d = r + ((((e >> 2) | (e << 30)) ^ ((e >> 13) | (e << 19)) ^ ((e >> 22) | (e << 10))) + ((e & f) ^ (e & g) ^ (f & g)));
		w13 += (((w11 >> 17) | (w11 << 15)) ^ ((w11 >> 19) | (w11 << 13)) ^ (w11 >> 10)) + w6 + (((w14 >> 7) | (w14 << 25)) ^ ((w14 >> 18) | (w14 << 14)) ^ (w14 >> 3));
		r = c + (((h >> 6) | (h << 26)) ^ ((h >> 11) | (h << 21)) ^ ((h >> 25) | (h << 7))) + ((h & a) ^ (~h & b)) + w13 + 0xd6990624UL;
		g += r;
		c = r + ((((d >> 2) | (d << 30)) ^ ((d >> 13) | (d << 19)) ^ ((d >> 22) | (d << 10))) + ((d & e) ^ (d & f) ^ (e & f)));
		w14 += (((w12 >> 17) | (w12 << 15)) ^ ((w12 >> 19) | (w12 << 13)) ^ (w12 >> 10)) + w7 + (((w15 >> 7) | (w15 << 25)) ^ ((w15 >> 18) | (w15 << 14)) ^ (w15 >> 3));
		r = b + (((g >> 6) | (g << 26)) ^ ((g >> 11) | (g << 21)) ^ ((g >> 25) | (g << 7))) + ((g & h) ^ (~g & a)) + w14 + 0xf40e3585UL;
		f += r;
		b = r + ((((c >> 2) | (c << 30)) ^ ((c >> 13) | (c << 19)) ^ ((c >> 22) | (c << 10))) + ((c & d) ^ (c & e) ^ (d & e)));
		w15 += (((w13 >> 17) | (w13 << 15)) ^ ((w13 >> 19) | (w13 << 13)) ^ (w13 >> 10)) + w8 + (((w0 >> 7) | (w0 << 25)) ^ ((w0 >> 18) | (w0 << 14)) ^ (w0 >> 3));
		r = a + (((f >> 6) | (f << 26)) ^ ((f >> 11) | (f << 21)) ^ ((f >> 25) | (f << 7))) + ((f & g) ^ (~f & h)) + w15 + 0x106aa070UL;
		e += r;
		a = r + ((((b >> 2) | (b << 30)) ^ ((b >> 13) | (b << 19)) ^ ((b >> 22) | (b << 10))) + ((b & c) ^ (b & d) ^ (c & d)));

		w0 += (((w14 >> 17) | (w14 << 15)) ^ ((w14 >> 19) | (w14 << 13)) ^ (w14 >> 10)) + w9 + (((w1 >> 7) | (w1 << 25)) ^ ((w1 >> 18) | (w1 << 14)) ^ (w1 >> 3));
		r = h + (((e >> 6) | (e << 26)) ^ ((e >> 11) | (e << 21)) ^ ((e >> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + w0 + 0x19a4c116UL;
		d += r;
		h = r + ((((a >> 2) | (a << 30)) ^ ((a >> 13) | (a << 19)) ^ ((a >> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c)));
		w1 += (((w15 >> 17) | (w15 << 15)) ^ ((w15 >> 19) | (w15 << 13)) ^ (w15 >> 10)) + w10 + (((w2 >> 7) | (w2 << 25)) ^ ((w2 >> 18) | (w2 << 14)) ^ (w2 >> 3));
		r = g + (((d >> 6) | (d << 26)) ^ ((d >> 11) | (d << 21)) ^ ((d >> 25) | (d << 7))) + ((d & e) ^ (~d & f)) + w1 + 0x1e376c08UL;
		c += r;
		g = r + ((((h >> 2) | (h << 30)) ^ ((h >> 13) | (h << 19)) ^ ((h >> 22) | (h << 10))) + ((h & a) ^ (h & b) ^ (a & b)));
		w2 += (((w0 >> 17) | (w0 << 15)) ^ ((w0 >> 19) | (w0 << 13)) ^ (w0 >> 10)) + w11 + (((w3 >> 7) | (w3 << 25)) ^ ((w3 >> 18) | (w3 << 14)) ^ (w3 >> 3));
		r = f + (((c >> 6) | (c << 26)) ^ ((c >> 11) | (c << 21)) ^ ((c >> 25) | (c << 7))) + ((c & d) ^ (~c & e)) + w2 + 0x2748774cUL;
		b += r;
		f = r + ((((g >> 2) | (g << 30)) ^ ((g >> 13) | (g << 19)) ^ ((g >> 22) | (g << 10))) + ((g & h) ^ (g & a) ^ (h & a)));
		w3 += (((w1 >> 17) | (w1 << 15)) ^ ((w1 >> 19) | (w1 << 13)) ^ (w1 >> 10)) + w12 + (((w4 >> 7) | (w4 << 25)) ^ ((w4 >> 18) | (w4 << 14)) ^ (w4 >> 3));
		r = e + (((b >> 6) | (b << 26)) ^ ((b >> 11) | (b << 21)) ^ ((b >> 25) | (b << 7))) + ((b & c) ^ (~b & d)) + w3 + 0x34b0bcb5UL;
		a += r;
		e = r + ((((f >> 2) | (f << 30)) ^ ((f >> 13) | (f << 19)) ^ ((f >> 22) | (f << 10))) + ((f & g) ^ (f & h) ^ (g & h)));
		w4 += (((w2 >> 17) | (w2 << 15)) ^ ((w2 >> 19) | (w2 << 13)) ^ (w2 >> 10)) + w13 + (((w5 >> 7) | (w5 << 25)) ^ ((w5 >> 18) | (w5 << 14)) ^ (w5 >> 3));
		r = d + (((a >> 6) | (a << 26)) ^ ((a >> 11) | (a << 21)) ^ ((a >> 25) | (a << 7))) + ((a & b) ^ (~a & c)) + w4 + 0x391c0cb3UL;
		h += r;
		d = r + ((((e >> 2) | (e << 30)) ^ ((e >> 13) | (e << 19)) ^ ((e >> 22) | (e << 10))) + ((e & f) ^ (e & g) ^ (f & g)));
		w5 += (((w3 >> 17) | (w3 << 15)) ^ ((w3 >> 19) | (w3 << 13)) ^ (w3 >> 10)) + w14 + (((w6 >> 7) | (w6 << 25)) ^ ((w6 >> 18) | (w6 << 14)) ^ (w6 >> 3));
		r = c + (((h >> 6) | (h << 26)) ^ ((h >> 11) | (h << 21)) ^ ((h >> 25) | (h << 7))) + ((h & a) ^ (~h & b)) + w5 + 0x4ed8aa4aUL;
		g += r;
		c = r + ((((d >> 2) | (d << 30)) ^ ((d >> 13) | (d << 19)) ^ ((d >> 22) | (d << 10))) + ((d & e) ^ (d & f) ^ (e & f)));
		w6 += (((w4 >> 17) | (w4 << 15)) ^ ((w4 >> 19) | (w4 << 13)) ^ (w4 >> 10)) + w15 + (((w7 >> 7) | (w7 << 25)) ^ ((w7 >> 18) | (w7 << 14)) ^ (w7 >> 3));
		r = b + (((g >> 6) | (g << 26)) ^ ((g >> 11) | (g << 21)) ^ ((g >> 25) | (g << 7))) + ((g & h) ^ (~g & a)) + w6 + 0x5b9cca4fUL;
		f += r;
		b = r + ((((c >> 2) | (c << 30)) ^ ((c >> 13) | (c << 19)) ^ ((c >> 22) | (c << 10))) + ((c & d) ^ (c & e) ^ (d & e)));
		w7 += (((w5 >> 17) | (w5 << 15)) ^ ((w5 >> 19) | (w5 << 13)) ^ (w5 >> 10)) + w0 + (((w8 >> 7) | (w8 << 25)) ^ ((w8 >> 18) | (w8 << 14)) ^ (w8 >> 3));
		r = a + (((f >> 6) | (f << 26)) ^ ((f >> 11) | (f << 21)) ^ ((f >> 25) | (f << 7))) + ((f & g) ^ (~f & h)) + w7 + 0x682e6ff3UL;
		e += r;
		a = r + ((((b >> 2) | (b << 30)) ^ ((b >> 13) | (b << 19)) ^ ((b >> 22) | (b << 10))) + ((b & c) ^ (b & d) ^ (c & d)));
		w8 += (((w6 >> 17) | (w6 << 15)) ^ ((w6 >> 19) | (w6 << 13)) ^ (w6 >> 10)) + w1 + (((w9 >> 7) | (w9 << 25)) ^ ((w9 >> 18) | (w9 << 14)) ^ (w9 >> 3));
		r = h + (((e >> 6) | (e << 26)) ^ ((e >> 11) | (e << 21)) ^ ((e >> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + w8 + 0x748f82eeUL;
		d += r;
		h = r + ((((a >> 2) | (a << 30)) ^ ((a >> 13) | (a << 19)) ^ ((a >> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c)));
		w9 += (((w7 >> 17) | (w7 << 15)) ^ ((w7 >> 19) | (w7 << 13)) ^ (w7 >> 10)) + w2 + (((w10 >> 7) | (w10 << 25)) ^ ((w10 >> 18) | (w10 << 14)) ^ (w10 >> 3));
		r = g + (((d >> 6) | (d << 26)) ^ ((d >> 11) | (d << 21)) ^ ((d >> 25) | (d << 7))) + ((d & e) ^ (~d & f)) + w9 + 0x78a5636fUL;
		c += r;
		g = r + ((((h >> 2) | (h << 30)) ^ ((h >> 13) | (h << 19)) ^ ((h >> 22) | (h << 10))) + ((h & a) ^ (h & b) ^ (a & b)));
		w10 += (((w8 >> 17) | (w8 << 15)) ^ ((w8 >> 19) | (w8 << 13)) ^ (w8 >> 10)) + w3 + (((w11 >> 7) | (w11 << 25)) ^ ((w11 >> 18) | (w11 << 14)) ^ (w11 >> 3));
		r = f + (((c >> 6) | (c << 26)) ^ ((c >> 11) | (c << 21)) ^ ((c >> 25) | (c << 7))) + ((c & d) ^ (~c & e)) + w10 + 0x84c87814UL;
		b += r;
		f = r + ((((g >> 2) | (g << 30)) ^ ((g >> 13) | (g << 19)) ^ ((g >> 22) | (g << 10))) + ((g & h) ^ (g & a) ^ (h & a)));
		w11 += (((w9 >> 17) | (w9 << 15)) ^ ((w9 >> 19) | (w9 << 13)) ^ (w9 >> 10)) + w4 + (((w12 >> 7) | (w12 << 25)) ^ ((w12 >> 18) | (w12 << 14)) ^ (w12 >> 3));
		r = e + (((b >> 6) | (b << 26)) ^ ((b >> 11) | (b << 21)) ^ ((b >> 25) | (b << 7))) + ((b & c) ^ (~b & d)) + w11 + 0x8cc70208UL;
		a += r;
		e = r + ((((f >> 2) | (f << 30)) ^ ((f >> 13) | (f << 19)) ^ ((f >> 22) | (f << 10))) + ((f & g) ^ (f & h) ^ (g & h)));
		w12 += (((w10 >> 17) | (w10 << 15)) ^ ((w10 >> 19) | (w10 << 13)) ^ (w10 >> 10)) + w5 + (((w13 >> 7) | (w13 << 25)) ^ ((w13 >> 18) | (w13 << 14)) ^ (w13 >> 3));
		r = d + (((a >> 6) | (a << 26)) ^ ((a >> 11) | (a << 21)) ^ ((a >> 25) | (a << 7))) + ((a & b) ^ (~a & c)) + w12 + 0x90befffaUL;
		h += r;
		d = r + ((((e >> 2) | (e << 30)) ^ ((e >> 13) | (e << 19)) ^ ((e >> 22) | (e << 10))) + ((e & f) ^ (e & g) ^ (f & g)));
		w13 += (((w11 >> 17) | (w11 << 15)) ^ ((w11 >> 19) | (w11 << 13)) ^ (w11 >> 10)) + w6 + (((w14 >> 7) | (w14 << 25)) ^ ((w14 >> 18) | (w14 << 14)) ^ (w14 >> 3));
		r = c + (((h >> 6) | (h << 26)) ^ ((h >> 11) | (h << 21)) ^ ((h >> 25) | (h << 7))) + ((h & a) ^ (~h & b)) + w13 + 0xa4506cebUL;
		g += r;
		c = r + ((((d >> 2) | (d << 30)) ^ ((d >> 13) | (d << 19)) ^ ((d >> 22) | (d << 10))) + ((d & e) ^ (d & f) ^ (e & f)));
		w14 += (((w12 >> 17) | (w12 << 15)) ^ ((w12 >> 19) | (w12 << 13)) ^ (w12 >> 10)) + w7 + (((w15 >> 7) | (w15 << 25)) ^ ((w15 >> 18) | (w15 << 14)) ^ (w15 >> 3));
		r = b + (((g >> 6) | (g << 26)) ^ ((g >> 11) | (g << 21)) ^ ((g >> 25) | (g << 7))) + ((g & h) ^ (~g & a)) + w14 + 0xbef9a3f7UL;
		f += r;
		b = r + ((((c >> 2) | (c << 30)) ^ ((c >> 13) | (c << 19)) ^ ((c >> 22) | (c << 10))) + ((c & d) ^ (c & e) ^ (d & e)));
		w15 += (((w13 >> 17) | (w13 << 15)) ^ ((w13 >> 19) | (w13 << 13)) ^ (w13 >> 10)) + w8 + (((w0 >> 7) | (w0 << 25)) ^ ((w0 >> 18) | (w0 << 14)) ^ (w0 >> 3));
		r = a + (((f >> 6) | (f << 26)) ^ ((f >> 11) | (f << 21)) ^ ((f >> 25) | (f << 7))) + ((f & g) ^ (~f & h)) + w15 + 0xc67178f2UL;
		e += r;
		a = r + ((((b >> 2) | (b << 30)) ^ ((b >> 13) | (b << 19)) ^ ((b >> 22) | (b << 10))) + ((b & c) ^ (b & d) ^ (c & d)));

		output[0U] += a;
		output[1U] += b;
		output[2U] += c;
		output[3U] += d;
		output[4U] += e;
		output[5U] += f;
		output[6U] += g;
		output[7U] += h;
	}
}
#endif

#if defined(QSC_SHA2_SHANI_ENABLED) && defined(__GNUC__) && !defined(__clang__) && !defined(QSC_SYSTEM_ARM_SHA256_ENABLED)
static void sha256_compress_blocks(uint32_t* state, const uint8_t* message, size_t nblocks)
{
	sha256_shani_compress_blocks(state, message, nblocks);
}
#endif

void qsc_sha256_update(qsc_sha256_state* ctx, const uint8_t* message, size_t msglen)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);

	if (ctx != NULL && message != NULL && msglen != 0U)
	{
		if (ctx->position != 0U && (msglen >= QSC_SHA2_256_RATE - ctx->position))
		{
			const size_t RMDLEN = QSC_SHA2_256_RATE - ctx->position;

			if (RMDLEN != 0U)
			{
				qsc_memutils_copy((ctx->buffer + ctx->position), message, RMDLEN);
			}

			qsc_sha256_permute(ctx->state, ctx->buffer);
			sha256_increase(ctx, QSC_SHA2_256_RATE);
			ctx->position = 0U;
			message += RMDLEN;
			msglen -= RMDLEN;
		}

#if defined(QSC_SHA2_SHANI_ENABLED) && defined(__GNUC__) && !defined(__clang__) && !defined(QSC_SYSTEM_ARM_SHA256_ENABLED)
		/* SHA-NI keeps the chaining state in XMM registers between blocks. */
		if (msglen >= QSC_SHA2_256_RATE)
		{
			const size_t nblocks = msglen / QSC_SHA2_256_RATE;
			const size_t consumed = nblocks * QSC_SHA2_256_RATE;

			sha256_compress_blocks(ctx->state, message, nblocks);
			sha256_increase(ctx, consumed);
			message += consumed;
			msglen -= consumed;
		}
#else
		/* preserve the qualified single-block path on other architectures/compilers. */
		while (msglen >= QSC_SHA2_256_RATE)
		{
			qsc_sha256_permute(ctx->state, message);
			sha256_increase(ctx, QSC_SHA2_256_RATE);
			message += QSC_SHA2_256_RATE;
			msglen -= QSC_SHA2_256_RATE;
		}
#endif

		/* store unaligned bytes */
		if (msglen != 0U)
		{
			qsc_memutils_copy((ctx->buffer + ctx->position), message, msglen);
			ctx->position += msglen;
		}
	}
}

/* SHA2-384 */

static const uint64_t sha384_iv[8U] =
{
	0xCBBB9D5DC1059ED8ULL,
	0x629A292A367CD507ULL,
	0x9159015A3070DD17ULL,
	0x152FECD8F70E5939ULL,
	0x67332667FFC00B31ULL,
	0x8EB44A8768581511ULL,
	0xDB0C2E0D64F98FA7ULL,
	0x47B5481DBEFA4FA4ULL
};

static void sha384_increase(qsc_sha384_state* ctx, size_t length)
{
	QSC_ASSERT(ctx != NULL);

	if (ctx != NULL)
	{
		ctx->t[0U] += length;

		if (ctx->t[0U] > 0x1FFFFFFFFFFFFFFFULL)
		{
			ctx->t[1U] += (ctx->t[0U] >> 61);
			ctx->t[0U] &= 0x1FFFFFFFFFFFFFFFULL;
		}
	}
}

static void sha384_oneshot_small(uint8_t* output, const uint8_t* message, size_t msglen)
{
	/* one-rate SHA-384 one-shot hashing without general-purpose state buffering */
    uint64_t state[8U];
    uint8_t block[256U] = { 0U };
    size_t i;
    size_t blockcount;

    qsc_memutils_copy((uint8_t*)state, (const uint8_t*)sha384_iv, sizeof(state));

    if (msglen != 0U)
    {
        qsc_memutils_copy(block, message, msglen);
    }

    block[msglen] = 0x80U;
    blockcount = msglen <= 111U ? 1U : 2U;
    qsc_intutils_be64to8(block + (blockcount * 128U) - 8U, (uint64_t)(msglen * 8U));

    for (i = 0U; i < blockcount; ++i)
    {
        qsc_sha512_permute(state, block + (i * 128U));
    }

    for (i = 0U; i < 48U; i += 8U)
    {
        qsc_intutils_be64to8(output + i, state[i / 8U]);
    }

    qsc_memutils_secure_erase(state, sizeof(state));
    qsc_memutils_secure_erase(block, sizeof(block));
}

void qsc_sha384_compute(uint8_t* output, const uint8_t* message, size_t msglen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);

	qsc_sha384_state ctx;

	if (output != NULL && (message != NULL || msglen == 0U))
	{
		if (msglen <= QSC_SHA2_384_RATE)
		{
			sha384_oneshot_small(output, message, msglen);
		}
		else
		{
			qsc_sha384_initialize(&ctx);
			qsc_sha384_update(&ctx, message, msglen);
			qsc_sha384_finalize(&ctx, output);
		}
	}
}

void qsc_sha384_dispose(qsc_sha384_state* ctx)
{
	QSC_ASSERT(ctx != NULL);
	
	if (ctx != NULL)
	{
		qsc_memutils_secure_erase(ctx->state, sizeof(ctx->state));
		qsc_memutils_secure_erase(ctx->buffer, sizeof(ctx->buffer));
		ctx->t[0U] = 0U;
		ctx->t[1U] = 0U;
		ctx->position = 0U;
	}
}

void qsc_sha384_finalize(qsc_sha384_state* ctx, uint8_t* output)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(output != NULL);

	uint8_t pad[QSC_SHA2_384_RATE] = { 0U };
	uint64_t bitLen;

	if (ctx != NULL && output != NULL)
	{
		sha384_increase(ctx, ctx->position);
		bitLen = (ctx->t[0U] << 3);
		qsc_memutils_copy(pad, ctx->buffer, ctx->position);

		if (ctx->position == QSC_SHA2_384_RATE)
		{
			qsc_sha512_permute(ctx->state, pad);
			ctx->position = 0U;
		}

		pad[ctx->position] = 128U;
		++ctx->position;

		/* padding */
		if (ctx->position < QSC_SHA2_384_RATE)
		{
			qsc_memutils_clear((pad + ctx->position), QSC_SHA2_384_RATE - ctx->position);
		}

		if (ctx->position > 112U)
		{
			qsc_sha512_permute(ctx->state, pad);
			qsc_memutils_clear(pad, QSC_SHA2_384_RATE);
		}

		/* finalize state with counter and last compression */
		qsc_intutils_be64to8((pad + 112U), ctx->t[1U]);
		qsc_intutils_be64to8((pad + 120U), bitLen);
		qsc_sha512_permute(ctx->state, pad);

#if defined(QSC_SYSTEM_IS_BIG_ENDIAN)
		qsc_memutils_copy(output, (const uint8_t*)ctx->state, QSC_SHA2_384_HASH_SIZE);
#else
		for (size_t i = 0U; i < QSC_SHA2_384_HASH_SIZE; i += 8U)
		{
			qsc_intutils_be64to8((output + i), ctx->state[i / 8U]);
		}
#endif

		qsc_memutils_secure_erase(pad, sizeof(pad));
		qsc_sha384_dispose(ctx);
	}
}

void qsc_sha384_initialize(qsc_sha384_state* ctx)
{
	QSC_ASSERT(ctx != NULL);

	if (ctx != NULL)
	{
		qsc_memutils_copy((uint8_t*)ctx->state, (const uint8_t*)sha384_iv, sizeof(ctx->state));
		qsc_memutils_secure_erase(ctx->buffer, sizeof(ctx->buffer));
		ctx->t[0U] = 0U;
		ctx->t[1U] = 0U;
		ctx->position = 0U;
	}
}

#if defined(QSC_SYSTEM_X86) && defined(__AVX2__) && defined(__BMI2__)
static void sha512_compress_interleaved(uint64_t* output, const uint8_t* message);
#endif

void qsc_sha384_update(qsc_sha384_state* ctx, const uint8_t* message, size_t msglen)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);

	if (ctx != NULL && message != NULL && msglen != 0U)
	{
		if (ctx->position != 0U && (msglen >= QSC_SHA2_384_RATE - ctx->position))
		{
			const size_t RMDLEN = QSC_SHA2_384_RATE - ctx->position;

			if (RMDLEN != 0U)
			{
				qsc_memutils_copy((ctx->buffer + ctx->position), message, RMDLEN);
			}

			qsc_sha512_permute(ctx->state, ctx->buffer);
			sha384_increase(ctx, QSC_SHA2_384_RATE);
			ctx->position = 0U;
			message += RMDLEN;
			msglen -= RMDLEN;
		}

#if defined(QSC_SYSTEM_X86) && defined(__AVX2__) && defined(__BMI2__)
        if (msglen >= (4U * QSC_SHA2_384_RATE))
        {
            while (msglen >= QSC_SHA2_384_RATE)
            {
                sha512_compress_interleaved(ctx->state, message);
                sha384_increase(ctx, QSC_SHA2_384_RATE);
                message += QSC_SHA2_384_RATE;
                msglen -= QSC_SHA2_384_RATE;
            }
        }
        else
#endif
        {
		/* sequential loop through blocks */
		while (msglen >= QSC_SHA2_384_RATE)
		{
			qsc_sha512_permute(ctx->state, message);
			sha384_increase(ctx, QSC_SHA2_384_RATE);
			message += QSC_SHA2_384_RATE;
			msglen -= QSC_SHA2_384_RATE;
		}
        }

		/* store unaligned bytes */
		if (msglen != 0U)
		{
			qsc_memutils_copy((ctx->buffer + ctx->position), message, msglen);
			ctx->position += msglen;
		}
	}
}

/* SHA2-512 */

static const uint64_t sha512_iv[8U] =
{
	0x6A09E667F3BCC908ULL,
	0xBB67AE8584CAA73BULL,
	0x3C6EF372FE94F82BULL,
	0xA54FF53A5F1D36F1ULL,
	0x510E527FADE682D1ULL,
	0x9B05688C2B3E6C1FULL,
	0x1F83D9ABFB41BD6BULL,
	0x5BE0CD19137E2179ULL
};

static void sha512_increase(qsc_sha512_state* ctx, size_t length)
{
	QSC_ASSERT(ctx != NULL);

	ctx->t[0U] += length;

	if (ctx->t[0U] > 0x1FFFFFFFFFFFFFFFULL)
	{
		ctx->t[1U] += (ctx->t[0U] >> 61);
		ctx->t[0U] &= 0x1FFFFFFFFFFFFFFFULL;
	}
}

static void sha512_oneshot_small(uint8_t* output, const uint8_t* message, size_t msglen)
{
	/* one-rate SHA-512 one-shot hashing without general-purpose state buffering */
    uint64_t state[8U];
    uint8_t block[256U] = { 0U };
    size_t i;
    size_t blockcount;

    qsc_memutils_copy((uint8_t*)state, (const uint8_t*)sha512_iv, sizeof(state));

    if (msglen != 0U)
    {
        qsc_memutils_copy(block, message, msglen);
    }

    block[msglen] = 0x80U;
    blockcount = msglen <= 111U ? 1U : 2U;
    qsc_intutils_be64to8(block + (blockcount * 128U) - 8U, (uint64_t)(msglen * 8U));

    for (i = 0U; i < blockcount; ++i)
    {
        qsc_sha512_permute(state, block + (i * 128U));
    }

    for (i = 0U; i < 64U; i += 8U)
    {
        qsc_intutils_be64to8(output + i, state[i / 8U]);
    }

    qsc_memutils_secure_erase(state, sizeof(state));
    qsc_memutils_secure_erase(block, sizeof(block));
}

void qsc_sha512_compute(uint8_t* output, const uint8_t* message, size_t msglen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);

	qsc_sha512_state ctx;

	if (output != NULL && (message != NULL || msglen == 0U))
	{
		if (msglen <= QSC_SHA2_512_RATE)
		{
			sha512_oneshot_small(output, message, msglen);
		}
		else
		{
			qsc_sha512_initialize(&ctx);
			qsc_sha512_update(&ctx, message, msglen);
			qsc_sha512_finalize(&ctx, output);
		}
	}
}

void qsc_sha512_dispose(qsc_sha512_state* ctx)
{
	QSC_ASSERT(ctx != NULL);
	
	if (ctx != NULL)
	{
		qsc_memutils_secure_erase(ctx->state, sizeof(ctx->state));
		qsc_memutils_secure_erase(ctx->buffer, sizeof(ctx->buffer));
		ctx->t[0U] = 0U;
		ctx->t[1U] = 0U;
		ctx->position = 0U;
	}
}

void qsc_sha512_finalize(qsc_sha512_state* ctx, uint8_t* output)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(output != NULL);

	uint8_t pad[QSC_SHA2_512_RATE] = { 0U };
	uint64_t bitLen;

	if (ctx != NULL && output != NULL)
	{
		sha512_increase(ctx, ctx->position);
		bitLen = (ctx->t[0U] << 3);
		qsc_memutils_copy(pad, ctx->buffer, ctx->position);

		if (ctx->position == QSC_SHA2_512_RATE)
		{
			qsc_sha512_permute(ctx->state, pad);
			ctx->position = 0U;
		}

		pad[ctx->position] = 128U;
		++ctx->position;

		/* padding */
		if (ctx->position < QSC_SHA2_512_RATE)
		{
			qsc_memutils_clear((pad + ctx->position), QSC_SHA2_512_RATE - ctx->position);
		}

		if (ctx->position > 112U)
		{
			qsc_sha512_permute(ctx->state, pad);
			qsc_memutils_clear(pad, QSC_SHA2_512_RATE);
		}

		/* finalize state with counter and last compression */
		qsc_intutils_be64to8((pad + 112U), ctx->t[1U]);
		qsc_intutils_be64to8((pad + 120U), bitLen);
		qsc_sha512_permute(ctx->state, pad);

#if defined(QSC_SYSTEM_IS_BIG_ENDIAN)
		qsc_memutils_copy(output, (const uint8_t*)ctx->state, QSC_SHA2_512_HASH_SIZE);
#else
		for (size_t i = 0U; i < QSC_SHA2_512_HASH_SIZE; i += 8U)
		{
			qsc_intutils_be64to8((output + i), ctx->state[i / 8U]);
		}
#endif

		qsc_memutils_secure_erase(pad, sizeof(pad));
		qsc_sha512_dispose(ctx);
	}
}

void qsc_sha512_initialize(qsc_sha512_state* ctx)
{
	QSC_ASSERT(ctx != NULL);

	if (ctx != NULL)
	{
		qsc_memutils_copy((uint8_t*)ctx->state, (const uint8_t*)sha512_iv, sizeof(ctx->state));
		qsc_memutils_secure_erase(ctx->buffer, sizeof(ctx->buffer));
		ctx->t[0U] = 0U;
		ctx->t[1U] = 0U;
		ctx->position = 0U;
	}
}

#if defined(QSC_SYSTEM_ARM_SHA512_ENABLED)
/** 
* \brief Standard SHA-2 round constants in ascending round order. 
*/
static const uint64_t sha512_round_constants_arm[80U] =
{
	0x428a2f98d728ae22ULL, 0x7137449123ef65cdULL, 0xb5c0fbcfec4d3b2fULL, 0xe9b5dba58189dbbcULL,
	0x3956c25bf348b538ULL, 0x59f111f1b605d019ULL, 0x923f82a4af194f9bULL, 0xab1c5ed5da6d8118ULL,
	0xd807aa98a3030242ULL, 0x12835b0145706fbeULL, 0x243185be4ee4b28cULL, 0x550c7dc3d5ffb4e2ULL,
	0x72be5d74f27b896fULL, 0x80deb1fe3b1696b1ULL, 0x9bdc06a725c71235ULL, 0xc19bf174cf692694ULL,
	0xe49b69c19ef14ad2ULL, 0xefbe4786384f25e3ULL, 0x0fc19dc68b8cd5b5ULL, 0x240ca1cc77ac9c65ULL,
	0x2de92c6f592b0275ULL, 0x4a7484aa6ea6e483ULL, 0x5cb0a9dcbd41fbd4ULL, 0x76f988da831153b5ULL,
	0x983e5152ee66dfabULL, 0xa831c66d2db43210ULL, 0xb00327c898fb213fULL, 0xbf597fc7beef0ee4ULL,
	0xc6e00bf33da88fc2ULL, 0xd5a79147930aa725ULL, 0x06ca6351e003826fULL, 0x142929670a0e6e70ULL,
	0x27b70a8546d22ffcULL, 0x2e1b21385c26c926ULL, 0x4d2c6dfc5ac42aedULL, 0x53380d139d95b3dfULL,
	0x650a73548baf63deULL, 0x766a0abb3c77b2a8ULL, 0x81c2c92e47edaee6ULL, 0x92722c851482353bULL,
	0xa2bfe8a14cf10364ULL, 0xa81a664bbc423001ULL, 0xc24b8b70d0f89791ULL, 0xc76c51a30654be30ULL,
	0xd192e819d6ef5218ULL, 0xd69906245565a910ULL, 0xf40e35855771202aULL, 0x106aa07032bbd1b8ULL,
	0x19a4c116b8d2d0c8ULL, 0x1e376c085141ab53ULL, 0x2748774cdf8eeb99ULL, 0x34b0bcb5e19b48a8ULL,
	0x391c0cb3c5c95a63ULL, 0x4ed8aa4ae3418acbULL, 0x5b9cca4f7763e373ULL, 0x682e6ff3d6b2b8a3ULL,
	0x748f82ee5defb2fcULL, 0x78a5636f43172f60ULL, 0x84c87814a1f0ab72ULL, 0x8cc702081a6439ecULL,
	0x90befffa23631e28ULL, 0xa4506cebde82bde9ULL, 0xbef9a3f7b2c67915ULL, 0xc67178f2e372532bULL,
	0xca273eceea26619cULL, 0xd186b8c721c0c207ULL, 0xeada7dd6cde0eb1eULL, 0xf57d4f7fee6ed178ULL,
	0x06f067aa72176fbaULL, 0x0a637dc5a2c898a6ULL, 0x113f9804bef90daeULL, 0x1b710b35131c471bULL,
	0x28db77f523047d84ULL, 0x32caab7b40c72493ULL, 0x3c9ebe0a15c9bebcULL, 0x431d67c49c100d4cULL,
	0x4cc5d4becb3e42b6ULL, 0x597f299cfc657e2aULL, 0x5fcb6fab3ad6faecULL, 0x6c44198c4a475817ULL
};

void qsc_sha512_permute(uint64_t* output, const uint8_t* message)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL);

	if (output != NULL && message != NULL)
	{
		uint64x2_t schedule[8U];
		uint64x2_t ab;
		uint64x2_t cd;
		uint64x2_t ef;
		uint64x2_t gh;
		uint64x2_t nextab;
		uint64x2_t nextef;
		uint64x2_t words;
		uint64x2_t temp;

		ab = vld1q_u64(output);
		cd = vld1q_u64(output + 2U);
		ef = vld1q_u64(output + 4U);
		gh = vld1q_u64(output + 6U);

		for (size_t i = 0U; i < 8U; ++i)
		{
			words = vreinterpretq_u64_u8(vld1q_u8(message + (i * 16U)));
#if defined(QSC_SYSTEM_IS_LITTLE_ENDIAN)
			words = vreinterpretq_u64_u8(vrev64q_u8(vreinterpretq_u8_u64(words)));
#endif
			schedule[i] = words;
		}

		for (size_t i = 0U; i < 40U; ++i)
		{
			const size_t j = i & 7U;

			if (i >= 8U)
			{
				words = vextq_u64(schedule[(j + 4U) & 7U], schedule[(j + 5U) & 7U], 1);
				schedule[j] = vsha512su1q_u64(vsha512su0q_u64(schedule[j], schedule[(j + 1U) & 7U]), schedule[(j + 7U) & 7U], words);
			}

			words = vaddq_u64(schedule[j], vld1q_u64(sha512_round_constants_arm + (i * 2U)));
			temp = vaddq_u64(gh, vextq_u64(words, words, 1));
			temp = vsha512hq_u64(temp, vextq_u64(ef, gh, 1), vextq_u64(cd, ef, 1));
			nextab = vsha512h2q_u64(temp, cd, ab);
			nextef = vaddq_u64(cd, temp);
			cd = ab;
			gh = ef;
			ab = nextab;
			ef = nextef;
		}

		vst1q_u64(output, vaddq_u64(ab, vld1q_u64(output)));
		vst1q_u64(output + 2U, vaddq_u64(cd, vld1q_u64(output + 2U)));
		vst1q_u64(output + 4U, vaddq_u64(ef, vld1q_u64(output + 4U)));
		vst1q_u64(output + 6U, vaddq_u64(gh, vld1q_u64(output + 6U)));
		qsc_memutils_secure_erase(schedule, sizeof(schedule));
	}
}
#else
#if defined(QSC_SYSTEM_X86) && defined(__GNUC__) && !defined(__clang__)

static inline uint64_t sha512_load_be64(const uint8_t* input)
{
	/* read a SHA-512 big-endian word with inlined, unaligned-safe byte access */
	uint64_t result;

	result = ((uint64_t)input[0U] << 56U) |
		((uint64_t)input[1U] << 48U) |
		((uint64_t)input[2U] << 40U) |
		((uint64_t)input[3U] << 32U) |
		((uint64_t)input[4U] << 24U) |
		((uint64_t)input[5U] << 16U) |
		((uint64_t)input[6U] << 8U) |
		(uint64_t)input[7U];

	return result;
}
#endif

/** SHA-512 round constants, retained in read-only memory. */

/* keep the accepted volatile-table path except for GCC AVX-512, where
 * generated code incurs unnecessary round-constant memory loads */
#if defined(QSC_SYSTEM_X86) && defined(__AVX2__) && !(defined(__GNUC__) && !defined(__clang__) && defined(__AVX512F__))
static volatile const uint64_t sha512_round_constant_words[80U] =
#else
static const uint64_t sha512_round_constant_words[80U] =
#endif
{
    0x428A2F98D728AE22ULL, 0x7137449123EF65CDULL, 0xB5C0FBCFEC4D3B2FULL, 0xE9B5DBA58189DBBCULL,
    0x3956C25BF348B538ULL, 0x59F111F1B605D019ULL, 0x923F82A4AF194F9BULL, 0xAB1C5ED5DA6D8118ULL,
    0xD807AA98A3030242ULL, 0x12835B0145706FBEULL, 0x243185BE4EE4B28CULL, 0x550C7DC3D5FFB4E2ULL,
    0x72BE5D74F27B896FULL, 0x80DEB1FE3B1696B1ULL, 0x9BDC06A725C71235ULL, 0xC19BF174CF692694ULL,
    0xE49B69C19EF14AD2ULL, 0xEFBE4786384F25E3ULL, 0x0FC19DC68B8CD5B5ULL, 0x240CA1CC77AC9C65ULL,
    0x2DE92C6F592B0275ULL, 0x4A7484AA6EA6E483ULL, 0x5CB0A9DCBD41FBD4ULL, 0x76F988DA831153B5ULL,
    0x983E5152EE66DFABULL, 0xA831C66D2DB43210ULL, 0xB00327C898FB213FULL, 0xBF597FC7BEEF0EE4ULL,
    0xC6E00BF33DA88FC2ULL, 0xD5A79147930AA725ULL, 0x06CA6351E003826FULL, 0x142929670A0E6E70ULL,
    0x27B70A8546D22FFCULL, 0x2E1B21385C26C926ULL, 0x4D2C6DFC5AC42AEDULL, 0x53380D139D95B3DFULL,
    0x650A73548BAF63DEULL, 0x766A0ABB3C77B2A8ULL, 0x81C2C92E47EDAEE6ULL, 0x92722C851482353BULL,
    0xA2BFE8A14CF10364ULL, 0xA81A664BBC423001ULL, 0xC24B8B70D0F89791ULL, 0xC76C51A30654BE30ULL,
    0xD192E819D6EF5218ULL, 0xD69906245565A910ULL, 0xF40E35855771202AULL, 0x106AA07032BBD1B8ULL,
    0x19A4C116B8D2D0C8ULL, 0x1E376C085141AB53ULL, 0x2748774CDF8EEB99ULL, 0x34B0BCB5E19B48A8ULL,
    0x391C0CB3C5C95A63ULL, 0x4ED8AA4AE3418ACBULL, 0x5B9CCA4F7763E373ULL, 0x682E6FF3D6B2B8A3ULL,
    0x748F82EE5DEFB2FCULL, 0x78A5636F43172F60ULL, 0x84C87814A1F0AB72ULL, 0x8CC702081A6439ECULL,
    0x90BEFFFA23631E28ULL, 0xA4506CEBDE82BDE9ULL, 0xBEF9A3F7B2C67915ULL, 0xC67178F2E372532BULL,
    0xCA273ECEEA26619CULL, 0xD186B8C721C0C207ULL, 0xEADA7DD6CDE0EB1EULL, 0xF57D4F7FEE6ED178ULL,
    0x06F067AA72176FBAULL, 0x0A637DC5A2C898A6ULL, 0x113F9804BEF90DAEULL, 0x1B710B35131C471BULL,
    0x28DB77F523047D84ULL, 0x32CAAB7B40C72493ULL, 0x3C9EBE0A15C9BEBCULL, 0x431D67C49C100D4CULL,
    0x4CC5D4BECB3E42B6ULL, 0x597F299CFC657E2AULL, 0x5FCB6FAB3AD6FAECULL, 0x6C44198C4A475817ULL
};

void qsc_sha512_permute(uint64_t* output, const uint8_t* message)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL);

	uint64_t a;
	uint64_t b;
	uint64_t c;
	uint64_t d;
	uint64_t e;
	uint64_t f;
	uint64_t g;
	uint64_t h;
	uint64_t r;
	uint64_t w0;
	uint64_t w1;
	uint64_t w2;
	uint64_t w3;
	uint64_t w4;
	uint64_t w5;
	uint64_t w6;
	uint64_t w7;
	uint64_t w8;
	uint64_t w9;
	uint64_t w10;
	uint64_t w11;
	uint64_t w12;
	uint64_t w13;
	uint64_t w14;
	uint64_t w15;

	if (output != NULL && message != NULL)
	{
		a = output[0U];
		b = output[1U];
		c = output[2U];
		d = output[3U];
		e = output[4U];
		f = output[5U];
		g = output[6U];
		h = output[7U];

#if defined(QSC_SYSTEM_X86) && defined(__GNUC__) && !defined(__clang__)
		w0 = sha512_load_be64(message);
		w1 = sha512_load_be64(message + 8U);
		w2 = sha512_load_be64(message + 16U);
		w3 = sha512_load_be64(message + 24U);
		w4 = sha512_load_be64(message + 32U);
		w5 = sha512_load_be64(message + 40U);
		w6 = sha512_load_be64(message + 48U);
		w7 = sha512_load_be64(message + 56U);
		w8 = sha512_load_be64(message + 64U);
		w9 = sha512_load_be64(message + 72U);
		w10 = sha512_load_be64(message + 80U);
		w11 = sha512_load_be64(message + 88U);
		w12 = sha512_load_be64(message + 96U);
		w13 = sha512_load_be64(message + 104U);
		w14 = sha512_load_be64(message + 112U);
		w15 = sha512_load_be64(message + 120U);
#else
		w0 = qsc_intutils_be8to64(message);
		w1 = qsc_intutils_be8to64(message + 8U);
		w2 = qsc_intutils_be8to64(message + 16U);
		w3 = qsc_intutils_be8to64(message + 24U);
		w4 = qsc_intutils_be8to64(message + 32U);
		w5 = qsc_intutils_be8to64(message + 40U);
		w6 = qsc_intutils_be8to64(message + 48U);
		w7 = qsc_intutils_be8to64(message + 56U);
		w8 = qsc_intutils_be8to64(message + 64U);
		w9 = qsc_intutils_be8to64(message + 72U);
		w10 = qsc_intutils_be8to64(message + 80U);
		w11 = qsc_intutils_be8to64(message + 88U);
		w12 = qsc_intutils_be8to64(message + 96U);
		w13 = qsc_intutils_be8to64(message + 104U);
		w14 = qsc_intutils_be8to64(message + 112U);
		w15 = qsc_intutils_be8to64(message + 120U);
#endif

		r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + ((e & f) ^ (~e & g)) + w0 + sha512_round_constant_words[0U];
		d += r;
		h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
		r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + ((d & e) ^ (~d & f)) + w1 + sha512_round_constant_words[1U];
		c += r;
		g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
		r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + ((c & d) ^ (~c & e)) + w2 + sha512_round_constant_words[2U];
		b += r;
		f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
		r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + ((b & c) ^ (~b & d)) + w3 + sha512_round_constant_words[3U];
		a += r;
		e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
		r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + ((a & b) ^ (~a & c)) + w4 + sha512_round_constant_words[4U];
		h += r;
		d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
		r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + ((h & a) ^ (~h & b)) + w5 + sha512_round_constant_words[5U];
		g += r;
		c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
		r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + ((g & h) ^ (~g & a)) + w6 + sha512_round_constant_words[6U];
		f += r;
		b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
		r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + ((f & g) ^ (~f & h)) + w7 + sha512_round_constant_words[7U];
		e += r;
		a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));
		r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + ((e & f) ^ (~e & g)) + w8 + sha512_round_constant_words[8U];
		d += r;
		h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
		r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + ((d & e) ^ (~d & f)) + w9 + sha512_round_constant_words[9U];
		c += r;
		g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
		r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + ((c & d) ^ (~c & e)) + w10 + sha512_round_constant_words[10U];
		b += r;
		f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
		r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + ((b & c) ^ (~b & d)) + w11 + sha512_round_constant_words[11U];
		a += r;
		e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
		r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + ((a & b) ^ (~a & c)) + w12 + sha512_round_constant_words[12U];
		h += r;
		d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
		r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + ((h & a) ^ (~h & b)) + w13 + sha512_round_constant_words[13U];
		g += r;
		c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
		r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + ((g & h) ^ (~g & a)) + w14 + sha512_round_constant_words[14U];
		f += r;
		b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
		r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + ((f & g) ^ (~f & h)) + w15 + sha512_round_constant_words[15U];
		e += r;
		a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

		w0 += (((w14 << 45) | (w14 >> 19)) ^ ((w14 << 3) | (w14 >> 61)) ^ (w14 >> 6)) + w9 + (((w1 << 63) | (w1 >> 1)) ^ ((w1 << 56) | (w1 >> 8)) ^ (w1 >> 7));
		r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + ((e & f) ^ (~e & g)) + w0 + sha512_round_constant_words[16U];
		d += r;
		h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
		w1 += (((w15 << 45) | (w15 >> 19)) ^ ((w15 << 3) | (w15 >> 61)) ^ (w15 >> 6)) + w10 + (((w2 << 63) | (w2 >> 1)) ^ ((w2 << 56) | (w2 >> 8)) ^ (w2 >> 7));
		r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + ((d & e) ^ (~d & f)) + w1 + sha512_round_constant_words[17U];
		c += r;
		g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
		w2 += (((w0 << 45) | (w0 >> 19)) ^ ((w0 << 3) | (w0 >> 61)) ^ (w0 >> 6)) + w11 + (((w3 << 63) | (w3 >> 1)) ^ ((w3 << 56) | (w3 >> 8)) ^ (w3 >> 7));
		r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + ((c & d) ^ (~c & e)) + w2 + sha512_round_constant_words[18U];
		b += r;
		f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
		w3 += (((w1 << 45) | (w1 >> 19)) ^ ((w1 << 3) | (w1 >> 61)) ^ (w1 >> 6)) + w12 + (((w4 << 63) | (w4 >> 1)) ^ ((w4 << 56) | (w4 >> 8)) ^ (w4 >> 7));
		r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + ((b & c) ^ (~b & d)) + w3 + sha512_round_constant_words[19U];
		a += r;
		e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
		w4 += (((w2 << 45) | (w2 >> 19)) ^ ((w2 << 3) | (w2 >> 61)) ^ (w2 >> 6)) + w13 + (((w5 << 63) | (w5 >> 1)) ^ ((w5 << 56) | (w5 >> 8)) ^ (w5 >> 7));
		r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + ((a & b) ^ (~a & c)) + w4 + sha512_round_constant_words[20U];
		h += r;
		d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
		w5 += (((w3 << 45) | (w3 >> 19)) ^ ((w3 << 3) | (w3 >> 61)) ^ (w3 >> 6)) + w14 + (((w6 << 63) | (w6 >> 1)) ^ ((w6 << 56) | (w6 >> 8)) ^ (w6 >> 7));
		r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + ((h & a) ^ (~h & b)) + w5 + sha512_round_constant_words[21U];
		g += r;
		c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
		w6 += (((w4 << 45) | (w4 >> 19)) ^ ((w4 << 3) | (w4 >> 61)) ^ (w4 >> 6)) + w15 + (((w7 << 63) | (w7 >> 1)) ^ ((w7 << 56) | (w7 >> 8)) ^ (w7 >> 7));
		r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + ((g & h) ^ (~g & a)) + w6 + sha512_round_constant_words[22U];
		f += r;
		b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
		w7 += (((w5 << 45) | (w5 >> 19)) ^ ((w5 << 3) | (w5 >> 61)) ^ (w5 >> 6)) + w0 + (((w8 << 63) | (w8 >> 1)) ^ ((w8 << 56) | (w8 >> 8)) ^ (w8 >> 7));
		r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + ((f & g) ^ (~f & h)) + w7 + sha512_round_constant_words[23U];
		e += r;
		a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));
		w8 += (((w6 << 45) | (w6 >> 19)) ^ ((w6 << 3) | (w6 >> 61)) ^ (w6 >> 6)) + w1 + (((w9 << 63) | (w9 >> 1)) ^ ((w9 << 56) | (w9 >> 8)) ^ (w9 >> 7));
		r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + ((e & f) ^ (~e & g)) + w8 + sha512_round_constant_words[24U];
		d += r;
		h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
		w9 += (((w7 << 45) | (w7 >> 19)) ^ ((w7 << 3) | (w7 >> 61)) ^ (w7 >> 6)) + w2 + (((w10 << 63) | (w10 >> 1)) ^ ((w10 << 56) | (w10 >> 8)) ^ (w10 >> 7));
		r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + ((d & e) ^ (~d & f)) + w9 + sha512_round_constant_words[25U];
		c += r;
		g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
		w10 += (((w8 << 45) | (w8 >> 19)) ^ ((w8 << 3) | (w8 >> 61)) ^ (w8 >> 6)) + w3 + (((w11 << 63) | (w11 >> 1)) ^ ((w11 << 56) | (w11 >> 8)) ^ (w11 >> 7));
		r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + ((c & d) ^ (~c & e)) + w10 + sha512_round_constant_words[26U];
		b += r;
		f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
		w11 += (((w9 << 45) | (w9 >> 19)) ^ ((w9 << 3) | (w9 >> 61)) ^ (w9 >> 6)) + w4 + (((w12 << 63) | (w12 >> 1)) ^ ((w12 << 56) | (w12 >> 8)) ^ (w12 >> 7));
		r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + ((b & c) ^ (~b & d)) + w11 + sha512_round_constant_words[27U];
		a += r;
		e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
		w12 += (((w10 << 45) | (w10 >> 19)) ^ ((w10 << 3) | (w10 >> 61)) ^ (w10 >> 6)) + w5 + (((w13 << 63) | (w13 >> 1)) ^ ((w13 << 56) | (w13 >> 8)) ^ (w13 >> 7));
		r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + ((a & b) ^ (~a & c)) + w12 + sha512_round_constant_words[28U];
		h += r;
		d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
		w13 += (((w11 << 45) | (w11 >> 19)) ^ ((w11 << 3) | (w11 >> 61)) ^ (w11 >> 6)) + w6 + (((w14 << 63) | (w14 >> 1)) ^ ((w14 << 56) | (w14 >> 8)) ^ (w14 >> 7));
		r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + ((h & a) ^ (~h & b)) + w13 + sha512_round_constant_words[29U];
		g += r;
		c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
		w14 += (((w12 << 45) | (w12 >> 19)) ^ ((w12 << 3) | (w12 >> 61)) ^ (w12 >> 6)) + w7 + (((w15 << 63) | (w15 >> 1)) ^ ((w15 << 56) | (w15 >> 8)) ^ (w15 >> 7));
		r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + ((g & h) ^ (~g & a)) + w14 + sha512_round_constant_words[30U];
		f += r;
		b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
		w15 += (((w13 << 45) | (w13 >> 19)) ^ ((w13 << 3) | (w13 >> 61)) ^ (w13 >> 6)) + w8 + (((w0 << 63) | (w0 >> 1)) ^ ((w0 << 56) | (w0 >> 8)) ^ (w0 >> 7));
		r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + ((f & g) ^ (~f & h)) + w15 + sha512_round_constant_words[31U];
		e += r;
		a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

		w0 += (((w14 << 45) | (w14 >> 19)) ^ ((w14 << 3) | (w14 >> 61)) ^ (w14 >> 6)) + w9 + (((w1 << 63) | (w1 >> 1)) ^ ((w1 << 56) | (w1 >> 8)) ^ (w1 >> 7));
		r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + ((e & f) ^ (~e & g)) + w0 + sha512_round_constant_words[32U];
		d += r;
		h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
		w1 += (((w15 << 45) | (w15 >> 19)) ^ ((w15 << 3) | (w15 >> 61)) ^ (w15 >> 6)) + w10 + (((w2 << 63) | (w2 >> 1)) ^ ((w2 << 56) | (w2 >> 8)) ^ (w2 >> 7));
		r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + ((d & e) ^ (~d & f)) + w1 + sha512_round_constant_words[33U];
		c += r;
		g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
		w2 += (((w0 << 45) | (w0 >> 19)) ^ ((w0 << 3) | (w0 >> 61)) ^ (w0 >> 6)) + w11 + (((w3 << 63) | (w3 >> 1)) ^ ((w3 << 56) | (w3 >> 8)) ^ (w3 >> 7));
		r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + ((c & d) ^ (~c & e)) + w2 + sha512_round_constant_words[34U];
		b += r;
		f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
		w3 += (((w1 << 45) | (w1 >> 19)) ^ ((w1 << 3) | (w1 >> 61)) ^ (w1 >> 6)) + w12 + (((w4 << 63) | (w4 >> 1)) ^ ((w4 << 56) | (w4 >> 8)) ^ (w4 >> 7));
		r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + ((b & c) ^ (~b & d)) + w3 + sha512_round_constant_words[35U];
		a += r;
		e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
		w4 += (((w2 << 45) | (w2 >> 19)) ^ ((w2 << 3) | (w2 >> 61)) ^ (w2 >> 6)) + w13 + (((w5 << 63) | (w5 >> 1)) ^ ((w5 << 56) | (w5 >> 8)) ^ (w5 >> 7));
		r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + ((a & b) ^ (~a & c)) + w4 + sha512_round_constant_words[36U];
		h += r;
		d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
		w5 += (((w3 << 45) | (w3 >> 19)) ^ ((w3 << 3) | (w3 >> 61)) ^ (w3 >> 6)) + w14 + (((w6 << 63) | (w6 >> 1)) ^ ((w6 << 56) | (w6 >> 8)) ^ (w6 >> 7));
		r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + ((h & a) ^ (~h & b)) + w5 + sha512_round_constant_words[37U];
		g += r;
		c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
		w6 += (((w4 << 45) | (w4 >> 19)) ^ ((w4 << 3) | (w4 >> 61)) ^ (w4 >> 6)) + w15 + (((w7 << 63) | (w7 >> 1)) ^ ((w7 << 56) | (w7 >> 8)) ^ (w7 >> 7));
		r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + ((g & h) ^ (~g & a)) + w6 + sha512_round_constant_words[38U];
		f += r;
		b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
		w7 += (((w5 << 45) | (w5 >> 19)) ^ ((w5 << 3) | (w5 >> 61)) ^ (w5 >> 6)) + w0 + (((w8 << 63) | (w8 >> 1)) ^ ((w8 << 56) | (w8 >> 8)) ^ (w8 >> 7));
		r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + ((f & g) ^ (~f & h)) + w7 + sha512_round_constant_words[39U];
		e += r;
		a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));
		w8 += (((w6 << 45) | (w6 >> 19)) ^ ((w6 << 3) | (w6 >> 61)) ^ (w6 >> 6)) + w1 + (((w9 << 63) | (w9 >> 1)) ^ ((w9 << 56) | (w9 >> 8)) ^ (w9 >> 7));
		r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + ((e & f) ^ (~e & g)) + w8 + sha512_round_constant_words[40U];
		d += r;
		h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
		w9 += (((w7 << 45) | (w7 >> 19)) ^ ((w7 << 3) | (w7 >> 61)) ^ (w7 >> 6)) + w2 + (((w10 << 63) | (w10 >> 1)) ^ ((w10 << 56) | (w10 >> 8)) ^ (w10 >> 7));
		r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + ((d & e) ^ (~d & f)) + w9 + sha512_round_constant_words[41U];
		c += r;
		g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
		w10 += (((w8 << 45) | (w8 >> 19)) ^ ((w8 << 3) | (w8 >> 61)) ^ (w8 >> 6)) + w3 + (((w11 << 63) | (w11 >> 1)) ^ ((w11 << 56) | (w11 >> 8)) ^ (w11 >> 7));
		r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + ((c & d) ^ (~c & e)) + w10 + sha512_round_constant_words[42U];
		b += r;
		f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
		w11 += (((w9 << 45) | (w9 >> 19)) ^ ((w9 << 3) | (w9 >> 61)) ^ (w9 >> 6)) + w4 + (((w12 << 63) | (w12 >> 1)) ^ ((w12 << 56) | (w12 >> 8)) ^ (w12 >> 7));
		r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + ((b & c) ^ (~b & d)) + w11 + sha512_round_constant_words[43U];
		a += r;
		e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
		w12 += (((w10 << 45) | (w10 >> 19)) ^ ((w10 << 3) | (w10 >> 61)) ^ (w10 >> 6)) + w5 + (((w13 << 63) | (w13 >> 1)) ^ ((w13 << 56) | (w13 >> 8)) ^ (w13 >> 7));
		r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + ((a & b) ^ (~a & c)) + w12 + sha512_round_constant_words[44U];
		h += r;
		d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
		w13 += (((w11 << 45) | (w11 >> 19)) ^ ((w11 << 3) | (w11 >> 61)) ^ (w11 >> 6)) + w6 + (((w14 << 63) | (w14 >> 1)) ^ ((w14 << 56) | (w14 >> 8)) ^ (w14 >> 7));
		r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + ((h & a) ^ (~h & b)) + w13 + sha512_round_constant_words[45U];
		g += r;
		c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
		w14 += (((w12 << 45) | (w12 >> 19)) ^ ((w12 << 3) | (w12 >> 61)) ^ (w12 >> 6)) + w7 + (((w15 << 63) | (w15 >> 1)) ^ ((w15 << 56) | (w15 >> 8)) ^ (w15 >> 7));
		r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + ((g & h) ^ (~g & a)) + w14 + sha512_round_constant_words[46U];
		f += r;
		b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
		w15 += (((w13 << 45) | (w13 >> 19)) ^ ((w13 << 3) | (w13 >> 61)) ^ (w13 >> 6)) + w8 + (((w0 << 63) | (w0 >> 1)) ^ ((w0 << 56) | (w0 >> 8)) ^ (w0 >> 7));
		r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + ((f & g) ^ (~f & h)) + w15 + sha512_round_constant_words[47U];
		e += r;
		a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

		w0 += (((w14 << 45) | (w14 >> 19)) ^ ((w14 << 3) | (w14 >> 61)) ^ (w14 >> 6)) + w9 + (((w1 << 63) | (w1 >> 1)) ^ ((w1 << 56) | (w1 >> 8)) ^ (w1 >> 7));
		r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + ((e & f) ^ (~e & g)) + w0 + sha512_round_constant_words[48U];
		d += r;
		h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
		w1 += (((w15 << 45) | (w15 >> 19)) ^ ((w15 << 3) | (w15 >> 61)) ^ (w15 >> 6)) + w10 + (((w2 << 63) | (w2 >> 1)) ^ ((w2 << 56) | (w2 >> 8)) ^ (w2 >> 7));
		r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + ((d & e) ^ (~d & f)) + w1 + sha512_round_constant_words[49U];
		c += r;
		g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
		w2 += (((w0 << 45) | (w0 >> 19)) ^ ((w0 << 3) | (w0 >> 61)) ^ (w0 >> 6)) + w11 + (((w3 << 63) | (w3 >> 1)) ^ ((w3 << 56) | (w3 >> 8)) ^ (w3 >> 7));
		r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + ((c & d) ^ (~c & e)) + w2 + sha512_round_constant_words[50U];
		b += r;
		f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
		w3 += (((w1 << 45) | (w1 >> 19)) ^ ((w1 << 3) | (w1 >> 61)) ^ (w1 >> 6)) + w12 + (((w4 << 63) | (w4 >> 1)) ^ ((w4 << 56) | (w4 >> 8)) ^ (w4 >> 7));
		r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + ((b & c) ^ (~b & d)) + w3 + sha512_round_constant_words[51U];
		a += r;
		e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
		w4 += (((w2 << 45) | (w2 >> 19)) ^ ((w2 << 3) | (w2 >> 61)) ^ (w2 >> 6)) + w13 + (((w5 << 63) | (w5 >> 1)) ^ ((w5 << 56) | (w5 >> 8)) ^ (w5 >> 7));
		r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + ((a & b) ^ (~a & c)) + w4 + sha512_round_constant_words[52U];
		h += r;
		d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
		w5 += (((w3 << 45) | (w3 >> 19)) ^ ((w3 << 3) | (w3 >> 61)) ^ (w3 >> 6)) + w14 + (((w6 << 63) | (w6 >> 1)) ^ ((w6 << 56) | (w6 >> 8)) ^ (w6 >> 7));
		r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + ((h & a) ^ (~h & b)) + w5 + sha512_round_constant_words[53U];
		g += r;
		c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
		w6 += (((w4 << 45) | (w4 >> 19)) ^ ((w4 << 3) | (w4 >> 61)) ^ (w4 >> 6)) + w15 + (((w7 << 63) | (w7 >> 1)) ^ ((w7 << 56) | (w7 >> 8)) ^ (w7 >> 7));
		r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + ((g & h) ^ (~g & a)) + w6 + sha512_round_constant_words[54U];
		f += r;
		b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
		w7 += (((w5 << 45) | (w5 >> 19)) ^ ((w5 << 3) | (w5 >> 61)) ^ (w5 >> 6)) + w0 + (((w8 << 63) | (w8 >> 1)) ^ ((w8 << 56) | (w8 >> 8)) ^ (w8 >> 7));
		r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + ((f & g) ^ (~f & h)) + w7 + sha512_round_constant_words[55U];
		e += r;
		a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));
		w8 += (((w6 << 45) | (w6 >> 19)) ^ ((w6 << 3) | (w6 >> 61)) ^ (w6 >> 6)) + w1 + (((w9 << 63) | (w9 >> 1)) ^ ((w9 << 56) | (w9 >> 8)) ^ (w9 >> 7));
		r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + ((e & f) ^ (~e & g)) + w8 + sha512_round_constant_words[56U];
		d += r;
		h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
		w9 += (((w7 << 45) | (w7 >> 19)) ^ ((w7 << 3) | (w7 >> 61)) ^ (w7 >> 6)) + w2 + (((w10 << 63) | (w10 >> 1)) ^ ((w10 << 56) | (w10 >> 8)) ^ (w10 >> 7));
		r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + ((d & e) ^ (~d & f)) + w9 + sha512_round_constant_words[57U];
		c += r;
		g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
		w10 += (((w8 << 45) | (w8 >> 19)) ^ ((w8 << 3) | (w8 >> 61)) ^ (w8 >> 6)) + w3 + (((w11 << 63) | (w11 >> 1)) ^ ((w11 << 56) | (w11 >> 8)) ^ (w11 >> 7));
		r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + ((c & d) ^ (~c & e)) + w10 + sha512_round_constant_words[58U];
		b += r;
		f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
		w11 += (((w9 << 45) | (w9 >> 19)) ^ ((w9 << 3) | (w9 >> 61)) ^ (w9 >> 6)) + w4 + (((w12 << 63) | (w12 >> 1)) ^ ((w12 << 56) | (w12 >> 8)) ^ (w12 >> 7));
		r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + ((b & c) ^ (~b & d)) + w11 + sha512_round_constant_words[59U];
		a += r;
		e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
		w12 += (((w10 << 45) | (w10 >> 19)) ^ ((w10 << 3) | (w10 >> 61)) ^ (w10 >> 6)) + w5 + (((w13 << 63) | (w13 >> 1)) ^ ((w13 << 56) | (w13 >> 8)) ^ (w13 >> 7));
		r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + ((a & b) ^ (~a & c)) + w12 + sha512_round_constant_words[60U];
		h += r;
		d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
		w13 += (((w11 << 45) | (w11 >> 19)) ^ ((w11 << 3) | (w11 >> 61)) ^ (w11 >> 6)) + w6 + (((w14 << 63) | (w14 >> 1)) ^ ((w14 << 56) | (w14 >> 8)) ^ (w14 >> 7));
		r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + ((h & a) ^ (~h & b)) + w13 + sha512_round_constant_words[61U];
		g += r;
		c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
		w14 += (((w12 << 45) | (w12 >> 19)) ^ ((w12 << 3) | (w12 >> 61)) ^ (w12 >> 6)) + w7 + (((w15 << 63) | (w15 >> 1)) ^ ((w15 << 56) | (w15 >> 8)) ^ (w15 >> 7));
		r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + ((g & h) ^ (~g & a)) + w14 + sha512_round_constant_words[62U];
		f += r;
		b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
		w15 += (((w13 << 45) | (w13 >> 19)) ^ ((w13 << 3) | (w13 >> 61)) ^ (w13 >> 6)) + w8 + (((w0 << 63) | (w0 >> 1)) ^ ((w0 << 56) | (w0 >> 8)) ^ (w0 >> 7));
		r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + ((f & g) ^ (~f & h)) + w15 + sha512_round_constant_words[63U];
		e += r;
		a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

		w0 += (((w14 << 45) | (w14 >> 19)) ^ ((w14 << 3) | (w14 >> 61)) ^ (w14 >> 6)) + w9 + (((w1 << 63) | (w1 >> 1)) ^ ((w1 << 56) | (w1 >> 8)) ^ (w1 >> 7));
		r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + ((e & f) ^ (~e & g)) + w0 + sha512_round_constant_words[64U];
		d += r;
		h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
		w1 += (((w15 << 45) | (w15 >> 19)) ^ ((w15 << 3) | (w15 >> 61)) ^ (w15 >> 6)) + w10 + (((w2 << 63) | (w2 >> 1)) ^ ((w2 << 56) | (w2 >> 8)) ^ (w2 >> 7));
		r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + ((d & e) ^ (~d & f)) + w1 + sha512_round_constant_words[65U];
		c += r;
		g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
		w2 += (((w0 << 45) | (w0 >> 19)) ^ ((w0 << 3) | (w0 >> 61)) ^ (w0 >> 6)) + w11 + (((w3 << 63) | (w3 >> 1)) ^ ((w3 << 56) | (w3 >> 8)) ^ (w3 >> 7));
		r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + ((c & d) ^ (~c & e)) + w2 + sha512_round_constant_words[66U];
		b += r;
		f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
		w3 += (((w1 << 45) | (w1 >> 19)) ^ ((w1 << 3) | (w1 >> 61)) ^ (w1 >> 6)) + w12 + (((w4 << 63) | (w4 >> 1)) ^ ((w4 << 56) | (w4 >> 8)) ^ (w4 >> 7));
		r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + ((b & c) ^ (~b & d)) + w3 + sha512_round_constant_words[67U];
		a += r;
		e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
		w4 += (((w2 << 45) | (w2 >> 19)) ^ ((w2 << 3) | (w2 >> 61)) ^ (w2 >> 6)) + w13 + (((w5 << 63) | (w5 >> 1)) ^ ((w5 << 56) | (w5 >> 8)) ^ (w5 >> 7));
		r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + ((a & b) ^ (~a & c)) + w4 + sha512_round_constant_words[68U];
		h += r;
		d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
		w5 += (((w3 << 45) | (w3 >> 19)) ^ ((w3 << 3) | (w3 >> 61)) ^ (w3 >> 6)) + w14 + (((w6 << 63) | (w6 >> 1)) ^ ((w6 << 56) | (w6 >> 8)) ^ (w6 >> 7));
		r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + ((h & a) ^ (~h & b)) + w5 + sha512_round_constant_words[69U];
		g += r;
		c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
		w6 += (((w4 << 45) | (w4 >> 19)) ^ ((w4 << 3) | (w4 >> 61)) ^ (w4 >> 6)) + w15 + (((w7 << 63) | (w7 >> 1)) ^ ((w7 << 56) | (w7 >> 8)) ^ (w7 >> 7));
		r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + ((g & h) ^ (~g & a)) + w6 + sha512_round_constant_words[70U];
		f += r;
		b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
		w7 += (((w5 << 45) | (w5 >> 19)) ^ ((w5 << 3) | (w5 >> 61)) ^ (w5 >> 6)) + w0 + (((w8 << 63) | (w8 >> 1)) ^ ((w8 << 56) | (w8 >> 8)) ^ (w8 >> 7));
		r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + ((f & g) ^ (~f & h)) + w7 + sha512_round_constant_words[71U];
		e += r;
		a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));
		w8 += (((w6 << 45) | (w6 >> 19)) ^ ((w6 << 3) | (w6 >> 61)) ^ (w6 >> 6)) + w1 + (((w9 << 63) | (w9 >> 1)) ^ ((w9 << 56) | (w9 >> 8)) ^ (w9 >> 7));
		r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + ((e & f) ^ (~e & g)) + w8 + sha512_round_constant_words[72U];
		d += r;
		h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
		w9 += (((w7 << 45) | (w7 >> 19)) ^ ((w7 << 3) | (w7 >> 61)) ^ (w7 >> 6)) + w2 + (((w10 << 63) | (w10 >> 1)) ^ ((w10 << 56) | (w10 >> 8)) ^ (w10 >> 7));
		r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + ((d & e) ^ (~d & f)) + w9 + sha512_round_constant_words[73U];
		c += r;
		g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
		w10 += (((w8 << 45) | (w8 >> 19)) ^ ((w8 << 3) | (w8 >> 61)) ^ (w8 >> 6)) + w3 + (((w11 << 63) | (w11 >> 1)) ^ ((w11 << 56) | (w11 >> 8)) ^ (w11 >> 7));
		r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + ((c & d) ^ (~c & e)) + w10 + sha512_round_constant_words[74U];
		b += r;
		f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
		w11 += (((w9 << 45) | (w9 >> 19)) ^ ((w9 << 3) | (w9 >> 61)) ^ (w9 >> 6)) + w4 + (((w12 << 63) | (w12 >> 1)) ^ ((w12 << 56) | (w12 >> 8)) ^ (w12 >> 7));
		r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + ((b & c) ^ (~b & d)) + w11 + sha512_round_constant_words[75U];
		a += r;
		e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
		w12 += (((w10 << 45) | (w10 >> 19)) ^ ((w10 << 3) | (w10 >> 61)) ^ (w10 >> 6)) + w5 + (((w13 << 63) | (w13 >> 1)) ^ ((w13 << 56) | (w13 >> 8)) ^ (w13 >> 7));
		r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + ((a & b) ^ (~a & c)) + w12 + sha512_round_constant_words[76U];
		h += r;
		d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
		w13 += (((w11 << 45) | (w11 >> 19)) ^ ((w11 << 3) | (w11 >> 61)) ^ (w11 >> 6)) + w6 + (((w14 << 63) | (w14 >> 1)) ^ ((w14 << 56) | (w14 >> 8)) ^ (w14 >> 7));
		r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + ((h & a) ^ (~h & b)) + w13 + sha512_round_constant_words[77U];
		g += r;
		c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
		w14 += (((w12 << 45) | (w12 >> 19)) ^ ((w12 << 3) | (w12 >> 61)) ^ (w12 >> 6)) + w7 + (((w15 << 63) | (w15 >> 1)) ^ ((w15 << 56) | (w15 >> 8)) ^ (w15 >> 7));
		r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + ((g & h) ^ (~g & a)) + w14 + sha512_round_constant_words[78U];
		f += r;
		b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
		w15 += (((w13 << 45) | (w13 >> 19)) ^ ((w13 << 3) | (w13 >> 61)) ^ (w13 >> 6)) + w8 + (((w0 << 63) | (w0 >> 1)) ^ ((w0 << 56) | (w0 >> 8)) ^ (w0 >> 7));
		r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + ((f & g) ^ (~f & h)) + w15 + sha512_round_constant_words[79U];
		e += r;
		a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

		output[0U] += a;
		output[1U] += b;
		output[2U] += c;
		output[3U] += d;
		output[4U] += e;
		output[5U] += f;
		output[6U] += g;
		output[7U] += h;
	}
}

#endif

/* Interleaved two-word SHA-512 message schedule and compression rounds.
 * Eight XMM pairs hold the rolling 16-word message window. The next pair is
 * expanded immediately before it is used by the serial SHA-512 round engine.
 * Public state layout and function interfaces are unchanged.
 */
#if defined(QSC_SYSTEM_X86) && defined(__AVX2__) && defined(__BMI2__)

/*! \def SHA512_INTERLEAVED_CHOICE(x, y, z)
 * \brief Fixed-work SHA-512 Choice for the private interleaved compression loop.
 * \note The GCC AVX-512 expression preserves scalar SHA-512 logic while
 *       avoiding inefficient XMM instruction selection. Other targets retain
 *       the accepted Boolean expression and machine-code generation.
 */
#if defined(QSC_SYSTEM_X86) && defined(__GNUC__) && !defined(__clang__) && defined(__AVX512F__)
#define SHA512_INTERLEAVED_CHOICE(x, y, z) ((z) ^ ((x) & ((y) ^ (z))))
#else
#define SHA512_INTERLEAVED_CHOICE(x, y, z) (((x) & (y)) ^ (~(x) & (z)))
#endif

static void sha512_compress_interleaved(uint64_t* output, const uint8_t* message)
{
    uint64_t a;
    uint64_t b;
    uint64_t c;
    uint64_t d;
    uint64_t e;
    uint64_t f;
    uint64_t g;
    uint64_t h;
    uint64_t r;
    __m128i v0;
    __m128i v1;
    __m128i v2;
    __m128i v3;
    __m128i v4;
    __m128i v5;
    __m128i v6;
    __m128i v7;
    __m128i z0;
    __m128i z1;
    __m128i bswap;

    bswap = _mm_setr_epi8(7, 6, 5, 4, 3, 2, 1, 0, 15, 14, 13, 12, 11, 10, 9, 8);
    v0 = _mm_shuffle_epi8(_mm_loadu_si128((const __m128i*)(message + 0U)), bswap);
    v1 = _mm_shuffle_epi8(_mm_loadu_si128((const __m128i*)(message + 16U)), bswap);
    v2 = _mm_shuffle_epi8(_mm_loadu_si128((const __m128i*)(message + 32U)), bswap);
    v3 = _mm_shuffle_epi8(_mm_loadu_si128((const __m128i*)(message + 48U)), bswap);
    v4 = _mm_shuffle_epi8(_mm_loadu_si128((const __m128i*)(message + 64U)), bswap);
    v5 = _mm_shuffle_epi8(_mm_loadu_si128((const __m128i*)(message + 80U)), bswap);
    v6 = _mm_shuffle_epi8(_mm_loadu_si128((const __m128i*)(message + 96U)), bswap);
    v7 = _mm_shuffle_epi8(_mm_loadu_si128((const __m128i*)(message + 112U)), bswap);

    a = output[0U];
    b = output[1U];
    c = output[2U];
    d = output[3U];
    e = output[4U];
    f = output[5U];
    g = output[6U];
    h = output[7U];

	r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + SHA512_INTERLEAVED_CHOICE(e, f, g) + (uint64_t)_mm_cvtsi128_si64(v0) + sha512_round_constant_words[0U];
	d += r;
	h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
	r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + SHA512_INTERLEAVED_CHOICE(d, e, f) + (uint64_t)_mm_extract_epi64(v0, 1) + sha512_round_constant_words[1U];
	c += r;
	g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
	r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + SHA512_INTERLEAVED_CHOICE(c, d, e) + (uint64_t)_mm_cvtsi128_si64(v1) + sha512_round_constant_words[2U];
	b += r;
	f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
	r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + SHA512_INTERLEAVED_CHOICE(b, c, d) + (uint64_t)_mm_extract_epi64(v1, 1) + sha512_round_constant_words[3U];
	a += r;
	e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
	r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + SHA512_INTERLEAVED_CHOICE(a, b, c) + (uint64_t)_mm_cvtsi128_si64(v2) + sha512_round_constant_words[4U];
	h += r;
	d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
	r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + SHA512_INTERLEAVED_CHOICE(h, a, b) + (uint64_t)_mm_extract_epi64(v2, 1) + sha512_round_constant_words[5U];
	g += r;
	c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
	r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + SHA512_INTERLEAVED_CHOICE(g, h, a) + (uint64_t)_mm_cvtsi128_si64(v3) + sha512_round_constant_words[6U];
	f += r;
	b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
	r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + SHA512_INTERLEAVED_CHOICE(f, g, h) + (uint64_t)_mm_extract_epi64(v3, 1) + sha512_round_constant_words[7U];
	e += r;
	a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));
	r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + SHA512_INTERLEAVED_CHOICE(e, f, g) + (uint64_t)_mm_cvtsi128_si64(v4) + sha512_round_constant_words[8U];
	d += r;
	h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
	r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + SHA512_INTERLEAVED_CHOICE(d, e, f) + (uint64_t)_mm_extract_epi64(v4, 1) + sha512_round_constant_words[9U];
	c += r;
	g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
	r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + SHA512_INTERLEAVED_CHOICE(c, d, e) + (uint64_t)_mm_cvtsi128_si64(v5) + sha512_round_constant_words[10U];
	b += r;
	f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
	r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + SHA512_INTERLEAVED_CHOICE(b, c, d) + (uint64_t)_mm_extract_epi64(v5, 1) + sha512_round_constant_words[11U];
	a += r;
	e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
	r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + SHA512_INTERLEAVED_CHOICE(a, b, c) + (uint64_t)_mm_cvtsi128_si64(v6) + sha512_round_constant_words[12U];
	h += r;
	d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
	r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + SHA512_INTERLEAVED_CHOICE(h, a, b) + (uint64_t)_mm_extract_epi64(v6, 1) + sha512_round_constant_words[13U];
	g += r;
	c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
	r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + SHA512_INTERLEAVED_CHOICE(g, h, a) + (uint64_t)_mm_cvtsi128_si64(v7) + sha512_round_constant_words[14U];
	f += r;
	b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
	r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + SHA512_INTERLEAVED_CHOICE(f, g, h) + (uint64_t)_mm_extract_epi64(v7, 1) + sha512_round_constant_words[15U];
	e += r;
	a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));
    
	z0 = _mm_alignr_epi8(v1, v0, 8);
    z1 = _mm_alignr_epi8(v5, v4, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v7, 19), _mm_slli_epi64(v7, 45)), _mm_or_si128(_mm_srli_epi64(v7, 61), _mm_slli_epi64(v7, 3))), _mm_srli_epi64(v7, 6));
    v0 = _mm_add_epi64(_mm_add_epi64(v0, z1), z0);

	r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + SHA512_INTERLEAVED_CHOICE(e, f, g) + (uint64_t)_mm_cvtsi128_si64(v0) + sha512_round_constant_words[16U];
	d += r;
	h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
	r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + SHA512_INTERLEAVED_CHOICE(d, e, f) + (uint64_t)_mm_extract_epi64(v0, 1) + sha512_round_constant_words[17U];
	c += r;
	g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
    z0 = _mm_alignr_epi8(v2, v1, 8);
    z1 = _mm_alignr_epi8(v6, v5, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v0, 19), _mm_slli_epi64(v0, 45)), _mm_or_si128(_mm_srli_epi64(v0, 61), _mm_slli_epi64(v0, 3))), _mm_srli_epi64(v0, 6));
    v1 = _mm_add_epi64(_mm_add_epi64(v1, z1), z0);
	
	r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + SHA512_INTERLEAVED_CHOICE(c, d, e) + (uint64_t)_mm_cvtsi128_si64(v1) + sha512_round_constant_words[18U];
	b += r;
	f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
	r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + SHA512_INTERLEAVED_CHOICE(b, c, d) + (uint64_t)_mm_extract_epi64(v1, 1) + sha512_round_constant_words[19U];
	a += r;
	e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));
    
	z0 = _mm_alignr_epi8(v3, v2, 8);
    z1 = _mm_alignr_epi8(v7, v6, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v1, 19), _mm_slli_epi64(v1, 45)), _mm_or_si128(_mm_srli_epi64(v1, 61), _mm_slli_epi64(v1, 3))), _mm_srli_epi64(v1, 6));
    v2 = _mm_add_epi64(_mm_add_epi64(v2, z1), z0);
		
	r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + SHA512_INTERLEAVED_CHOICE(a, b, c) + (uint64_t)_mm_cvtsi128_si64(v2) + sha512_round_constant_words[20U];
	h += r;
	d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
	r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + SHA512_INTERLEAVED_CHOICE(h, a, b) + (uint64_t)_mm_extract_epi64(v2, 1) + sha512_round_constant_words[21U];
	g += r;
	c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
    
	z0 = _mm_alignr_epi8(v4, v3, 8);
    z1 = _mm_alignr_epi8(v0, v7, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v2, 19), _mm_slli_epi64(v2, 45)), _mm_or_si128(_mm_srli_epi64(v2, 61), _mm_slli_epi64(v2, 3))), _mm_srli_epi64(v2, 6));
    v3 = _mm_add_epi64(_mm_add_epi64(v3, z1), z0);
		
	r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + SHA512_INTERLEAVED_CHOICE(g, h, a) + (uint64_t)_mm_cvtsi128_si64(v3) + sha512_round_constant_words[22U];
	f += r;
	b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
	r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + SHA512_INTERLEAVED_CHOICE(f, g, h) + (uint64_t)_mm_extract_epi64(v3, 1) + sha512_round_constant_words[23U];
	e += r;
	a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

    z0 = _mm_alignr_epi8(v5, v4, 8);
    z1 = _mm_alignr_epi8(v1, v0, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v3, 19), _mm_slli_epi64(v3, 45)), _mm_or_si128(_mm_srli_epi64(v3, 61), _mm_slli_epi64(v3, 3))), _mm_srli_epi64(v3, 6));
    v4 = _mm_add_epi64(_mm_add_epi64(v4, z1), z0);

	r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + SHA512_INTERLEAVED_CHOICE(e, f, g) + (uint64_t)_mm_cvtsi128_si64(v4) + sha512_round_constant_words[24U];
	d += r;
	h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
	r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + SHA512_INTERLEAVED_CHOICE(d, e, f) + (uint64_t)_mm_extract_epi64(v4, 1) + sha512_round_constant_words[25U];
	c += r;
	g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));
    
	z0 = _mm_alignr_epi8(v6, v5, 8);
    z1 = _mm_alignr_epi8(v2, v1, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v4, 19), _mm_slli_epi64(v4, 45)), _mm_or_si128(_mm_srli_epi64(v4, 61), _mm_slli_epi64(v4, 3))), _mm_srli_epi64(v4, 6));
    v5 = _mm_add_epi64(_mm_add_epi64(v5, z1), z0);

	r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + SHA512_INTERLEAVED_CHOICE(c, d, e) + (uint64_t)_mm_cvtsi128_si64(v5) + sha512_round_constant_words[26U];
	b += r;
	f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
	r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + SHA512_INTERLEAVED_CHOICE(b, c, d) + (uint64_t)_mm_extract_epi64(v5, 1) + sha512_round_constant_words[27U];
	a += r;
	e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));

    z0 = _mm_alignr_epi8(v7, v6, 8);
    z1 = _mm_alignr_epi8(v3, v2, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v5, 19), _mm_slli_epi64(v5, 45)), _mm_or_si128(_mm_srli_epi64(v5, 61), _mm_slli_epi64(v5, 3))), _mm_srli_epi64(v5, 6));
    v6 = _mm_add_epi64(_mm_add_epi64(v6, z1), z0);

	r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + SHA512_INTERLEAVED_CHOICE(a, b, c) + (uint64_t)_mm_cvtsi128_si64(v6) + sha512_round_constant_words[28U];
	h += r;
	d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
	r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + SHA512_INTERLEAVED_CHOICE(h, a, b) + (uint64_t)_mm_extract_epi64(v6, 1) + sha512_round_constant_words[29U];
	g += r;
	c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));

    z0 = _mm_alignr_epi8(v0, v7, 8);
    z1 = _mm_alignr_epi8(v4, v3, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v6, 19), _mm_slli_epi64(v6, 45)), _mm_or_si128(_mm_srli_epi64(v6, 61), _mm_slli_epi64(v6, 3))), _mm_srli_epi64(v6, 6));
    v7 = _mm_add_epi64(_mm_add_epi64(v7, z1), z0);

	r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + SHA512_INTERLEAVED_CHOICE(g, h, a) + (uint64_t)_mm_cvtsi128_si64(v7) + sha512_round_constant_words[30U];
	f += r;
	b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
	r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + SHA512_INTERLEAVED_CHOICE(f, g, h) + (uint64_t)_mm_extract_epi64(v7, 1) + sha512_round_constant_words[31U];
	e += r;
	a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

    z0 = _mm_alignr_epi8(v1, v0, 8);
    z1 = _mm_alignr_epi8(v5, v4, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v7, 19), _mm_slli_epi64(v7, 45)), _mm_or_si128(_mm_srli_epi64(v7, 61), _mm_slli_epi64(v7, 3))), _mm_srli_epi64(v7, 6));
    v0 = _mm_add_epi64(_mm_add_epi64(v0, z1), z0);

	r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + SHA512_INTERLEAVED_CHOICE(e, f, g) + (uint64_t)_mm_cvtsi128_si64(v0) + sha512_round_constant_words[32U];
	d += r;
	h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
	r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + SHA512_INTERLEAVED_CHOICE(d, e, f) + (uint64_t)_mm_extract_epi64(v0, 1) + sha512_round_constant_words[33U];
	c += r;
	g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));

    z0 = _mm_alignr_epi8(v2, v1, 8);
    z1 = _mm_alignr_epi8(v6, v5, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v0, 19), _mm_slli_epi64(v0, 45)), _mm_or_si128(_mm_srli_epi64(v0, 61), _mm_slli_epi64(v0, 3))), _mm_srli_epi64(v0, 6));
    v1 = _mm_add_epi64(_mm_add_epi64(v1, z1), z0);

	r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + SHA512_INTERLEAVED_CHOICE(c, d, e) + (uint64_t)_mm_cvtsi128_si64(v1) + sha512_round_constant_words[34U];
	b += r;
	f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
	r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + SHA512_INTERLEAVED_CHOICE(b, c, d) + (uint64_t)_mm_extract_epi64(v1, 1) + sha512_round_constant_words[35U];
	a += r;
	e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));

    z0 = _mm_alignr_epi8(v3, v2, 8);
    z1 = _mm_alignr_epi8(v7, v6, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v1, 19), _mm_slli_epi64(v1, 45)), _mm_or_si128(_mm_srli_epi64(v1, 61), _mm_slli_epi64(v1, 3))), _mm_srli_epi64(v1, 6));
    v2 = _mm_add_epi64(_mm_add_epi64(v2, z1), z0);

	r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + SHA512_INTERLEAVED_CHOICE(a, b, c) + (uint64_t)_mm_cvtsi128_si64(v2) + sha512_round_constant_words[36U];
	h += r;
	d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
	r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + SHA512_INTERLEAVED_CHOICE(h, a, b) + (uint64_t)_mm_extract_epi64(v2, 1) + sha512_round_constant_words[37U];
	g += r;
	c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));

    z0 = _mm_alignr_epi8(v4, v3, 8);
    z1 = _mm_alignr_epi8(v0, v7, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v2, 19), _mm_slli_epi64(v2, 45)), _mm_or_si128(_mm_srli_epi64(v2, 61), _mm_slli_epi64(v2, 3))), _mm_srli_epi64(v2, 6));
    v3 = _mm_add_epi64(_mm_add_epi64(v3, z1), z0);

	r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + SHA512_INTERLEAVED_CHOICE(g, h, a) + (uint64_t)_mm_cvtsi128_si64(v3) + sha512_round_constant_words[38U];
	f += r;
	b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
	r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + SHA512_INTERLEAVED_CHOICE(f, g, h) + (uint64_t)_mm_extract_epi64(v3, 1) + sha512_round_constant_words[39U];
	e += r;
	a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

    z0 = _mm_alignr_epi8(v5, v4, 8);
    z1 = _mm_alignr_epi8(v1, v0, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v3, 19), _mm_slli_epi64(v3, 45)), _mm_or_si128(_mm_srli_epi64(v3, 61), _mm_slli_epi64(v3, 3))), _mm_srli_epi64(v3, 6));
    v4 = _mm_add_epi64(_mm_add_epi64(v4, z1), z0);

	r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + SHA512_INTERLEAVED_CHOICE(e, f, g) + (uint64_t)_mm_cvtsi128_si64(v4) + sha512_round_constant_words[40U];
	d += r;
	h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
	r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + SHA512_INTERLEAVED_CHOICE(d, e, f) + (uint64_t)_mm_extract_epi64(v4, 1) + sha512_round_constant_words[41U];
	c += r;
	g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));

    z0 = _mm_alignr_epi8(v6, v5, 8);
    z1 = _mm_alignr_epi8(v2, v1, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v4, 19), _mm_slli_epi64(v4, 45)), _mm_or_si128(_mm_srli_epi64(v4, 61), _mm_slli_epi64(v4, 3))), _mm_srli_epi64(v4, 6));
    v5 = _mm_add_epi64(_mm_add_epi64(v5, z1), z0);

	r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + SHA512_INTERLEAVED_CHOICE(c, d, e) + (uint64_t)_mm_cvtsi128_si64(v5) + sha512_round_constant_words[42U];
	b += r;
	f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
	r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + SHA512_INTERLEAVED_CHOICE(b, c, d) + (uint64_t)_mm_extract_epi64(v5, 1) + sha512_round_constant_words[43U];
	a += r;
	e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));

    z0 = _mm_alignr_epi8(v7, v6, 8);
    z1 = _mm_alignr_epi8(v3, v2, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v5, 19), _mm_slli_epi64(v5, 45)), _mm_or_si128(_mm_srli_epi64(v5, 61), _mm_slli_epi64(v5, 3))), _mm_srli_epi64(v5, 6));
    v6 = _mm_add_epi64(_mm_add_epi64(v6, z1), z0);

	r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + SHA512_INTERLEAVED_CHOICE(a, b, c) + (uint64_t)_mm_cvtsi128_si64(v6) + sha512_round_constant_words[44U];
	h += r;
	d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
	r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + SHA512_INTERLEAVED_CHOICE(h, a, b) + (uint64_t)_mm_extract_epi64(v6, 1) + sha512_round_constant_words[45U];
	g += r;
	c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));
    z0 = _mm_alignr_epi8(v0, v7, 8);
    z1 = _mm_alignr_epi8(v4, v3, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v6, 19), _mm_slli_epi64(v6, 45)), _mm_or_si128(_mm_srli_epi64(v6, 61), _mm_slli_epi64(v6, 3))), _mm_srli_epi64(v6, 6));
    v7 = _mm_add_epi64(_mm_add_epi64(v7, z1), z0);

	r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + SHA512_INTERLEAVED_CHOICE(g, h, a) + (uint64_t)_mm_cvtsi128_si64(v7) + sha512_round_constant_words[46U];
	f += r;
	b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
	r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + SHA512_INTERLEAVED_CHOICE(f, g, h) + (uint64_t)_mm_extract_epi64(v7, 1) + sha512_round_constant_words[47U];
	e += r;
	a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

    z0 = _mm_alignr_epi8(v1, v0, 8);
    z1 = _mm_alignr_epi8(v5, v4, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v7, 19), _mm_slli_epi64(v7, 45)), _mm_or_si128(_mm_srli_epi64(v7, 61), _mm_slli_epi64(v7, 3))), _mm_srli_epi64(v7, 6));
    v0 = _mm_add_epi64(_mm_add_epi64(v0, z1), z0);

	r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + SHA512_INTERLEAVED_CHOICE(e, f, g) + (uint64_t)_mm_cvtsi128_si64(v0) + sha512_round_constant_words[48U];
	d += r;
	h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
	r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + SHA512_INTERLEAVED_CHOICE(d, e, f) + (uint64_t)_mm_extract_epi64(v0, 1) + sha512_round_constant_words[49U];
	c += r;
	g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));

    z0 = _mm_alignr_epi8(v2, v1, 8);
    z1 = _mm_alignr_epi8(v6, v5, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v0, 19), _mm_slli_epi64(v0, 45)), _mm_or_si128(_mm_srli_epi64(v0, 61), _mm_slli_epi64(v0, 3))), _mm_srli_epi64(v0, 6));
    v1 = _mm_add_epi64(_mm_add_epi64(v1, z1), z0);

	r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + SHA512_INTERLEAVED_CHOICE(c, d, e) + (uint64_t)_mm_cvtsi128_si64(v1) + sha512_round_constant_words[50U];
	b += r;
	f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
	r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + SHA512_INTERLEAVED_CHOICE(b, c, d) + (uint64_t)_mm_extract_epi64(v1, 1) + sha512_round_constant_words[51U];
	a += r;
	e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));

    z0 = _mm_alignr_epi8(v3, v2, 8);
    z1 = _mm_alignr_epi8(v7, v6, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v1, 19), _mm_slli_epi64(v1, 45)), _mm_or_si128(_mm_srli_epi64(v1, 61), _mm_slli_epi64(v1, 3))), _mm_srli_epi64(v1, 6));
    v2 = _mm_add_epi64(_mm_add_epi64(v2, z1), z0);

	r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + SHA512_INTERLEAVED_CHOICE(a, b, c) + (uint64_t)_mm_cvtsi128_si64(v2) + sha512_round_constant_words[52U];
	h += r;
	d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
	r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + SHA512_INTERLEAVED_CHOICE(h, a, b) + (uint64_t)_mm_extract_epi64(v2, 1) + sha512_round_constant_words[53U];
	g += r;
	c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));

    z0 = _mm_alignr_epi8(v4, v3, 8);
    z1 = _mm_alignr_epi8(v0, v7, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v2, 19), _mm_slli_epi64(v2, 45)), _mm_or_si128(_mm_srli_epi64(v2, 61), _mm_slli_epi64(v2, 3))), _mm_srli_epi64(v2, 6));
    v3 = _mm_add_epi64(_mm_add_epi64(v3, z1), z0);

	r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + SHA512_INTERLEAVED_CHOICE(g, h, a) + (uint64_t)_mm_cvtsi128_si64(v3) + sha512_round_constant_words[54U];
	f += r;
	b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
	r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + SHA512_INTERLEAVED_CHOICE(f, g, h) + (uint64_t)_mm_extract_epi64(v3, 1) + sha512_round_constant_words[55U];
	e += r;
	a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

    z0 = _mm_alignr_epi8(v5, v4, 8);
    z1 = _mm_alignr_epi8(v1, v0, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v3, 19), _mm_slli_epi64(v3, 45)), _mm_or_si128(_mm_srli_epi64(v3, 61), _mm_slli_epi64(v3, 3))), _mm_srli_epi64(v3, 6));
    v4 = _mm_add_epi64(_mm_add_epi64(v4, z1), z0);

	r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + SHA512_INTERLEAVED_CHOICE(e, f, g) + (uint64_t)_mm_cvtsi128_si64(v4) + sha512_round_constant_words[56U];
	d += r;
	h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
	r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + SHA512_INTERLEAVED_CHOICE(d, e, f) + (uint64_t)_mm_extract_epi64(v4, 1) + sha512_round_constant_words[57U];
	c += r;
	g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));

    z0 = _mm_alignr_epi8(v6, v5, 8);
    z1 = _mm_alignr_epi8(v2, v1, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v4, 19), _mm_slli_epi64(v4, 45)), _mm_or_si128(_mm_srli_epi64(v4, 61), _mm_slli_epi64(v4, 3))), _mm_srli_epi64(v4, 6));
    v5 = _mm_add_epi64(_mm_add_epi64(v5, z1), z0);

	r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + SHA512_INTERLEAVED_CHOICE(c, d, e) + (uint64_t)_mm_cvtsi128_si64(v5) + sha512_round_constant_words[58U];
	b += r;
	f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
	r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + SHA512_INTERLEAVED_CHOICE(b, c, d) + (uint64_t)_mm_extract_epi64(v5, 1) + sha512_round_constant_words[59U];
	a += r;
	e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));

    z0 = _mm_alignr_epi8(v7, v6, 8);
    z1 = _mm_alignr_epi8(v3, v2, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v5, 19), _mm_slli_epi64(v5, 45)), _mm_or_si128(_mm_srli_epi64(v5, 61), _mm_slli_epi64(v5, 3))), _mm_srli_epi64(v5, 6));
    v6 = _mm_add_epi64(_mm_add_epi64(v6, z1), z0);

	r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + SHA512_INTERLEAVED_CHOICE(a, b, c) + (uint64_t)_mm_cvtsi128_si64(v6) + sha512_round_constant_words[60U];
	h += r;
	d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
	r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + SHA512_INTERLEAVED_CHOICE(h, a, b) + (uint64_t)_mm_extract_epi64(v6, 1) + sha512_round_constant_words[61U];
	g += r;
	c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));

    z0 = _mm_alignr_epi8(v0, v7, 8);
    z1 = _mm_alignr_epi8(v4, v3, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v6, 19), _mm_slli_epi64(v6, 45)), _mm_or_si128(_mm_srli_epi64(v6, 61), _mm_slli_epi64(v6, 3))), _mm_srli_epi64(v6, 6));
    v7 = _mm_add_epi64(_mm_add_epi64(v7, z1), z0);

	r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + SHA512_INTERLEAVED_CHOICE(g, h, a) + (uint64_t)_mm_cvtsi128_si64(v7) + sha512_round_constant_words[62U];
	f += r;
	b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
	r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + SHA512_INTERLEAVED_CHOICE(f, g, h) + (uint64_t)_mm_extract_epi64(v7, 1) + sha512_round_constant_words[63U];
	e += r;
	a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

    z0 = _mm_alignr_epi8(v1, v0, 8);
    z1 = _mm_alignr_epi8(v5, v4, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v7, 19), _mm_slli_epi64(v7, 45)), _mm_or_si128(_mm_srli_epi64(v7, 61), _mm_slli_epi64(v7, 3))), _mm_srli_epi64(v7, 6));
    v0 = _mm_add_epi64(_mm_add_epi64(v0, z1), z0);

	r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + SHA512_INTERLEAVED_CHOICE(e, f, g) + (uint64_t)_mm_cvtsi128_si64(v0) + sha512_round_constant_words[64U];
	d += r;
	h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
	r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + SHA512_INTERLEAVED_CHOICE(d, e, f) + (uint64_t)_mm_extract_epi64(v0, 1) + sha512_round_constant_words[65U];
	c += r;
	g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));

    z0 = _mm_alignr_epi8(v2, v1, 8);
    z1 = _mm_alignr_epi8(v6, v5, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v0, 19), _mm_slli_epi64(v0, 45)), _mm_or_si128(_mm_srli_epi64(v0, 61), _mm_slli_epi64(v0, 3))), _mm_srli_epi64(v0, 6));
    v1 = _mm_add_epi64(_mm_add_epi64(v1, z1), z0);

	r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + SHA512_INTERLEAVED_CHOICE(c, d, e) + (uint64_t)_mm_cvtsi128_si64(v1) + sha512_round_constant_words[66U];
	b += r;
	f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
	r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + SHA512_INTERLEAVED_CHOICE(b, c, d) + (uint64_t)_mm_extract_epi64(v1, 1) + sha512_round_constant_words[67U];
	a += r;
	e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));

    z0 = _mm_alignr_epi8(v3, v2, 8);
    z1 = _mm_alignr_epi8(v7, v6, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v1, 19), _mm_slli_epi64(v1, 45)), _mm_or_si128(_mm_srli_epi64(v1, 61), _mm_slli_epi64(v1, 3))), _mm_srli_epi64(v1, 6));
    v2 = _mm_add_epi64(_mm_add_epi64(v2, z1), z0);

	r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + SHA512_INTERLEAVED_CHOICE(a, b, c) + (uint64_t)_mm_cvtsi128_si64(v2) + sha512_round_constant_words[68U];
	h += r;
	d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
	r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + SHA512_INTERLEAVED_CHOICE(h, a, b) + (uint64_t)_mm_extract_epi64(v2, 1) + sha512_round_constant_words[69U];
	g += r;
	c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));

    z0 = _mm_alignr_epi8(v4, v3, 8);
    z1 = _mm_alignr_epi8(v0, v7, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v2, 19), _mm_slli_epi64(v2, 45)), _mm_or_si128(_mm_srli_epi64(v2, 61), _mm_slli_epi64(v2, 3))), _mm_srli_epi64(v2, 6));
    v3 = _mm_add_epi64(_mm_add_epi64(v3, z1), z0);

	r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + SHA512_INTERLEAVED_CHOICE(g, h, a) + (uint64_t)_mm_cvtsi128_si64(v3) + sha512_round_constant_words[70U];
	f += r;
	b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
	r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + SHA512_INTERLEAVED_CHOICE(f, g, h) + (uint64_t)_mm_extract_epi64(v3, 1) + sha512_round_constant_words[71U];
	e += r;
	a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

    z0 = _mm_alignr_epi8(v5, v4, 8);
    z1 = _mm_alignr_epi8(v1, v0, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v3, 19), _mm_slli_epi64(v3, 45)), _mm_or_si128(_mm_srli_epi64(v3, 61), _mm_slli_epi64(v3, 3))), _mm_srli_epi64(v3, 6));
    v4 = _mm_add_epi64(_mm_add_epi64(v4, z1), z0);

	r = h + (((e << 50) | (e >> 14)) ^ ((e << 46) | (e >> 18)) ^ ((e << 23) | (e >> 41))) + SHA512_INTERLEAVED_CHOICE(e, f, g) + (uint64_t)_mm_cvtsi128_si64(v4) + sha512_round_constant_words[72U];
	d += r;
	h = r + (((a << 36) | (a >> 28)) ^ ((a << 30) | (a >> 34)) ^ ((a << 25) | (a >> 39))) + ((a & b) ^ (a & c) ^ (b & c));
	r = g + (((d << 50) | (d >> 14)) ^ ((d << 46) | (d >> 18)) ^ ((d << 23) | (d >> 41))) + SHA512_INTERLEAVED_CHOICE(d, e, f) + (uint64_t)_mm_extract_epi64(v4, 1) + sha512_round_constant_words[73U];
	c += r;
	g = r + (((h << 36) | (h >> 28)) ^ ((h << 30) | (h >> 34)) ^ ((h << 25) | (h >> 39))) + ((h & a) ^ (h & b) ^ (a & b));

    z0 = _mm_alignr_epi8(v6, v5, 8);
    z1 = _mm_alignr_epi8(v2, v1, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v4, 19), _mm_slli_epi64(v4, 45)), _mm_or_si128(_mm_srli_epi64(v4, 61), _mm_slli_epi64(v4, 3))), _mm_srli_epi64(v4, 6));
    v5 = _mm_add_epi64(_mm_add_epi64(v5, z1), z0);

	r = f + (((c << 50) | (c >> 14)) ^ ((c << 46) | (c >> 18)) ^ ((c << 23) | (c >> 41))) + SHA512_INTERLEAVED_CHOICE(c, d, e) + (uint64_t)_mm_cvtsi128_si64(v5) + sha512_round_constant_words[74U];
	b += r;
	f = r + (((g << 36) | (g >> 28)) ^ ((g << 30) | (g >> 34)) ^ ((g << 25) | (g >> 39))) + ((g & h) ^ (g & a) ^ (h & a));
	r = e + (((b << 50) | (b >> 14)) ^ ((b << 46) | (b >> 18)) ^ ((b << 23) | (b >> 41))) + SHA512_INTERLEAVED_CHOICE(b, c, d) + (uint64_t)_mm_extract_epi64(v5, 1) + sha512_round_constant_words[75U];
	a += r;
	e = r + (((f << 36) | (f >> 28)) ^ ((f << 30) | (f >> 34)) ^ ((f << 25) | (f >> 39))) + ((f & g) ^ (f & h) ^ (g & h));

    z0 = _mm_alignr_epi8(v7, v6, 8);
    z1 = _mm_alignr_epi8(v3, v2, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v5, 19), _mm_slli_epi64(v5, 45)), _mm_or_si128(_mm_srli_epi64(v5, 61), _mm_slli_epi64(v5, 3))), _mm_srli_epi64(v5, 6));
    v6 = _mm_add_epi64(_mm_add_epi64(v6, z1), z0);

	r = d + (((a << 50) | (a >> 14)) ^ ((a << 46) | (a >> 18)) ^ ((a << 23) | (a >> 41))) + SHA512_INTERLEAVED_CHOICE(a, b, c) + (uint64_t)_mm_cvtsi128_si64(v6) + sha512_round_constant_words[76U];
	h += r;
	d = r + (((e << 36) | (e >> 28)) ^ ((e << 30) | (e >> 34)) ^ ((e << 25) | (e >> 39))) + ((e & f) ^ (e & g) ^ (f & g));
	r = c + (((h << 50) | (h >> 14)) ^ ((h << 46) | (h >> 18)) ^ ((h << 23) | (h >> 41))) + SHA512_INTERLEAVED_CHOICE(h, a, b) + (uint64_t)_mm_extract_epi64(v6, 1) + sha512_round_constant_words[77U];
	g += r;
	c = r + (((d << 36) | (d >> 28)) ^ ((d << 30) | (d >> 34)) ^ ((d << 25) | (d >> 39))) + ((d & e) ^ (d & f) ^ (e & f));

    z0 = _mm_alignr_epi8(v0, v7, 8);
    z1 = _mm_alignr_epi8(v4, v3, 8);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(z0, 1), _mm_slli_epi64(z0, 63)), _mm_or_si128(_mm_srli_epi64(z0, 8), _mm_slli_epi64(z0, 56))), _mm_srli_epi64(z0, 7));
    z1 = _mm_add_epi64(z1, z0);
    z0 = _mm_xor_si128(_mm_xor_si128(_mm_or_si128(_mm_srli_epi64(v6, 19), _mm_slli_epi64(v6, 45)), _mm_or_si128(_mm_srli_epi64(v6, 61), _mm_slli_epi64(v6, 3))), _mm_srli_epi64(v6, 6));
    v7 = _mm_add_epi64(_mm_add_epi64(v7, z1), z0);

	r = b + (((g << 50) | (g >> 14)) ^ ((g << 46) | (g >> 18)) ^ ((g << 23) | (g >> 41))) + SHA512_INTERLEAVED_CHOICE(g, h, a) + (uint64_t)_mm_cvtsi128_si64(v7) + sha512_round_constant_words[78U];
	f += r;
	b = r + (((c << 36) | (c >> 28)) ^ ((c << 30) | (c >> 34)) ^ ((c << 25) | (c >> 39))) + ((c & d) ^ (c & e) ^ (d & e));
	r = a + (((f << 50) | (f >> 14)) ^ ((f << 46) | (f >> 18)) ^ ((f << 23) | (f >> 41))) + SHA512_INTERLEAVED_CHOICE(f, g, h) + (uint64_t)_mm_extract_epi64(v7, 1) + sha512_round_constant_words[79U];
	e += r;
	a = r + (((b << 36) | (b >> 28)) ^ ((b << 30) | (b >> 34)) ^ ((b << 25) | (b >> 39))) + ((b & c) ^ (b & d) ^ (c & d));

    output[0U] += a;
    output[1U] += b;
    output[2U] += c;
    output[3U] += d;
    output[4U] += e;
    output[5U] += f;
    output[6U] += g;
    output[7U] += h;
}
#undef SHA512_INTERLEAVED_CHOICE

#endif

void qsc_sha512_update(qsc_sha512_state* ctx, const uint8_t* message, size_t msglen)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);

	if (ctx != NULL && message != NULL && msglen != 0U)
	{
		if (ctx->position != 0U && (msglen >= QSC_SHA2_512_RATE - ctx->position))
		{
			const size_t RMDLEN = QSC_SHA2_512_RATE - ctx->position;

			if (RMDLEN != 0U)
			{
				qsc_memutils_copy((ctx->buffer + ctx->position), message, RMDLEN);
			}

			qsc_sha512_permute(ctx->state, ctx->buffer);
			sha512_increase(ctx, QSC_SHA2_512_RATE);
			ctx->position = 0U;
			message += RMDLEN;
			msglen -= RMDLEN;
		}

#if defined(QSC_SYSTEM_X86) && defined(__AVX2__) && defined(__BMI2__)
        if (msglen >= (4U * QSC_SHA2_512_RATE))
        {
            while (msglen >= QSC_SHA2_512_RATE)
            {
                sha512_compress_interleaved(ctx->state, message);
                sha512_increase(ctx, QSC_SHA2_512_RATE);
                message += QSC_SHA2_512_RATE;
                msglen -= QSC_SHA2_512_RATE;
            }
        }
        else
#endif
        {
			/* sequential loop through blocks */
			while (msglen >= QSC_SHA2_512_RATE)
			{
				qsc_sha512_permute(ctx->state, message);
				sha512_increase(ctx, QSC_SHA2_512_RATE);
				message += QSC_SHA2_512_RATE;
				msglen -= QSC_SHA2_512_RATE;
			}
        }

		/* store unaligned bytes */
		if (msglen != 0U)
		{
			qsc_memutils_copy((ctx->buffer + ctx->position), message, msglen);
			ctx->position += msglen;
		}
	}
}

/* HMAC-256 */

void qsc_hmac256_compute(uint8_t* output, const uint8_t* message, size_t msglen, const uint8_t* key, size_t keylen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);
	QSC_ASSERT(key != NULL || keylen == 0U);

	qsc_hmac256_state ctx;

	if (output != NULL && (message != NULL || msglen == 0U) && (key != NULL || keylen == 0U))
	{
		qsc_hmac256_initialize(&ctx, key, keylen);
		qsc_hmac256_update(&ctx, message, msglen);
		qsc_hmac256_finalize(&ctx, output);
	}
}

void qsc_hmac256_dispose(qsc_hmac256_state* ctx)
{
	QSC_ASSERT(ctx != NULL);
	
	if (ctx != NULL)
	{
		qsc_memutils_secure_erase(ctx->ipad, sizeof(ctx->ipad));
		qsc_memutils_secure_erase(ctx->opad, sizeof(ctx->opad));
		qsc_sha256_dispose(&ctx->pstate);
	}
}

void qsc_hmac256_finalize(qsc_hmac256_state* ctx, uint8_t* output)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(output != NULL);

	uint8_t tmpv[QSC_SHA2_256_HASH_SIZE] = { 0U };

	if (ctx != NULL && output != NULL)
	{
		qsc_sha256_finalize(&ctx->pstate, tmpv);
		qsc_sha256_initialize(&ctx->pstate);
		qsc_sha256_update(&ctx->pstate, ctx->opad, sizeof(ctx->opad));
		qsc_sha256_update(&ctx->pstate, tmpv, sizeof(tmpv));
		qsc_sha256_finalize(&ctx->pstate, output);
		qsc_hmac256_dispose(ctx);
		qsc_memutils_secure_erase(tmpv, sizeof(tmpv));
	}
}

void qsc_hmac256_initialize(qsc_hmac256_state* ctx, const uint8_t* key, size_t keylen)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(key != NULL || keylen == 0U);

	const uint8_t IPAD = 0x36U;
	const uint8_t OPAD = 0x5CU;
	static const uint8_t zkey[1U] = { 0U };
	const uint8_t* kptr = key;

	if (ctx != NULL && (key != NULL || keylen == 0U))
	{
		if (kptr == NULL)
		{
			kptr = zkey;
		}

		qsc_memutils_secure_erase(ctx->ipad, QSC_SHA2_256_RATE);

		if (keylen > QSC_SHA2_256_RATE)
		{
			qsc_sha256_initialize(&ctx->pstate);
			qsc_sha256_update(&ctx->pstate, kptr, keylen);
			qsc_sha256_finalize(&ctx->pstate, ctx->ipad);
		}
		else if (keylen != 0U)
		{
			qsc_memutils_copy(ctx->ipad, kptr, keylen);
		}

		qsc_memutils_copy(ctx->opad, ctx->ipad, QSC_SHA2_256_RATE);
		qsc_memutils_xorv(ctx->opad, OPAD, QSC_SHA2_256_RATE);
		qsc_memutils_xorv(ctx->ipad, IPAD, QSC_SHA2_256_RATE);

		qsc_sha256_initialize(&ctx->pstate);
		qsc_sha256_update(&ctx->pstate, ctx->ipad, sizeof(ctx->ipad));
	}
}

void qsc_hmac256_update(qsc_hmac256_state* ctx, const uint8_t* message, size_t msglen)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);

	if (ctx != NULL && msglen != 0U)
	{
		qsc_sha256_update(&ctx->pstate, message, msglen);
	}
}

/* HMAC-384 */

void qsc_hmac384_compute(uint8_t* output, const uint8_t* message, size_t msglen, const uint8_t* key, size_t keylen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);
	QSC_ASSERT(key != NULL || keylen == 0U);

	qsc_hmac384_state ctx;

	if (output != NULL && (message != NULL || msglen == 0U) && (key != NULL || keylen == 0U))
	{
		qsc_hmac384_initialize(&ctx, key, keylen);
		qsc_hmac384_update(&ctx, message, msglen);
		qsc_hmac384_finalize(&ctx, output);
	}
}

void qsc_hmac384_dispose(qsc_hmac384_state* ctx)
{
	QSC_ASSERT(ctx != NULL);

	if (ctx != NULL)
	{
		qsc_memutils_secure_erase(ctx->ipad, sizeof(ctx->ipad));
		qsc_memutils_secure_erase(ctx->opad, sizeof(ctx->opad));
		qsc_sha384_dispose(&ctx->pstate);
	}
}

void qsc_hmac384_finalize(qsc_hmac384_state* ctx, uint8_t* output)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(output != NULL);

	uint8_t tmpv[QSC_SHA2_384_HASH_SIZE] = { 0U };

	if (ctx != NULL && output != NULL)
	{
		qsc_sha384_finalize(&ctx->pstate, tmpv);
		qsc_sha384_initialize(&ctx->pstate);
		qsc_sha384_update(&ctx->pstate, ctx->opad, sizeof(ctx->opad));
		qsc_sha384_update(&ctx->pstate, tmpv, sizeof(tmpv));
		qsc_sha384_finalize(&ctx->pstate, output);
		qsc_hmac384_dispose(ctx);
		qsc_memutils_secure_erase(tmpv, sizeof(tmpv));
	}
}

void qsc_hmac384_initialize(qsc_hmac384_state* ctx, const uint8_t* key, size_t keylen)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(key != NULL || keylen == 0U);

	const uint8_t IPAD = 0x36U;
	const uint8_t OPAD = 0x5CU;
	static const uint8_t zkey[1U] = { 0U };
	const uint8_t* kptr = key;

	if (ctx != NULL && (key != NULL || keylen == 0U))
	{
		if (kptr == NULL)
		{
			kptr = zkey;
		}

		qsc_memutils_secure_erase(ctx->ipad, QSC_SHA2_384_RATE);

		if (keylen > QSC_SHA2_384_RATE)
		{
			qsc_sha384_initialize(&ctx->pstate);
			qsc_sha384_update(&ctx->pstate, kptr, keylen);
			qsc_sha384_finalize(&ctx->pstate, ctx->ipad);
		}
		else if (keylen != 0U)
		{
			qsc_memutils_copy(ctx->ipad, kptr, keylen);
		}

		qsc_memutils_copy(ctx->opad, ctx->ipad, QSC_SHA2_384_RATE);
		qsc_memutils_xorv(ctx->opad, OPAD, QSC_SHA2_384_RATE);
		qsc_memutils_xorv(ctx->ipad, IPAD, QSC_SHA2_384_RATE);

		qsc_sha384_initialize(&ctx->pstate);
		qsc_sha384_update(&ctx->pstate, ctx->ipad, sizeof(ctx->ipad));
	}
}

void qsc_hmac384_update(qsc_hmac384_state* ctx, const uint8_t* message, size_t msglen)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);

	if (ctx != NULL && msglen != 0U)
	{
		qsc_sha384_update(&ctx->pstate, message, msglen);
	}
}

/* HMAC-512 */

void qsc_hmac512_compute(uint8_t* output, const uint8_t* message, size_t msglen, const uint8_t* key, size_t keylen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);
	QSC_ASSERT(key != NULL || keylen == 0U);

	qsc_hmac512_state ctx;

	if (output != NULL && (message != NULL || msglen == 0U) && (key != NULL || keylen == 0U))
	{
		qsc_hmac512_initialize(&ctx, key, keylen);
		qsc_hmac512_update(&ctx, message, msglen);
		qsc_hmac512_finalize(&ctx, output);
	}
}

void qsc_hmac512_dispose(qsc_hmac512_state* ctx)
{
	QSC_ASSERT(ctx != NULL);
	
	if (ctx != NULL)
	{
		qsc_memutils_secure_erase(ctx->ipad, sizeof(ctx->ipad));
		qsc_memutils_secure_erase(ctx->opad, sizeof(ctx->opad));
		qsc_sha512_dispose(&ctx->pstate);
	}
}

void qsc_hmac512_finalize(qsc_hmac512_state* ctx, uint8_t* output)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(output != NULL);

	uint8_t tmpv[QSC_SHA2_512_HASH_SIZE] = { 0U };

	if (ctx != NULL && output != NULL)
	{
		qsc_sha512_finalize(&ctx->pstate, tmpv);
		qsc_sha512_initialize(&ctx->pstate);
		qsc_sha512_update(&ctx->pstate, ctx->opad, sizeof(ctx->opad));
		qsc_sha512_update(&ctx->pstate, tmpv, sizeof(tmpv));
		qsc_sha512_finalize(&ctx->pstate, output);
		qsc_hmac512_dispose(ctx);
		qsc_memutils_secure_erase(tmpv, sizeof(tmpv));
	}
}

void qsc_hmac512_initialize(qsc_hmac512_state* ctx, const uint8_t* key, size_t keylen)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(key != NULL || keylen == 0U);

	const uint8_t IPAD = 0x36U;
	const uint8_t OPAD = 0x5CU;
	static const uint8_t zkey[1U] = { 0U };
	const uint8_t* kptr = key;

	if (ctx != NULL && (key != NULL || keylen == 0U))
	{
		if (kptr == NULL)
		{
			kptr = zkey;
		}

		qsc_memutils_secure_erase(ctx->ipad, QSC_SHA2_512_RATE);

		if (keylen > QSC_SHA2_512_RATE)
		{
			qsc_sha512_initialize(&ctx->pstate);
			qsc_sha512_update(&ctx->pstate, kptr, keylen);
			qsc_sha512_finalize(&ctx->pstate, ctx->ipad);
		}
		else if (keylen != 0U)
		{
			qsc_memutils_copy(ctx->ipad, kptr, keylen);
		}

		qsc_memutils_copy(ctx->opad, ctx->ipad, QSC_SHA2_512_RATE);
		qsc_memutils_xorv(ctx->opad, OPAD, QSC_SHA2_512_RATE);
		qsc_memutils_xorv(ctx->ipad, IPAD, QSC_SHA2_512_RATE);

		qsc_sha512_initialize(&ctx->pstate);
		qsc_sha512_update(&ctx->pstate, ctx->ipad, sizeof(ctx->ipad));
	}
}

void qsc_hmac512_update(qsc_hmac512_state* ctx, const uint8_t* message, size_t msglen)
{
	QSC_ASSERT(ctx != NULL);
	QSC_ASSERT(message != NULL || msglen == 0U);

	if (ctx != NULL && msglen != 0U)
	{
		qsc_sha512_update(&ctx->pstate, message, msglen);
	}
}

/* HKDF-256 */

void qsc_hkdf256_expand(uint8_t* output, size_t otplen, const uint8_t* key, size_t keylen, const uint8_t* info, size_t infolen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(otplen <= 255U * QSC_SHA2_256_HASH_SIZE);
	QSC_ASSERT(key != NULL);
	QSC_ASSERT(info != NULL || infolen == 0U);

	qsc_hmac256_state ctx;
	qsc_hmac256_state template_state;
	size_t rmdlen;
	uint8_t buf[QSC_SHA2_256_HASH_SIZE] = { 0U };
	uint8_t ctr[1U] = { 0U };

	if (output != NULL && key != NULL && (info != NULL || infolen == 0U))
	{
		if (otplen <= 255U * QSC_SHA2_256_HASH_SIZE)
		{
			if (otplen <= (size_t)QSC_SHA2_256_HASH_SIZE)
			{
				while (otplen != 0U)
				{
					qsc_hmac256_initialize(&ctx, key, keylen);
	
					if (ctr[0U] != 0U)
					{
						qsc_hmac256_update(&ctx, buf, sizeof(buf));
					}
	
					if (infolen != 0U)
					{
						qsc_hmac256_update(&ctx, info, infolen);
					}
	
					++ctr[0U];
					qsc_hmac256_update(&ctx, ctr, sizeof(ctr));
					qsc_hmac256_finalize(&ctx, buf);
	
					rmdlen = qsc_intutils_min(otplen, (size_t)QSC_SHA2_256_HASH_SIZE);
					qsc_memutils_copy(output, buf, rmdlen);
	
					otplen -= rmdlen;
					output += rmdlen;
				}
			}
			else
			{
				qsc_hmac256_initialize(&template_state, key, keylen);
				while (otplen != 0U)
				{
					qsc_memutils_copy((uint8_t*)&ctx, (const uint8_t*)&template_state, sizeof(ctx));
	
					if (ctr[0U] != 0U)
					{
						qsc_hmac256_update(&ctx, buf, sizeof(buf));
					}
	
					if (infolen != 0U)
					{
						qsc_hmac256_update(&ctx, info, infolen);
					}
	
					++ctr[0U];
					qsc_hmac256_update(&ctx, ctr, sizeof(ctr));
					qsc_hmac256_finalize(&ctx, buf);
	
					rmdlen = qsc_intutils_min(otplen, (size_t)QSC_SHA2_256_HASH_SIZE);
					qsc_memutils_copy(output, buf, rmdlen);
	
					otplen -= rmdlen;
					output += rmdlen;
				}
				qsc_hmac256_dispose(&template_state);
			}
		}
	}
	qsc_memutils_secure_erase(buf, sizeof(buf));
}

void qsc_hkdf256_extract(uint8_t* output, size_t otplen, const uint8_t* key, size_t keylen, const uint8_t* salt, size_t saltlen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(otplen >= QSC_SHA2_256_HASH_SIZE);
	QSC_ASSERT(key != NULL || keylen == 0U);
	QSC_ASSERT(salt != NULL || saltlen == 0U);

	if (output != NULL && (key != NULL || keylen == 0U) && (salt != NULL || saltlen == 0U) && otplen >= QSC_SHA2_256_HASH_SIZE)
	{
		qsc_hmac256_state ctx;
		static const uint8_t zkey[1U] = { 0U };
		const uint8_t* kptr = key;

		if (kptr == NULL)
		{
			kptr = zkey;
		}

		if (saltlen != 0U)
		{
			qsc_hmac256_initialize(&ctx, salt, saltlen);
		}
		else
		{
			uint8_t tmp[QSC_HMAC_256_MAC_SIZE] = { 0U };
			qsc_hmac256_initialize(&ctx, tmp, sizeof(tmp));
		}

		qsc_hmac256_update(&ctx, kptr, keylen);
		qsc_hmac256_finalize(&ctx, output);
	}
}

/* HKDF-512 */

void qsc_hkdf384_expand(uint8_t* output, size_t otplen, const uint8_t* key, size_t keylen, const uint8_t* info, size_t infolen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(otplen <= 255U * QSC_SHA2_384_HASH_SIZE);
	QSC_ASSERT(key != NULL);
	QSC_ASSERT(info != NULL || infolen == 0U);

	qsc_hmac384_state ctx;
	qsc_hmac384_state template_state;
	size_t rmdlen;
	uint8_t buf[QSC_SHA2_384_HASH_SIZE] = { 0U };
	uint8_t ctr[1U] = { 0U };

	if (output != NULL && key != NULL && (info != NULL || infolen == 0U))
	{
		if (otplen <= 255U * QSC_SHA2_384_HASH_SIZE)
		{
			if (otplen <= (size_t)QSC_SHA2_384_HASH_SIZE)
			{
				while (otplen != 0U)
				{
					qsc_hmac384_initialize(&ctx, key, keylen);
	
					if (ctr[0U] != 0U)
					{
						qsc_hmac384_update(&ctx, buf, sizeof(buf));
					}
	
					if (infolen != 0U)
					{
						qsc_hmac384_update(&ctx, info, infolen);
					}
	
					++ctr[0U];
					qsc_hmac384_update(&ctx, ctr, sizeof(ctr));
					qsc_hmac384_finalize(&ctx, buf);
	
					rmdlen = qsc_intutils_min(otplen, (size_t)QSC_SHA2_384_HASH_SIZE);
					qsc_memutils_copy(output, buf, rmdlen);
	
					otplen -= rmdlen;
					output += rmdlen;
				}
			}
			else
			{
				qsc_hmac384_initialize(&template_state, key, keylen);

				while (otplen != 0U)
				{
					qsc_memutils_copy((uint8_t*)&ctx, (const uint8_t*)&template_state, sizeof(ctx));
	
					if (ctr[0U] != 0U)
					{
						qsc_hmac384_update(&ctx, buf, sizeof(buf));
					}
	
					if (infolen != 0U)
					{
						qsc_hmac384_update(&ctx, info, infolen);
					}
	
					++ctr[0U];
					qsc_hmac384_update(&ctx, ctr, sizeof(ctr));
					qsc_hmac384_finalize(&ctx, buf);
	
					rmdlen = qsc_intutils_min(otplen, (size_t)QSC_SHA2_384_HASH_SIZE);
					qsc_memutils_copy(output, buf, rmdlen);
	
					otplen -= rmdlen;
					output += rmdlen;
				}
				qsc_hmac384_dispose(&template_state);
			}
		}
	}
	qsc_memutils_secure_erase(buf, sizeof(buf));
}

void qsc_hkdf384_extract(uint8_t* output, size_t otplen, const uint8_t* key, size_t keylen, const uint8_t* salt, size_t saltlen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(otplen >= QSC_SHA2_384_HASH_SIZE);
	QSC_ASSERT(key != NULL || keylen == 0U);
	QSC_ASSERT(salt != NULL || saltlen == 0U);

	if (output != NULL && (key != NULL || keylen == 0U) && (salt != NULL || saltlen == 0U) && otplen >= QSC_SHA2_384_HASH_SIZE)
	{
		qsc_hmac384_state ctx;
		static const uint8_t zkey[1U] = { 0U };
		const uint8_t* kptr = key;

		if (kptr == NULL)
		{
			kptr = zkey;
		}

		if (saltlen != 0U)
		{
			qsc_hmac384_initialize(&ctx, salt, saltlen);
		}
		else
		{
			uint8_t tmp[QSC_HMAC_384_MAC_SIZE] = { 0U };
			qsc_hmac384_initialize(&ctx, tmp, sizeof(tmp));
		}

		qsc_hmac384_update(&ctx, kptr, keylen);
		qsc_hmac384_finalize(&ctx, output);
	}
}

/* HKDF-512 */

void qsc_hkdf512_expand(uint8_t* output, size_t otplen, const uint8_t* key, size_t keylen, const uint8_t* info, size_t infolen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(otplen <= 255U * QSC_SHA2_512_HASH_SIZE);
	QSC_ASSERT(key != NULL);
	QSC_ASSERT(info != NULL || infolen == 0U);

	qsc_hmac512_state ctx;
	qsc_hmac512_state template_state;
	size_t rmdlen;
	uint8_t buf[QSC_SHA2_512_HASH_SIZE] = { 0U };
	uint8_t ctr[1U] = { 0U };

	if (output != NULL && key != NULL && (info != NULL || infolen == 0U))
	{
		if (otplen <= 255U * QSC_SHA2_512_HASH_SIZE)
		{
			if (otplen <= (size_t)QSC_SHA2_512_HASH_SIZE)
			{
				while (otplen != 0U)
				{
					qsc_hmac512_initialize(&ctx, key, keylen);
	
					if (ctr[0U] != 0U)
					{
						qsc_hmac512_update(&ctx, buf, sizeof(buf));
					}
	
					if (infolen != 0U)
					{
						qsc_hmac512_update(&ctx, info, infolen);
					}
	
					++ctr[0U];
					qsc_hmac512_update(&ctx, ctr, sizeof(ctr));
					qsc_hmac512_finalize(&ctx, buf);
	
					rmdlen = qsc_intutils_min(otplen, (size_t)QSC_SHA2_512_HASH_SIZE);
					qsc_memutils_copy(output, buf, rmdlen);
	
					otplen -= rmdlen;
					output += rmdlen;
				}
			}
			else
			{
				qsc_hmac512_initialize(&template_state, key, keylen);

				while (otplen != 0U)
				{
					qsc_memutils_copy((uint8_t*)&ctx, (const uint8_t*)&template_state, sizeof(ctx));
	
					if (ctr[0U] != 0U)
					{
						qsc_hmac512_update(&ctx, buf, sizeof(buf));
					}
	
					if (infolen != 0U)
					{
						qsc_hmac512_update(&ctx, info, infolen);
					}
	
					++ctr[0U];
					qsc_hmac512_update(&ctx, ctr, sizeof(ctr));
					qsc_hmac512_finalize(&ctx, buf);
	
					rmdlen = qsc_intutils_min(otplen, (size_t)QSC_SHA2_512_HASH_SIZE);
					qsc_memutils_copy(output, buf, rmdlen);
	
					otplen -= rmdlen;
					output += rmdlen;
				}
				qsc_hmac512_dispose(&template_state);
			}
		}
	}
	qsc_memutils_secure_erase(buf, sizeof(buf));
}

void qsc_hkdf512_extract(uint8_t* output, size_t otplen, const uint8_t* key, size_t keylen, const uint8_t* salt, size_t saltlen)
{
	QSC_ASSERT(output != NULL);
	QSC_ASSERT(otplen >= QSC_SHA2_512_HASH_SIZE);
	QSC_ASSERT(key != NULL || keylen == 0U);
	QSC_ASSERT(salt != NULL || saltlen == 0U);

	if (output != NULL && (key != NULL || keylen == 0U) && (salt != NULL || saltlen == 0U) && otplen >= QSC_SHA2_512_HASH_SIZE)
	{
		qsc_hmac512_state ctx;
		static const uint8_t zkey[1U] = { 0U };
		const uint8_t* kptr = key;

		if (kptr == NULL)
		{
			kptr = zkey;
		}

		if (saltlen != 0U)
		{
			qsc_hmac512_initialize(&ctx, salt, saltlen);
		}
		else
		{
			uint8_t tmp[QSC_HMAC_512_MAC_SIZE] = { 0U };
			qsc_hmac512_initialize(&ctx, tmp, sizeof(tmp));
		}

		qsc_hmac512_update(&ctx, kptr, keylen);
		qsc_hmac512_finalize(&ctx, output);
	}
}
