#[=[
/* 2020-2026 Quantum Resistant Cryptographic Solutions Corporation
 * All Rights Reserved.
 *
 * NOTICE:
 * This software and all accompanying materials are the exclusive property of
 * Quantum Resistant Cryptographic Solutions Corporation (QRCS). The intellectual
 * and technical concepts contained herein are proprietary to QRCS and are
 * protected under applicable Canadian, U.S., and international copyright,
 * patent, and trade secret laws.
 *
 * CRYPTOGRAPHIC ALGORITHMS AND IMPLEMENTATIONS:
 * - This software includes implementations of cryptographic primitives and
 *   algorithms that are standardized or in the public domain, such as AES
 *   and SHA-3, which are not proprietary to QRCS.
 * - This software also includes cryptographic primitives, constructions, and
 *   algorithms designed by QRCS, including but not limited to RCS, SCB, CSX, QMAC, and
 *   related components, which are proprietary to QRCS.
 * - All source code, implementations, protocol compositions, optimizations,
 *   parameter selections, and engineering work contained in this software are
 *   original works of QRCS and are protected under this license.
 *
 * LICENSE AND USE RESTRICTIONS:
 * - This software is licensed under the Quantum Resistant Cryptographic Solutions
 *   Public Research and Evaluation License (QRCS-PREL), 2025-2026.
 * - Permission is granted solely for non-commercial evaluation, academic research,
 *   cryptographic analysis, interoperability testing, and feasibility assessment.
 * - Commercial use, production deployment, commercial redistribution, or
 *   integration into products or services is strictly prohibited without a
 *   separate written license agreement executed with QRCS.
 * - Licensing and authorized distribution are solely at the discretion of QRCS.
 *
 * EXPERIMENTAL CRYPTOGRAPHY NOTICE:
 * Portions of this software may include experimental, novel, or evolving
 * cryptographic designs. Use of this software is entirely at the user's risk.
 *
 * DISCLAIMER:
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, SECURITY, OR NON-INFRINGEMENT. QRCS DISCLAIMS ALL
 * LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING FROM THE USE OR MISUSE OF THIS SOFTWARE.
 *
 * FULL LICENSE:
 * This software is subject to the Quantum Resistant Cryptographic Solutions
 * Public Research and Evaluation License (QRCS-PREL), 2025-2026. The complete license terms
 * are provided in the accompanying LICENSE file or at https://www.qrcscorp.ca.
 *
 * Written by: John G. Underhill
 * Contact: contact@qrcscorp.ca
 */
]=]

# Profiles are composition recipes, not alternative source implementations.
set(QSC_SUPPORTED_PROFILES
    FULL
    BOOT_VERIFY
    DEVICE_IDENTITY
    CRYPTO_CLASSICAL
    CRYPTO_PQC3
    CRYPTO_PQC5
    CRYPTO_HYBRID
    CLOUD_HSM
    EDGE_GATEWAY
)

function(qsc_resolve_profile _profile _out_sources _out_algorithms)
    if(NOT _profile IN_LIST QSC_SUPPORTED_PROFILES)
        message(FATAL_ERROR "Unknown QSC_PROFILE='${_profile}'. Supported: ${QSC_SUPPORTED_PROFILES}")
    endif()

    if(_profile STREQUAL "FULL" OR _profile STREQUAL "CLOUD_HSM" OR _profile STREQUAL "EDGE_GATEWAY")
        # TLS and X.509 require the unchanged complete dispatch dependency set.
        # CLOUD_HSM/EDGE_GATEWAY are intentionally full-crypto recipes for now.
        set(_files ${QSC_ALL_SOURCES})
        set(_algorithms "ALL")
    else()
        set(_files ${QSC_COMPACT_SUPPORT_SOURCES})
        if(_profile STREQUAL "BOOT_VERIFY")
            list(APPEND _files sha2.c sha3.c csp.c ecdsap256.c mldsa65.c)
            set(_algorithms "ECDSA_P256_VERIFY;MLDSA65_VERIFY;SHA2;SHA3")
        elseif(_profile STREQUAL "DEVICE_IDENTITY" OR _profile STREQUAL "CRYPTO_HYBRID")
            list(APPEND _files sha2.c sha3.c aes.c csp.c ed25519.c ${QSC_CLASSICAL_PRIMITIVE_SOURCES} ${QSC_PQC3_PRIMITIVE_SOURCES})
            set(_algorithms "X25519;ECDSA_P256;MLKEM768;MLDSA65;SHA2;SHA3;AES_GCM")
        elseif(_profile STREQUAL "CRYPTO_CLASSICAL")
            list(APPEND _files sha2.c sha3.c aes.c csp.c ed25519.c ${QSC_CLASSICAL_PRIMITIVE_SOURCES})
            set(_algorithms "X25519;ECDSA_P256;SHA2;AES_GCM")
        elseif(_profile STREQUAL "CRYPTO_PQC3")
            list(APPEND _files sha3.c aes.c ${QSC_PQC3_PRIMITIVE_SOURCES})
            set(_algorithms "MLKEM768;MLDSA65;SHA3;AES_GCM")
        elseif(_profile STREQUAL "CRYPTO_PQC5")
            list(APPEND _files sha3.c aes.c ${QSC_PQC5_PRIMITIVE_SOURCES})
            set(_algorithms "MLKEM1024;MLDSA87;SHA3;AES_GCM")
        endif()
    endif()

    list(REMOVE_DUPLICATES _files)
    set(${_out_sources} "${_files}" PARENT_SCOPE)
    set(${_out_algorithms} "${_algorithms}" PARENT_SCOPE)
endfunction()
