#[=[
/* 2020-2026 Quantum Resistant Cryptographic Solutions Corporation
 * All Rights Reserved.
 *
 * NOTICE:
 * This software and all accompanying materials are the exclusive property of
 * Quantum Resistant Cryptographic Solutions Corporation (QRCS). The intellectual
 * and technical concepts contained herein are proprietary to QRCS and are
 * protected under applicable Canadian, U.S., and international copyright,
 * patent, and trade secret laws.
 *
 * CRYPTOGRAPHIC ALGORITHMS AND IMPLEMENTATIONS:
 * - This software includes implementations of cryptographic primitives and
 *   algorithms that are standardized or in the public domain, such as AES
 *   and SHA-3, which are not proprietary to QRCS.
 * - This software also includes cryptographic primitives, constructions, and
 *   algorithms designed by QRCS, including but not limited to RCS, SCB, CSX, QMAC, and
 *   related components, which are proprietary to QRCS.
 * - All source code, implementations, protocol compositions, optimizations,
 *   parameter selections, and engineering work contained in this software are
 *   original works of QRCS and are protected under this license.
 *
 * LICENSE AND USE RESTRICTIONS:
 * - This software is licensed under the Quantum Resistant Cryptographic Solutions
 *   Public Research and Evaluation License (QRCS-PREL), 2025-2026.
 * - Permission is granted solely for non-commercial evaluation, academic research,
 *   cryptographic analysis, interoperability testing, and feasibility assessment.
 * - Commercial use, production deployment, commercial redistribution, or
 *   integration into products or services is strictly prohibited without a
 *   separate written license agreement executed with QRCS.
 * - Licensing and authorized distribution are solely at the discretion of QRCS.
 *
 * EXPERIMENTAL CRYPTOGRAPHY NOTICE:
 * Portions of this software may include experimental, novel, or evolving
 * cryptographic designs. Use of this software is entirely at the user's risk.
 *
 * DISCLAIMER:
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, SECURITY, OR NON-INFRINGEMENT. QRCS DISCLAIMS ALL
 * LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING FROM THE USE OR MISUSE OF THIS SOFTWARE.
 *
 * FULL LICENSE:
 * This software is subject to the Quantum Resistant Cryptographic Solutions
 * Public Research and Evaluation License (QRCS-PREL), 2025-2026. The complete license terms
 * are provided in the accompanying LICENSE file or at https://www.qrcscorp.ca.
 *
 * Written by: John G. Underhill
 * Contact: contact@qrcscorp.ca
 */
]=]

# QSC CMake profile integration

The CMake files target the **QSC 2026-11-06** source snapshot. Copy them into the same directory as `QSC.vcxproj`. No existing QSC files are replaced or modified.

**Scope:** static libraries only. The existing Visual Studio projects remain authoritative for existing MSVC configurations. Shared-library ABI and fine-grained TLS/X.509 pruning are deferred. This CMake system never changes cryptographic arithmetic.

## Quick start

```sh
cmake -S . -B out/full -DCMAKE_BUILD_TYPE=Release -DQSC_PROFILE=FULL
cmake --build out/full --parallel

cmake -S . -B out/pqc3 -DCMAKE_BUILD_TYPE=Release -DQSC_PROFILE=CRYPTO_PQC3
cmake --build out/pqc3 --parallel
```

For generators with multiple configurations, use `cmake --build out/full --config Release`. The supplied presets require Ninja. On Windows the normal MSVC toolchain must be available (e.g. run from a Visual Studio Developer Command Prompt).

Profiles: `FULL`, `BOOT_VERIFY`, `DEVICE_IDENTITY`, `CRYPTO_CLASSICAL`, `CRYPTO_PQC3`, `CRYPTO_PQC5`, `CRYPTO_HYBRID`, `CLOUD_HSM`, `EDGE_GATEWAY`. The last two deliberately include the full TLS/X.509 dependency graph; they are NOT compact TLS variants yet. `BOOT_VERIFY` includes complete ECDSA-P256 and ML-DSA-65 translation units; verification-only source-level trimming is not promised.

Hardware can be enabled independently:

```sh
cmake -S . -B out/hsm -DCMAKE_BUILD_TYPE=Release -DQSC_PROFILE=CLOUD_HSM -DQSC_ENABLE_HARDWARE=ON -DQSC_HARDWARE_PROVIDERS=PKCS11
cmake --build out/hsm --parallel
```

Supported provider names: `PKCS11`, `NCRYPT` (Windows), `TPM` (Linux with tss2-esys/tctildr), `ATECC`, `SE050`, `PSA`, `PSA_NATIVE` (requires `QSC_PSA_INCLUDE_DIR` and `QSC_PSA_LIBRARY`), and `PLATFORM`. Provider presence in a build is not proof that a device or a particular algorithm is available at runtime. Never silently route hardware-owned private-key operations into software.

`QSC_CPU_TARGET` defaults to `BASELINE`; `AVX2` is opt-in and must only run on compatible CPUs. All cross-compiler ISA detection remains in the original QSC files. Consumer applications may use `find_package(QSC CONFIG REQUIRED)` and link `QSC::QSC` after installing a profile. The installed `QSCFeatures.h` and `QSCCapabilities.json` describe the binary, but all original QSC headers are installed unchanged: a compact build does *not* implement every API declared by the headers.

**Current limitations:** Windows DLL/shared builds are intentionally rejected to honor the zero-source-change requirement. The portable `CLOUD_HSM` and `EDGE_GATEWAY` recipes retain all primitive dependencies. Code-size and cryptographic conformance must be measured and qualified independently for every supported build. There is no runtime CPU dispatch.
