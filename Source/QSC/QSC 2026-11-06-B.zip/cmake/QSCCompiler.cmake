#[=[
/* 2020-2026 Quantum Resistant Cryptographic Solutions Corporation
 * All Rights Reserved.
 *
 * NOTICE:
 * This software and all accompanying materials are the exclusive property of
 * Quantum Resistant Cryptographic Solutions Corporation (QRCS). The intellectual
 * and technical concepts contained herein are proprietary to QRCS and are
 * protected under applicable Canadian, U.S., and international copyright,
 * patent, and trade secret laws.
 *
 * CRYPTOGRAPHIC ALGORITHMS AND IMPLEMENTATIONS:
 * - This software includes implementations of cryptographic primitives and
 *   algorithms that are standardized or in the public domain, such as AES
 *   and SHA-3, which are not proprietary to QRCS.
 * - This software also includes cryptographic primitives, constructions, and
 *   algorithms designed by QRCS, including but not limited to RCS, SCB, CSX, QMAC, and
 *   related components, which are proprietary to QRCS.
 * - All source code, implementations, protocol compositions, optimizations,
 *   parameter selections, and engineering work contained in this software are
 *   original works of QRCS and are protected under this license.
 *
 * LICENSE AND USE RESTRICTIONS:
 * - This software is licensed under the Quantum Resistant Cryptographic Solutions
 *   Public Research and Evaluation License (QRCS-PREL), 2025-2026.
 * - Permission is granted solely for non-commercial evaluation, academic research,
 *   cryptographic analysis, interoperability testing, and feasibility assessment.
 * - Commercial use, production deployment, commercial redistribution, or
 *   integration into products or services is strictly prohibited without a
 *   separate written license agreement executed with QRCS.
 * - Licensing and authorized distribution are solely at the discretion of QRCS.
 *
 * EXPERIMENTAL CRYPTOGRAPHY NOTICE:
 * Portions of this software may include experimental, novel, or evolving
 * cryptographic designs. Use of this software is entirely at the user's risk.
 *
 * DISCLAIMER:
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, SECURITY, OR NON-INFRINGEMENT. QRCS DISCLAIMS ALL
 * LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING FROM THE USE OR MISUSE OF THIS SOFTWARE.
 *
 * FULL LICENSE:
 * This software is subject to the Quantum Resistant Cryptographic Solutions
 * Public Research and Evaluation License (QRCS-PREL), 2025-2026. The complete license terms
 * are provided in the accompanying LICENSE file or at https://www.qrcscorp.ca.
 *
 * Written by: John G. Underhill
 * Contact: contact@qrcscorp.ca
 */
]=]

# Preserve the source's compile-time ISA dispatch; no runtime CPU dispatch.
set(QSC_CPU_TARGET "BASELINE" CACHE STRING "CPU target: BASELINE or AVX2")
set_property(CACHE QSC_CPU_TARGET PROPERTY STRINGS BASELINE AVX2)

function(qsc_configure_compiler _target)
    if(NOT QSC_CPU_TARGET STREQUAL "BASELINE" AND NOT QSC_CPU_TARGET STREQUAL "AVX2")
        message(FATAL_ERROR "Unsupported QSC_CPU_TARGET=${QSC_CPU_TARGET}")
    endif()
    if(MSVC)
        target_compile_options(${_target} PRIVATE /W3 /sdl)
        if(QSC_CPU_TARGET STREQUAL "AVX2")
            if(NOT CMAKE_SYSTEM_PROCESSOR MATCHES "AMD64|amd64|x86|X86")
                message(FATAL_ERROR "AVX2 target requires x86/x64")
            endif()
            target_compile_options(${_target} PRIVATE /arch:AVX2)
        endif()
    else()
        target_compile_options(${_target} PRIVATE
            $<$<CONFIG:Release>:-ffunction-sections>
            $<$<CONFIG:Release>:-fdata-sections>
        )
        if(QSC_CPU_TARGET STREQUAL "AVX2")
            if(NOT CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|amd64|AMD64|i[3-6]86")
                message(FATAL_ERROR "AVX2 target requires x86/x64")
            endif()
            target_compile_options(${_target} PRIVATE -mavx2 -maes -mpclmul)
        endif()
    endif()
endfunction()
