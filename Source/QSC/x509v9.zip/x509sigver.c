#include "x509sigver.h"
#include "x509cert.h"
#include "memutils.h"

static bool x509_qsc_verify_is_supported_algorithm(const qsc_x509_certificate* certificate, const qsc_x509_certificate* issuer)
{
	bool res;

	res = false;

	if (certificate != (const qsc_x509_certificate*)NULL &&
		issuer != (const qsc_x509_certificate*)NULL)
	{
		if (certificate->signaturealgorithm.signature == QSC_X509_SIGNATURE_ALGORITHM_ECDSA_SHA256 &&
			issuer->subjectpublickeyinfo.algorithm.publickey == QSC_X509_PUBLIC_KEY_ALGORITHM_EC &&
			issuer->subjectpublickeyinfo.algorithm.curve == QSC_X509_NAMED_CURVE_PRIME256V1)
		{
			res = true;
		}
	}

	return res;
}

void qsc_x509_qsc_verify_state_initialize(qsc_x509_qsc_verify_state* state, uint8_t* buffer, size_t buflen)
{
	if (state != (qsc_x509_qsc_verify_state*)NULL)
	{
		state->signaturemessage = buffer;
		state->signaturemessage_size = buflen;
	}
}

bool qsc_x509_qsc_signature_verify(const qsc_x509_certificate* certificate, const qsc_x509_certificate* issuer, void* state)
{
	qsc_x509_qsc_verify_state* vstate;
	qsc_x509_ecdsa_signature esig;
	uint8_t pubkey[QSC_ECDSA_PUBLICKEY_SIZE];
	uint8_t x[32U];
	uint8_t y[32U];
	uint8_t* buffer;
	size_t buflen;
	size_t signedlen;
	size_t msglen;
	bool res;

	vstate = (qsc_x509_qsc_verify_state*)state;
	buffer = (uint8_t*)NULL;
	buflen = 0U;
	signedlen = 0U;
	msglen = 0U;
	res = false;
	qsc_memutils_clear((uint8_t*)&esig, sizeof(qsc_x509_ecdsa_signature));
	qsc_memutils_clear(pubkey, sizeof(pubkey));
	qsc_memutils_clear(x, sizeof(x));
	qsc_memutils_clear(y, sizeof(y));

	if (certificate != (const qsc_x509_certificate*)NULL &&
		issuer != (const qsc_x509_certificate*)NULL &&
		vstate != (qsc_x509_qsc_verify_state*)NULL)
	{
		buffer = vstate->signaturemessage;
		buflen = vstate->signaturemessage_size;

		if (buffer != (uint8_t*)NULL &&
			certificate->tbsdata != (const uint8_t*)NULL &&
			certificate->tbsdatalen != 0U &&
			x509_qsc_verify_is_supported_algorithm(certificate, issuer) == true &&
			buflen >= (QSC_ECDSA_SIGNATURE_SIZE + certificate->tbsdatalen))
		{
			/*
			 * The decoded certificate stores the raw BIT STRING contents in
			 * certificate->signature. For ECDSA in X.509, those contents are DER
			 * encoded as SEQUENCE { INTEGER r, INTEGER s }. Decode them into the
			 * fixed-width raw QSC form.
			 */
			{
				qsc_encoding_ber_element outer;
				uint8_t bitstring[sizeof(certificate->signature) + 1U];

				qsc_memutils_clear((uint8_t*)&outer, sizeof(qsc_encoding_ber_element));
				qsc_memutils_clear(bitstring, sizeof(bitstring));

				outer.tagclass = 0x00U;
				outer.constructed = false;
				outer.tagnumber = 3U;
				outer.length = certificate->signaturelen + 1U;
				outer.value = bitstring;
				bitstring[0U] = certificate->signatureunusedbits;
				qsc_memutils_copy(bitstring + 1U, certificate->signature, certificate->signaturelen);

				if (qsc_x509_signature_value_decode_ecdsa(&outer, QSC_X509_NAMED_CURVE_PRIME256V1, &esig) == QSC_ASN1_STATUS_SUCCESS)
				{
					if (qsc_x509_spki_get_ec_coordinates(&issuer->subjectpublickeyinfo, x, sizeof(x), y, sizeof(y)) == QSC_ASN1_STATUS_SUCCESS)
					{
						uint8_t* recovered;

						qsc_memutils_copy(pubkey, x, sizeof(x));
						qsc_memutils_copy(pubkey + sizeof(x), y, sizeof(y));

						if (certificate->tbsdatalen > 0U)
						{
							recovered = qsc_memutils_malloc(certificate->tbsdatalen);

							if (recovered != NULL)
							{
								qsc_memutils_clear(recovered, certificate->tbsdatalen);
								res = qsc_ecdsa_verify(recovered, &msglen, buffer, signedlen, pubkey);

								if (res == true)
								{
									res = (msglen == certificate->tbsdatalen);
								}

								qsc_memutils_secure_erase(recovered, sizeof(recovered));
								qsc_memutils_alloc_free(recovered);
							}
						}
					}
				}
			}
		}
	}

	qsc_memutils_secure_erase(pubkey, sizeof(pubkey));
	qsc_memutils_secure_erase(x, sizeof(x));
	qsc_memutils_secure_erase(y, sizeof(y));
	qsc_memutils_secure_erase((uint8_t*)&esig, sizeof(qsc_x509_ecdsa_signature));

	return res;
}
