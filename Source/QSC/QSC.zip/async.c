#include "async.h"
#include "memutils.h"
#include "sysutils.h"
#include <stdarg.h>
#include <stdlib.h>

#if defined(QSC_SYSTEM_OS_WINDOWS)
#   if !defined(WIN32_LEAN_AND_MEAN)
#       define WIN32_LEAN_AND_MEAN
#   endif
#   if !defined(VC_EXTRALEAN)
#       define VC_EXTRALEAN
#   endif
#   if !defined(NOMINMAX)
#       define NOMINMAX
#   endif
#   if !defined(_WINSOCKAPI_)
#       define _WINSOCKAPI_
#   endif
#   include <windows.h>
#   include <intrin.h>
#   include <process.h>
#define THREAD_FUNC_RETURN uint32_t __stdcall
#define THREAD_FUNC_CALL __stdcall
#elif defined(QSC_SYSTEM_OS_POSIX)
#   include <time.h>
#   include <unistd.h>
#   define THREAD_FUNC_RETURN void*
#   define THREAD_FUNC_CALL
static pthread_mutex_t tsusp = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t tcond = PTHREAD_COND_INITIALIZER;
static bool suspended = false;
#endif

/*!
 * \struct async_thread_task_t
 * \brief Contains the thread task context state.
 */
typedef struct
{
    void (*task)(void* context, size_t index);  /*!< Function to execute */
    void* context;                              /*!< Context to pass to the task */
    size_t index;                               /*!< Index for this thread */
} async_thread_task_t;

THREAD_FUNC_RETURN THREAD_FUNC_CALL async_thread_worker(void* arg)
{
    async_thread_task_t* task = (async_thread_task_t*)arg;
    task->task(task->context, task->index);
    return 0;
}

bool qsc_async_atomic_bool_load(volatile bool* target)
{
    QSC_ASSERT(target != NULL);

    bool res;

    res = false;

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        /* OR with 0: reads atomically without modifying the value */
        res = (_InterlockedOr8((volatile char*)target, (char)0) != (char)0);
#else
        res = __atomic_load_n(target, __ATOMIC_SEQ_CST);
#endif
    }

    return res;
}

void qsc_async_atomic_bool_store(volatile bool* target, bool value)
{
    QSC_ASSERT(target != NULL);

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        _InterlockedExchange8((volatile char*)target, (char)value);
#else
        __atomic_store_n(target, value, __ATOMIC_SEQ_CST);
#endif
    }
}

bool qsc_async_atomic_bool_exchange(volatile bool* target, bool value)
{
    QSC_ASSERT(target != NULL);

    bool res;

    res = false;

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        res = (_InterlockedExchange8((volatile char*)target, (char)value) != (char)0);
#else
        res = __atomic_exchange_n(target, value, __ATOMIC_SEQ_CST);
#endif
    }

    return res;
}

bool qsc_async_atomic_bool_compare_exchange(volatile bool* target, bool expected, bool desired)
{
    QSC_ASSERT(target != NULL);

    bool res;

    res = false;

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        res = (_InterlockedCompareExchange8((volatile char*)target, (char)desired, (char)expected) == (char)expected);
#else
        /* __atomic_compare_exchange_n writes back to expected on failure; use a copy */
        res = __atomic_compare_exchange_n(target, &expected, desired, false, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST);
#endif
    }

    return res;
}
int32_t qsc_async_atomic_int32_load(volatile int32_t* target)
{
    QSC_ASSERT(target != NULL);

    int32_t res;

    res = 0;

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        /* OR with 0: reads atomically without modifying the value */
        res = (int32_t)_InterlockedOr((volatile LONG*)target, 0L);
#else
        res = __atomic_load_n(target, __ATOMIC_SEQ_CST);
#endif
    }

    return res;
}

void qsc_async_atomic_int32_store(volatile int32_t* target, int32_t value)
{
    QSC_ASSERT(target != NULL);

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        _InterlockedExchange((volatile LONG*)target, (LONG)value);
#else
        __atomic_store_n(target, value, __ATOMIC_SEQ_CST);
#endif
    }
}

int32_t qsc_async_atomic_int32_exchange(volatile int32_t* target, int32_t value)
{
    QSC_ASSERT(target != NULL);

    int32_t res;

    res = 0;

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        res = (int32_t)_InterlockedExchange((volatile LONG*)target, (LONG)value);
#else
        res = __atomic_exchange_n(target, value, __ATOMIC_SEQ_CST);
#endif
    }

    return res;
}

bool qsc_async_atomic_int32_compare_exchange(volatile int32_t* target, int32_t expected, int32_t desired)
{
    QSC_ASSERT(target != NULL);

    bool res;

    res = false;

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        res = (_InterlockedCompareExchange((volatile LONG*)target, (LONG)desired, (LONG)expected) == (LONG)expected);
#else
        res = __atomic_compare_exchange_n(target, &expected, desired, false, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST);
#endif
    }

    return res;
}

int32_t qsc_async_atomic_int32_add(volatile int32_t* target, int32_t value)
{
    QSC_ASSERT(target != NULL);

    int32_t res;

    res = 0;

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        /* _InterlockedExchangeAdd returns the original value; add value to get the new value */
        res = (int32_t)_InterlockedExchangeAdd((volatile LONG*)target, (LONG)value) + value;
#else
        res = __atomic_add_fetch(target, value, __ATOMIC_SEQ_CST);
#endif
    }

    return res;
}

int32_t qsc_async_atomic_int32_subtract(volatile int32_t* target, int32_t value)
{
    QSC_ASSERT(target != NULL);

    int32_t res;

    res = 0;

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        /* Negate value to perform subtraction; original - value = new value */
        res = (int32_t)_InterlockedExchangeAdd((volatile LONG*)target, -(LONG)value) - value;
#else
        res = __atomic_sub_fetch(target, value, __ATOMIC_SEQ_CST);
#endif
    }

    return res;
}

int32_t qsc_async_atomic_int32_increment(volatile int32_t* target)
{
    QSC_ASSERT(target != NULL);

    int32_t res;

    res = 0;

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        /* _InterlockedIncrement returns the new value directly */
        res = (int32_t)_InterlockedIncrement((volatile LONG*)target);
#else
        res = __atomic_add_fetch(target, 1, __ATOMIC_SEQ_CST);
#endif
    }

    return res;
}

int32_t qsc_async_atomic_int32_decrement(volatile int32_t* target)
{
    QSC_ASSERT(target != NULL);

    int32_t res;

    res = 0;

    if (target != NULL)
    {
#if defined(QSC_SYSTEM_COMPILER_MSC)
        /* _InterlockedDecrement returns the new value directly */
        res = (int32_t)_InterlockedDecrement((volatile LONG*)target);
#else
        res = __atomic_sub_fetch(target, 1, __ATOMIC_SEQ_CST);
#endif
    }

    return res;
}

void qsc_async_launch_thread(void (*func)(void*), void* state)
{
    QSC_ASSERT(func != NULL);

    qsc_thread thd;

    if (func != NULL)
    {
        thd = qsc_async_thread_create(func, state);
        qsc_async_thread_wait(thd);
    }
}

void qsc_async_launch_parallel_threads(void (*func)(void*), size_t count, ...)
{
    QSC_ASSERT(func != NULL);
    QSC_ASSERT(count <= QSC_ASYNC_PARALLEL_MAX);

    qsc_thread thds[QSC_ASYNC_PARALLEL_MAX] = { 0 };
    va_list list;

    if (func != NULL)
    {
        va_start(list, count);

        for (size_t i = 0U; i < count; ++i)
        {
            thds[i] = qsc_async_thread_create(func, va_arg(list, void*));
        }

        qsc_async_thread_wait_all(thds, count);
        va_end(list);
    }
}

qsc_mutex qsc_async_mutex_create(void)
{
    qsc_mutex mtx;

#if defined(QSC_SYSTEM_OS_WINDOWS)
    mtx = CreateMutex(NULL, FALSE, NULL);
#else
    mtx = (pthread_mutex_t*)qsc_memutils_malloc(sizeof(pthread_mutex_t));
    if (mtx != NULL)
    {
        pthread_mutex_init(mtx, NULL);
    }
#endif

    return mtx;
}

bool qsc_async_mutex_destroy(qsc_mutex mtx)
{
    bool res;
    res = false;

    if (mtx != NULL)
    {
#if defined(QSC_SYSTEM_OS_WINDOWS)
        res = (bool)CloseHandle(mtx);
#else
        res = (pthread_mutex_destroy(mtx) == 0);
        qsc_memutils_alloc_free(mtx);
#endif
        mtx = NULL;
    }

    return res;
}

void qsc_async_mutex_lock(qsc_mutex mtx)
{
#if defined(QSC_SYSTEM_OS_WINDOWS)
    WaitForSingleObject(mtx, INFINITE);
#else
    pthread_mutex_lock(mtx);
#endif
}

qsc_mutex qsc_async_mutex_lock_ex(void)
{
    qsc_mutex mtx;

    mtx = qsc_async_mutex_create();
    qsc_async_mutex_lock(mtx);

    return mtx;
}

void qsc_async_mutex_unlock(qsc_mutex mtx)
{
#if defined(QSC_SYSTEM_OS_WINDOWS)
    ReleaseMutex(mtx);
#else
    pthread_mutex_unlock(mtx);
#endif
}

void qsc_async_mutex_unlock_ex(qsc_mutex mtx)
{
    qsc_async_mutex_unlock(mtx);
    qsc_async_mutex_destroy(mtx);
}

bool qsc_async_parallel_for(void (*task)(void* context, size_t index), void* context, size_t nthreads)
{
    QSC_ASSERT(task != NULL);
    QSC_ASSERT(context != NULL);
    QSC_ASSERT(nthreads != 0U);

    size_t cnt;
    bool res;

    cnt = 0U;
    res = false;

    if (task != NULL && context != NULL && nthreads != 0U)
    {
        qsc_thread* threads;
        async_thread_task_t* tasks;

        threads = (qsc_thread*)qsc_memutils_malloc(nthreads * sizeof(qsc_thread));

        if (threads != NULL)
        {
            tasks = (async_thread_task_t*)qsc_memutils_malloc(nthreads * sizeof(async_thread_task_t));

            if (tasks != NULL)
            {
                qsc_memutils_clear(threads, nthreads * sizeof(qsc_thread));
                qsc_memutils_clear(tasks, nthreads * sizeof(async_thread_task_t));
                res = true;

                /* process each task on a new thread */
                for (size_t i = 0U; i < nthreads; ++i)
                {
                    tasks[i].task = task;
                    tasks[i].context = context;
                    tasks[i].index = i;

#if defined(QSC_SYSTEM_OS_WINDOWS)
                    threads[i] = (HANDLE)_beginthreadex(NULL, 0, async_thread_worker, &tasks[i], 0, NULL);

                    if (threads[i] == NULL)
                    {
                        res = false;
                        break;
                    }
#elif defined(QSC_SYSTEM_OS_POSIX)
                    if (pthread_create(&threads[i], NULL, async_thread_worker, &tasks[i]) != 0)
                    {
                        res = false;
                        break;
                    }
#endif

                    ++cnt;
                }

                /* wait for all threads to finish */
                for (size_t i = 0U; i < cnt; ++i)
                {
#if defined(QSC_SYSTEM_OS_WINDOWS)
                    if (threads[i] != NULL)
                    {
                        WaitForSingleObject(threads[i], INFINITE);
                        CloseHandle(threads[i]);
                    }
#elif defined(QSC_SYSTEM_OS_POSIX)
                    pthread_join(threads[i], NULL);
#endif
                }

                qsc_memutils_alloc_free(tasks);
                tasks = NULL;
            }

            qsc_memutils_alloc_free(threads);
            threads = NULL;
        }
    }

    return res;
}

size_t qsc_async_processor_count(void)
{
    size_t cpus;

    cpus = qsc_sysutils_cpu_count();

    return cpus;
}

qsc_thread qsc_async_thread_create(void (*func)(void*), void* state)
{
    QSC_ASSERT(func != NULL);

    qsc_thread res;

#if defined(QSC_SYSTEM_OS_WINDOWS)
    res = NULL;
#else
    res = 0;
#endif

    if (func != NULL)
    {
#if defined(QSC_SYSTEM_OS_WINDOWS)
        uint32_t id = 0U;
        res = (HANDLE)_beginthreadex(NULL, 0, (uint32_t(__stdcall*)(void*))func, state, 0, &id);
#elif defined(QSC_SYSTEM_OS_POSIX)
        pthread_create(&res, NULL, (void* (*) (void*))func, state);
#endif
    }

    return res;
}

qsc_thread qsc_async_thread_create_ex(void (*func)(void**), void** args)
{
    QSC_ASSERT(func != NULL);

    qsc_thread res;

#if defined(QSC_SYSTEM_OS_WINDOWS)
    res = NULL;
#else
    res = 0;
#endif

    if (func != NULL)
    {
#if defined(QSC_SYSTEM_OS_WINDOWS)
        uint32_t id;

        id = 0U;
        res = (HANDLE)_beginthreadex(NULL, 0, (uint32_t(__stdcall*)(void*))func, (void*)args, 0, &id);
#elif defined(QSC_SYSTEM_OS_POSIX)
        pthread_create(&res, NULL, (void* (*)(void*))func, args);
#endif
    }

    return res;
}

qsc_thread qsc_async_thread_create_noargs(void (*func)(void))
{
    QSC_ASSERT(func != NULL);

    qsc_thread res;

#if defined(QSC_SYSTEM_OS_WINDOWS)
    res = NULL;
#else
    res = 0;
#endif

    if (func != NULL)
    {
#if defined(QSC_SYSTEM_OS_WINDOWS)
        uint32_t id = 0;
        res = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)func, NULL, 0, (LPDWORD)&id);
#elif defined(QSC_SYSTEM_OS_POSIX)
        pthread_create(&res, NULL, (void* (*) (void*))func, NULL);
#endif
    }

    return res;
}

int32_t qsc_async_thread_resume(qsc_thread handle)
{
    int32_t res;

#if defined(QSC_SYSTEM_OS_WINDOWS)
    res = ResumeThread(handle);
#elif defined(QSC_SYSTEM_OS_POSIX)
    pthread_mutex_lock(&tsusp);
    suspended = false;
    res = 0;
    pthread_cond_signal(&tcond);
    pthread_mutex_unlock(&tsusp);
#endif

    return res;
}

void qsc_async_thread_sleep(uint32_t msec)
{
    QSC_ASSERT(msec != 0U);

    if (msec != 0U)
    {
#if defined(QSC_SYSTEM_OS_WINDOWS)
        Sleep(msec);
#elif defined(QSC_SYSTEM_OS_POSIX)
        struct timespec ts;

        ts.tv_sec = (time_t)(msec / 1000U);
        ts.tv_nsec = (long)((msec % 1000U) * 1000000L);
        nanosleep(&ts, NULL);
#endif
    }
}

int32_t qsc_async_thread_suspend(qsc_thread handle)
{
    QSC_ASSERT(handle != 0);

    int32_t res;

#if defined(QSC_SYSTEM_OS_WINDOWS)
    res = SuspendThread(handle);
#elif defined(QSC_SYSTEM_OS_POSIX)
    pthread_mutex_lock(&tsusp);
    suspended = true;
    res = 0;

    while (suspended)
    {
        pthread_cond_wait(&tcond, &tsusp);
    }

    pthread_mutex_unlock(&tsusp);
#endif

    return res;
}

bool qsc_async_thread_terminate(qsc_thread handle)
{
    QSC_ASSERT(handle != 0);

    bool res;

    res = false;

#if defined(QSC_SYSTEM_OS_WINDOWS)
    res = (TerminateThread(handle, 0U) != 0);
    CloseHandle(handle);
#elif defined(QSC_SYSTEM_OS_POSIX)
    res = (pthread_cancel(handle) == 0);
#endif

    return res;
}

void qsc_async_thread_wait(qsc_thread handle)
{
#if defined(QSC_SYSTEM_OS_WINDOWS)
    WaitForSingleObject(handle, INFINITE);
#elif defined(QSC_SYSTEM_OS_POSIX)
    void* stg;
    pthread_join(handle, &stg);
#endif
}

void qsc_async_thread_wait_time(qsc_thread handle, uint32_t msec)
{
#if defined(QSC_SYSTEM_OS_WINDOWS)
    WaitForSingleObject(handle, msec);
#elif defined(QSC_SYSTEM_OS_POSIX) && defined(QSC_SYSTEM_OS_LINUX)
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    ts.tv_sec += msec / 1000U;
    ts.tv_nsec += (msec % 1000U) * 1000000L;

    if (ts.tv_nsec >= 1000000000L)
    {
        ts.tv_sec += 1;
        ts.tv_nsec -= 1000000000L;
    }

    pthread_timedjoin_np(handle, NULL, &ts);
#else
    (void)msec;
    void* stg;
    pthread_join(handle, &stg);
#endif
}

void qsc_async_thread_wait_all(qsc_thread* handles, size_t count)
{
    QSC_ASSERT(handles != NULL);

    if (handles != NULL && count != 0U)
    {
#if defined(QSC_SYSTEM_OS_WINDOWS)
        size_t i = 0U;

        while (i < count) 
        {
            DWORD batch = (DWORD)((count - i) < MAXIMUM_WAIT_OBJECTS ? (count - i) : MAXIMUM_WAIT_OBJECTS);
            WaitForMultipleObjects(batch, handles + i, TRUE, INFINITE);
            i += batch;
        }
#elif defined(QSC_SYSTEM_OS_POSIX)
        void* stg;

        for (size_t i = 0U; i < count; ++i)
        {
            pthread_join(handles[i], &stg);
        }
#endif
    }
}
