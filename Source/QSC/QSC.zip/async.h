/* 2020-2026 Quantum Resistant Cryptographic Solutions Corporation
 * All Rights Reserved.
 *
 * NOTICE:
 * This software and all accompanying materials are the exclusive property of
 * Quantum Resistant Cryptographic Solutions Corporation (QRCS). The intellectual
 * and technical concepts contained herein are proprietary to QRCS and are
 * protected under applicable Canadian, U.S., and international copyright,
 * patent, and trade secret laws.
 *
 * CRYPTOGRAPHIC ALGORITHMS AND IMPLEMENTATIONS:
 * - This software includes implementations of cryptographic primitives and
 *   algorithms that are standardized or in the public domain, such as AES
 *   and SHA-3, which are not proprietary to QRCS.
 * - This software also includes cryptographic primitives, constructions, and
 *   algorithms designed by QRCS, including but not limited to RCS, SCB, CSX, QMAC, and
 *   related components, which are proprietary to QRCS.
 * - All source code, implementations, protocol compositions, optimizations,
 *   parameter selections, and engineering work contained in this software are
 *   original works of QRCS and are protected under this license.
 *
 * LICENSE AND USE RESTRICTIONS:
 * - This software is licensed under the Quantum Resistant Cryptographic Solutions
 *   Public Research and Evaluation License (QRCS-PREL), 2025-2026.
 * - Permission is granted solely for non-commercial evaluation, academic research,
 *   cryptographic analysis, interoperability testing, and feasibility assessment.
 * - Commercial use, production deployment, commercial redistribution, or
 *   integration into products or services is strictly prohibited without a
 *   separate written license agreement executed with QRCS.
 * - Licensing and authorized distribution are solely at the discretion of QRCS.
 *
 * EXPERIMENTAL CRYPTOGRAPHY NOTICE:
 * Portions of this software may include experimental, novel, or evolving
 * cryptographic designs. Use of this software is entirely at the user's risk.
 *
 * DISCLAIMER:
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, SECURITY, OR NON-INFRINGEMENT. QRCS DISCLAIMS ALL
 * LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING FROM THE USE OR MISUSE OF THIS SOFTWARE.
 *
 * FULL LICENSE:
 * This software is subject to the Quantum Resistant Cryptographic Solutions
 * Public Research and Evaluation License (QRCS-PREL), 2025-2026. The complete license terms
 * are provided in the accompanying LICENSE file or at https://www.qrcscorp.ca.
 *
 * Written by: John G. Underhill
 * Contact: contact@qrcscorp.ca
 */

#ifndef QSC_THREADS_H
#define QSC_THREADS_H

#include "qsccommon.h"
#include <stdarg.h>

#if defined(QSC_SYSTEM_OS_WINDOWS)
	typedef void* qsc_mutex;
	typedef void* qsc_thread;
#elif defined(QSC_SYSTEM_OS_POSIX)
#   ifndef _XOPEN_SOURCE
#       define _XOPEN_SOURCE 700
#   endif
#   ifndef _DARWIN_C_SOURCE
#       define _DARWIN_C_SOURCE
#   endif
#   include <pthread.h>
	typedef pthread_mutex_t* qsc_mutex;
	typedef pthread_t qsc_thread;
#else
#   error your operating system is not supported!
#endif

QSC_CPLUSPLUS_ENABLED_START

/**
 * \file async.h
 * \brief Asynchronous Thread and Mutex Management Functions.
 *
 * \details
 * This header defines the public API for asynchronous thread management and mutex operations.
 * It provides functions for launching threads (both individually and in parallel), creating and
 * managing mutexes for thread synchronization, and waiting on thread execution. The API supports
 * both Windows and POSIX threading models.
 *
 * \code
 * // Example: Launch a single thread.
 * qsc_async_launch_thread(sample_task, (void*)arg);
 *
 * // Example: Launch multiple threads in parallel.
 * qsc_async_launch_parallel_threads(sample_task, 4, (void*)arg1, (void*)arg2, (void*)arg3, (void*)arg4);
 *
 * // Example: Create, lock, and unlock a mutex.
 * qsc_mutex mtx = qsc_async_mutex_create();
 * qsc_async_mutex_lock(mtx);
 * // Perform critical operations here.
 * qsc_async_mutex_unlock(mtx);
 * qsc_async_mutex_destroy(mtx);
 * \endcode
 *
 * \section async_links Reference Links:
 * - <a href="https://docs.microsoft.com/en-us/windows/win32/procthread/">Microsoft Windows Threading</a>
 * - <a href="https://pubs.opengroup.org/onlinepubs/9699919799/functions/pthread_create.html">POSIX Threads (pthreads)</a>
 */

/*!
 * \def QSC_ASYNC_PARALLEL_MAX
 * \brief The maximum number of threads that can be launched in parallel for a parallel for loop.
 */
#define QSC_ASYNC_PARALLEL_MAX 128ULL

/**
 * \brief Atomically load the current value of a boolean.
 *
 * \details
 * Reads the value at \p target using a sequentially consistent atomic load.
 * The operation is equivalent to acquiring the value without the possibility
 * of observing a partial write from a concurrent store.
 *
 * \param target: [volatile bool*] Pointer to the boolean to read. Must not be NULL.
 * 
 * \return [bool] The value held by \p target at the time of the load.
 */
QSC_EXPORT_API bool qsc_async_atomic_bool_load(volatile bool* target);

/**
 * \brief Atomically store a value into a boolean.
 *
 * \details
 * Writes \p value to \p target using a sequentially consistent atomic store.
 * Any thread that subsequently calls qsc_async_atomic_bool_load on the same
 * target is guaranteed to observe \p value or any later write.
 *
 * \param target: [volatile bool*] Pointer to the boolean to write. Must not be NULL.
 * \param value: [bool] The value to store.
 */
QSC_EXPORT_API void qsc_async_atomic_bool_store(volatile bool* target, bool value);

/**
 * \brief Atomically swap a boolean with a new value.
 *
 * \details
 * Stores \p value into \p target and returns the value that \p target held
 * immediately before the swap. The read and the write occur as a single
 * indivisible operation; no other thread can observe an intermediate state.
 *
 * \param target: [volatile bool*] Pointer to the boolean to swap. Must not be NULL.
 * \param value: [bool] The new value to store.
 * 
 * \return [bool] The previous value of \p target before the swap.
 */
QSC_EXPORT_API bool qsc_async_atomic_bool_exchange(volatile bool* target, bool value);

/**
 * \brief Atomically compare a boolean and conditionally store a new value.
 *
 * \details
 * Reads \p target and compares it to \p expected. If they are equal, \p desired
 * is written to \p target and the function returns true. If they differ, the
 * target is left unchanged and the function returns false. The comparison and
 * the conditional store are performed as a single indivisible operation.
 *
 * \param target: [volatile bool*] Pointer to the boolean to test and update. Must not be NULL.
 * \param expected: [bool] The value the caller expects \p target to currently hold.
 * \param desired: [bool] The value to store if the comparison succeeds.
 * 
 * \return [bool] True if the store was performed; false if \p target did not equal \p expected.
 */
QSC_EXPORT_API bool qsc_async_atomic_bool_compare_exchange(volatile bool* target, bool expected, bool desired);

/**
 * \brief Atomically load an int32_t value.
 *
 * Reads the current value of *target with sequential consistency.
 *
 * \param target: [volatile int32_t*] Pointer to the atomic integer.
 * 
 * \return [int32_t] The current value.
 */
QSC_EXPORT_API int32_t qsc_async_atomic_int32_load(volatile int32_t* target);

/**
 * \brief Atomically store an int32_t value.
 *
 * Writes value to *target with sequential consistency.
 *
 * \param target: [volatile int32_t*] Pointer to the atomic integer.
 * \param value: [int32_t] The value to store.
 */
QSC_EXPORT_API void qsc_async_atomic_int32_store(volatile int32_t* target, int32_t value);

/**
 * \brief Atomically exchange an int32_t value.
 *
 * Writes value to *target and returns the previous value.
 *
 * \param target: [volatile int32_t*] Pointer to the atomic integer.
 * \param value: [int32_t] The new value to store.
 * 
 * \return [int32_t] The previous value of *target.
 */
QSC_EXPORT_API int32_t qsc_async_atomic_int32_exchange(volatile int32_t* target, int32_t value);

/**
 * \brief Atomically compare and conditionally exchange an int32_t value.
 *
 * If *target equals expected, stores desired into *target.
 * The comparison and store occur as a single atomic operation.
 *
 * \param target: [volatile int32_t*] Pointer to the atomic integer.
 * \param expected: [int32_t] The value the caller expects *target to hold.
 * \param desired: [int32_t] The value to store if the comparison succeeds.
 * 
 * \return [bool] True if the exchange was performed; false otherwise.
 */
QSC_EXPORT_API bool qsc_async_atomic_int32_compare_exchange(volatile int32_t* target, int32_t expected, int32_t desired);

/**
 * \brief Atomically add a value to an int32_t.
 *
 * Adds value to *target and returns the value AFTER the addition.
 *
 * \param target: [volatile int32_t*] Pointer to the atomic integer.
 * \param value: [int32_t] The amount to add
 * 
 * \return [int32_t] The new value of *target after the addition.
 */
QSC_EXPORT_API int32_t qsc_async_atomic_int32_add(volatile int32_t* target, int32_t value);

/**
 * \brief Atomically subtract a value from an int32_t.
 *
 * Subtracts value from *target and returns the value AFTER the subtraction.
 *
 * \param target: [volatile int32_t*] Pointer to the atomic integer.
 * \param value: [int32_t] The amount to subtract.
 * 
 * \return [int32_t] The new value of *target after the subtraction.
 */
QSC_EXPORT_API int32_t qsc_async_atomic_int32_subtract(volatile int32_t* target, int32_t value);

/**
 * \brief Atomically increment an int32_t by one.
 *
 * Increments *target by one and returns the value AFTER the increment.
 *
 * \param target: [volatile int32_t*] Pointer to the atomic integer.
 * 
 * \return [int32_t] The new value of *target after the increment.
 */
QSC_EXPORT_API int32_t qsc_async_atomic_int32_increment(volatile int32_t* target);

/**
 * \brief Atomically decrement an int32_t by one.
 *
 * Decrements *target by one and returns the value AFTER the decrement.
 *
 * \param target: [volatile int32_t*] Pointer to the atomic integer.
 * 
 * \return [int32_t] The new value of *target after the decrement.
 */
QSC_EXPORT_API int32_t qsc_async_atomic_int32_decrement(volatile int32_t* target);

/**
 * \brief Launch a function on a new thread.
 *
 * Spawns a new thread to execute the provided function with a single argument.
 *
 * \param func: [void (*)(void*)] Pointer to the function to execute.
 * \param state: [void*] Pointer to the argument to pass to the function.
 */
QSC_EXPORT_API void qsc_async_launch_thread(void (*func)(void*), void* state);

/**
 * \brief Launch multiple threads in parallel using variadic arguments.
 *
 * Spawns several threads, each executing the provided function with its respective argument.
 *
 * \param func: [void (*)(void*)] Pointer to the function to execute.
 * \param count: [size_t] The number of threads (and corresponding arguments) to launch.
 * \param ...: [variadic] Variadic arguments representing the state for each thread.
 */
QSC_EXPORT_API void qsc_async_launch_parallel_threads(void (*func)(void*), size_t count, ...);

/**
 * \brief Create a mutex.
 *
 * Creates a new mutex object for synchronizing threads.
 *
 * \return [qsc_mutex] Returns a handle to the newly created mutex.
 */
QSC_EXPORT_API qsc_mutex qsc_async_mutex_create(void);

/**
 * \brief Destroy a mutex.
 *
 * Destroys the specified mutex object.
 *
 * \param mtx: [qsc_mutex] The mutex handle to destroy.
 * \return [bool] Returns true on successful destruction.
 */
QSC_EXPORT_API bool qsc_async_mutex_destroy(qsc_mutex mtx);

/**
 * \brief Lock a mutex.
 *
 * Blocks until the specified mutex is acquired.
 *
 * \param mtx: [qsc_mutex] The mutex to lock.
 */
QSC_EXPORT_API void qsc_async_mutex_lock(qsc_mutex mtx);

/**
 * \brief Create and lock a mutex.
 *
 * Creates a mutex, locks it immediately, and returns the locked mutex.
 *
 * \return [qsc_mutex] The locked mutex handle.
 */
QSC_EXPORT_API qsc_mutex qsc_async_mutex_lock_ex(void);

/**
 * \brief Unlock a mutex.
 *
 * Unlocks the specified mutex.
 *
 * \param mtx: [qsc_mutex] The mutex to unlock.
 */
QSC_EXPORT_API void qsc_async_mutex_unlock(qsc_mutex mtx);

/**
 * \brief Unlock and destroy a mutex.
 *
 * Unlocks the specified mutex and then destroys it.
 *
 * \param mtx: [qsc_mutex] The mutex to unlock and destroy.
 */
QSC_EXPORT_API void qsc_async_mutex_unlock_ex(qsc_mutex mtx);

/**
 * \brief Get the number of processor cores available.
 *
 * Retrieves the number of CPU cores (including hyper-threads) available on the system.
 *
 * \return [size_t] The number of processor cores.
 */
QSC_EXPORT_API size_t qsc_async_processor_count(void);

/**
 * \brief Create a thread with one parameter.
 *
 * Creates a new thread that executes the specified function with a single argument.
 *
 * \param func: [void (*)(void*)] Pointer to the function to execute in the new thread.
 * \param state: [void*] Pointer to the argument to pass to the thread function.
 * 
 * \return [qsc_thread] Returns a handle to the created thread, or NULL on failure.
 */
QSC_EXPORT_API qsc_thread qsc_async_thread_create(void (*func)(void*), void* state);

/**
 * \brief Create a thread with multiple parameters.
 *
 * Creates a new thread that executes the specified function with multiple arguments.
 *
 * \param func: [void (*)(void**)] Pointer to the function to execute in the new thread.
 * \param args: [void**] An array of pointers to the arguments.
 * 
 * \return [qsc_thread] Returns a handle to the created thread, or NULL on failure.
 */
QSC_EXPORT_API qsc_thread qsc_async_thread_create_ex(void (*func)(void**), void** args);

/**
 * \brief Create a thread with no arguments parameter.
 *
 * Creates a new thread that executes the specified function with multiple arguments.
 *
 * \param func: [void (*)(void**)] Pointer to the function to execute in the new thread.
 * 
 * \return [qsc_thread] Returns a handle to the created thread, or NULL on failure.
 */
QSC_EXPORT_API qsc_thread qsc_async_thread_create_noargs(void (*func)(void));

/**
 * \brief Resume a suspended thread.
 *
 * Resumes execution of a thread that has been suspended.
 *
 * \param handle: [qsc_thread] The thread handle to resume.
 * 
 * \return [int32_t] Returns zero on success.
 */
QSC_EXPORT_API int32_t qsc_async_thread_resume(qsc_thread handle);

/**
 * \brief Suspend the calling thread for a specified number of milliseconds.
 *
 * Suspends execution of the calling thread for the given duration.
 *
 * \param msec: [uint32_t] The number of milliseconds to sleep.
 */
QSC_EXPORT_API void qsc_async_thread_sleep(uint32_t msec);

/**
 * \brief Suspend a thread.
 *
 * Suspends the execution of the specified thread.
 *
 * \param handle: [qsc_thread] The thread handle to suspend.
 * 
 * \return [int32_t] Returns a non-negative value on success.
 */
QSC_EXPORT_API int32_t qsc_async_thread_suspend(qsc_thread handle);

/**
 * \brief Terminate a thread.
 *
 * Terminates the specified thread. On Windows, this may terminate the calling thread.
 *
 * \param handle: [qsc_thread] The thread handle to terminate.
 * 
 * \return [bool] Returns true if termination was successful.
 */
QSC_EXPORT_API bool qsc_async_thread_terminate(qsc_thread handle);

/**
 * \brief Wait for a thread to complete execution.
 *
 * Blocks until the specified thread has finished executing.
 *
 * \param handle: [qsc_thread] The thread handle to wait on.
 */
QSC_EXPORT_API void qsc_async_thread_wait(qsc_thread handle);

/**
 * \brief Wait for a thread to complete execution with a timeout.
 *
 * Blocks until the specified thread has finished executing or the timeout expires.
 *
 * \param handle: [qsc_thread] The thread handle to wait on.
 * \param msec: [uint32_t] The maximum number of milliseconds to wait.
 */
QSC_EXPORT_API void qsc_async_thread_wait_time(qsc_thread handle, uint32_t msec);

/**
 * \brief Wait for an array of threads to complete execution.
 *
 * Blocks until all threads in the provided array have finished executing.
 *
 * \param handles: [qsc_thread*] An array of thread handles.
 * \param count: [size_t] The number of threads in the array.
 */
QSC_EXPORT_API void qsc_async_thread_wait_all(qsc_thread* handles, size_t count);

QSC_CPLUSPLUS_ENABLED_END

#endif
