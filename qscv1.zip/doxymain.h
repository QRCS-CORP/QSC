/* 2020-2026 Quantum Resistant Cryptographic Solutions Corporation
 * All Rights Reserved.
 *
 * NOTICE:
 * This software and all accompanying materials are the exclusive property of
 * Quantum Resistant Cryptographic Solutions Corporation (QRCS). The intellectual
 * and technical concepts contained herein are proprietary to QRCS and are
 * protected under applicable Canadian, U.S., and international copyright,
 * patent, and trade secret laws.
 *
 * CRYPTOGRAPHIC ALGORITHMS AND IMPLEMENTATIONS:
 * - This software includes implementations of cryptographic primitives and
 *   algorithms that are standardized or in the public domain, such as AES
 *   and SHA-3, which are not proprietary to QRCS.
 * - This software also includes cryptographic primitives, constructions, and
 *   algorithms designed by QRCS, including but not limited to RCS, SCB, CSX, QMAC, and
 *   related components, which are proprietary to QRCS.
 * - All source code, implementations, protocol compositions, optimizations,
 *   parameter selections, and engineering work contained in this software are
 *   original works of QRCS and are protected under this license.
 *
 * LICENSE AND USE RESTRICTIONS:
 * - This software is licensed under the Quantum Resistant Cryptographic Solutions
 *   Public Research and Evaluation License (QRCS-PREL), 2025-2026.
 * - Permission is granted solely for non-commercial evaluation, academic research,
 *   cryptographic analysis, interoperability testing, and feasibility assessment.
 * - Commercial use, production deployment, commercial redistribution, or
 *   integration into products or services is strictly prohibited without a
 *   separate written license agreement executed with QRCS.
 * - Licensing and authorized distribution are solely at the discretion of QRCS.
 *
 * EXPERIMENTAL CRYPTOGRAPHY NOTICE:
 * Portions of this software may include experimental, novel, or evolving
 * cryptographic designs. Use of this software is entirely at the user's risk.
 *
 * DISCLAIMER:
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, SECURITY, OR NON-INFRINGEMENT. QRCS DISCLAIMS ALL
 * LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING FROM THE USE OR MISUSE OF THIS SOFTWARE.
 *
 * FULL LICENSE:
 * This software is subject to the Quantum Resistant Cryptographic Solutions
 * Public Research and Evaluation License (QRCS-PREL), 2025-2026. The complete license terms
 * are provided in the accompanying LICENSE file or at https://www.qrcscorp.ca.
 *
 * Written by: John G. Underhill
 * Contact: contact@qrcscorp.ca
 */

#ifndef DOXYMAIN_H
#define DOXYMAIN_H

/*! \mainpage QSC: Quantum Secure Cryptographic Solutions Library
 *
 * \brief Main documentation page for the QSC Library.
 *
 * \details
 * QSC (Quantum Secure Cryptographic Solutions) is a compact, self-contained, and highly optimized 
 * cryptographic library written in C. It is designed to provide next-generation, post-quantum secure 
 * cryptographic primitives for applications requiring long-term security. The library adheres to 
 * MISRA secure coding standards and is structured for clarity, ease of verification, and integration 
 * into secure communication platforms.
 *
 * \par Overview
 * The QSC Library includes a comprehensive suite of cryptographic algorithms and utilities, such as:
 * - **Asymmetric Cryptography:**
 *   - *Key Encapsulation Mechanisms:* McEliece (Niederreiter dual form), Kyber (FIPS-203), and NTRU.
 *   - *Digital Signature Schemes:* Sphincs+ (FIPS-205), Dilithium (FIPS-204), and Falcon.
 *	 - *Classical Asymmetric Algorithms:* ECDSA and ECDH using the EC25519 curve.
 * - **Symmetric Cryptography:**
 *   - *Block Ciphers:* AES with the blockcipher modes GCM, HBA, CBC, CTR, ECB, and PKCS7 padding.
 *   - *Authenticated Stream Ciphers:* ChaChaPoly1305, CSX (a wide-block AEAD ChaCha-based authenticated cipher using KMAC/QMAC), 
 *	    and RCS (an authenticated stream cipher based on wide-block Rijndael and KMAC/QMAC).
 * - **Hash Functions and MACs:**
 *   - Cryptographic message digests including SHA3 and SHA2.
 *   - Message authentication codes (MAC) via QMAC, KMAC, HMAC, and Poly1305.
 * - **Pseudo-Random Number Generation and Entropy:**
 *   - XOF functions (SHAKE and cSHAKE) used in DRBGs and key derivation functions (HKDF).
 *   - Secure random number generators (PRNGs) and entropy providers (ACP, CSP, RDP) that integrate hardware 
 *     randomness (e.g., Intel RDRAND) with system entropy.
 * - **System Utilities:**
 *   - Asynchronous threading, mutex-based synchronization, and dual IPv4/IPv6 networking stacks.
 *   - CPU feature detection (CPUID) and secure memory management with SIMD (AVX/AVX2/AVX512) optimizations.
 *	 - A complete dual-stack sockets library, support functions, a multi-threaded server and client architectures.
 *   - A large set of integrated tools; file, directory, string, integer, console, array, sockets, threading, and SIMD memory functions.
 *
 * \par Architecture and Performance
 * The QSC Library is architected with both portability and performance in mind:
 * - **Reference Implementations:** Clear and maintainable C code ensuring broad platform compatibility.
 * - **SIMD Optimizations:** Critical algorithms are implemented using AVX, AVX2, and AVX512 intrinsics to 
 *   leverage modern CPU capabilities, achieving superior performance.
 *
 * \par Supported Platforms
 * QSC has been thoroughly tested on:
 * - Windows 10/11/Server (Visual Studio)
 * - Ubuntu Linux (GCC)
 * - macOS (Apple Clang)
 *
 * \par References and Standards
 * - **NIST SHA3 (FIPS 202):** [SHA-3 FIPS 202](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.202.pdf)
 * - **AES (FIPS 197):** [AES Specification](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.197.pdf)
 * - **Microsoft CryptGenRandom Documentation:** [CryptGenRandom](https://docs.microsoft.com/en-us/windows/win32/seccrypto/cryptgenrandom)
 * - **POSIX /dev/urandom:** [Linux /dev/urandom](https://man7.org/linux/man-pages/man4/urandom.4.html)
 * - **Intel CPUID Instruction:** [Intel CPUID](https://software.intel.com/content/www/us/en/develop/articles/intel-64-architecture-cpuid-instruction.html)
 * - **AMD CPUID Documentation:** [AMD CPUID](https://www.amd.com/system/files/TechDocs/25481.pdf)
 * - **ChaCha Stream Cipher Specification:** [ChaCha Specification](https://cr.yp.to/chacha/chacha-20080120.pdf)
 * - **Dilithium (FIPS 204):** [Dilithium FIPS 204](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.204.pdf)
 * - **Classic McEliece Specification:** [McEliece Specification](https://www.randombit.net/mceliece/mceliece-spec.pdf)
 * - **Kyber Documentation:** See the PQ-Crystals Kyber documentation.
 * - **Galois Field Theory and Carryless Multiplication:** [Intel Intrinsics Reference](https://www.intel.com/content/www/us/en/develop/documentation/64-ia-32-architectures-software-developer-instruction-set-reference-guide-325383.pdf)
 *
 * \par Keywords
 * Cryptography, Post-Quantum, Asymmetric Cryptography, Symmetric Cryptography, Digital Signature, Key Encapsulation, 
 * Key Exchange, Hash Function, MAC, Pseudo-Random Number Generator, DRBG, Entropy, SIMD, AVX, AVX2, AVX512, 
 * Secure Memory, Asynchronous, MISRA, QSC.
 *
 * \par Example
 * Refer to the module-specific headers (e.g., aes.h, sha3.h, kyber.h, ecdh.h, ecdsa.h, etc.) for detailed usage examples.
 *
 *
 * \remarks
 * QSC is designed to serve as the foundational cryptographic solution for secure, post-quantum 
 * communications and is continuously updated to incorporate emerging cryptographic research and standards.
 * 
 * QRCS-PL private License. See license file for details.
 * All rights reserved by QRCS Corporation, copyrighted and patents pending.
 * 
 * \author John G. Underhill
 * \date 2025-03-14
 * \version 1.0.0.6c
 */

#endif
