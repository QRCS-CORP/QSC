#include "encoding.h"
#include "memutils.h"
#include "stringutils.h"
#include <stdio.h>

static bool encoding_header_labels_check(const char* input, const char* header, const char* footer, const char* seperator)
{
    char lbla[128U] = { 0U };
    char lblb[128U] = { 0U };
    int64_t posa;
    int64_t posb;
    size_t sepl;
    bool res;

    res = false;
    sepl = qsc_stringutils_string_size(header);

    if (input != NULL && header != NULL && footer != NULL && seperator != NULL && sepl > 0U)
    {
        if (qsc_stringutils_string_contains(input, header) == true &&
            qsc_stringutils_string_contains(input, footer) == true)
        {
            posa = sepl;
            posb = qsc_stringutils_find_string(input + sepl, seperator);

            if (posb > 0U)
            {
                qsc_stringutils_copy_substring(lbla, sizeof(lbla), input + posa, posb);

                posa = qsc_stringutils_find_string(input, footer);

                if (posa > 0U)
                {
                    posa += qsc_stringutils_string_size(footer);
                    posb = qsc_stringutils_find_string(input + posa, seperator);

                    if (posb > 0U)
                    {
                        qsc_stringutils_copy_substring(lblb, sizeof(lblb), input + posa, posb);

                        res = qsc_memutils_are_equal((uint8_t*)lbla, (uint8_t*)lblb, posb);
                    }
                }
            }
        }
    }

    return res;
}

static bool encoding_base64_length_valid(const char* input, const char* separator)
{
    int64_t posa;
    int64_t posb;
    size_t mod;
    size_t pctr;
    size_t sepl;
    bool res;

    res = false;
    mod = 4U;
    pctr = 0U;
    sepl = qsc_stringutils_string_size(separator);

    if (input != NULL && separator != NULL)
    {
        posa = qsc_stringutils_find_string(input, separator);

        if (posa >= 0U)
        {
            posa += sepl;
            posb = qsc_stringutils_find_string(input + posa, separator);

            if (posb >= 0U)
            {
                posa += sepl + posb;
                posb = qsc_stringutils_find_string(input + posa, separator);

                if (posb >= 0U)
                {
                    posb += posa;

                    for (int64_t i = posa; i < posb; ++i)
                    {
                        char c = input[i];

                        if ((c >= 'A' && c <= 'Z') ||
                            (c >= 'a' && c <= 'z') ||
                            (c >= '0' && c <= '9') ||
                            c == '+' || c == '/' || c == '=')
                        {
                            /* valid Base64 character */
                            ++pctr;
                        }
                    }

                    res = pctr % mod == 0U;
                }
            }
        }
    }

    return res;
}

qsc_encoding_ber_element* qsc_encoding_ber_decode_element(const uint8_t* buffer, size_t buflen, size_t* consumed)
{
    QSC_ASSERT(buffer != NULL);
    QSC_ASSERT(buflen != 0U);
    QSC_ASSERT(consumed != NULL);

    qsc_encoding_ber_element* relem;
    qsc_encoding_ber_element* elem;
    qsc_encoding_ber_element** tmp;
    qsc_encoding_ber_element* child;
    size_t pos;
    size_t taglen;
    size_t llen;
    size_t length;
    size_t achildren;
    size_t start;
    size_t chconsumed;
    uint8_t tagclass;
    uint32_t tagnumber;
    bool constructed;
    bool indefinite;

    relem = (qsc_encoding_ber_element*)NULL;

    if (buffer != NULL && buflen != 0U && consumed != NULL)
    {
        elem = (qsc_encoding_ber_element*)NULL;
        tmp = (qsc_encoding_ber_element**)NULL;
        child = (qsc_encoding_ber_element*)NULL;
        pos = 0U;
        length = 0U;
        tagclass = 0U;
        constructed = false;
        tagnumber = 0U;
        indefinite = false;

        if (buflen < 2U)
        {
            *consumed = 0U;
            relem = (qsc_encoding_ber_element*)NULL;
        }
        else
        {
            taglen = qsc_encoding_ber_decode_tag(buffer, buflen, &tagclass, &constructed, &tagnumber);

            if (taglen == 0U)
            {
                relem = (qsc_encoding_ber_element*)NULL;
            }
            else
            {
                pos = pos + taglen;
                llen = qsc_encoding_ber_decode_length(buffer + pos, buflen - pos, &length, &indefinite);

                if (llen == 0U)
                {
                    relem = (qsc_encoding_ber_element*)NULL;
                }
                else
                {
                    pos = pos + llen;
                    elem = (qsc_encoding_ber_element*)qsc_memutils_malloc(sizeof(qsc_encoding_ber_element));

                    if (elem == (qsc_encoding_ber_element*)NULL)
                    {
                        relem = (qsc_encoding_ber_element*)NULL;
                    }
                    else
                    {
                        qsc_memutils_clear(elem, sizeof(qsc_encoding_ber_element));
                        elem->tagclass = tagclass;
                        elem->constructed = constructed;
                        elem->tagnumber = tagnumber;
                        elem->indefinite = indefinite;

                        if (constructed == true)
                        {
                            elem->ccount = 0U;
                            elem->children = (qsc_encoding_ber_element**)NULL;
                            achildren = 0U;
                            start = pos;

                            if (indefinite == true)
                            {
                                while ((pos + 2U) <= buflen)
                                {
                                    if ((buffer[pos] == 0U) && (buffer[pos + 1U] == 0U))
                                    {
                                        break;
                                    }

                                    chconsumed = 0U;
                                    child = qsc_encoding_ber_decode_element(buffer + pos, buflen - pos, &chconsumed);

                                    if (child == (qsc_encoding_ber_element*)NULL)
                                    {
                                        break;
                                    }

                                    pos = pos + chconsumed;

                                    if (elem->ccount >= achildren)
                                    {
                                        if (achildren == 0U)
                                        {
                                            achildren = 4U;
                                        }
                                        else
                                        {
                                            achildren = achildren * 2U;
                                        }

                                        tmp = (qsc_encoding_ber_element**)qsc_memutils_realloc(elem->children, achildren * sizeof(qsc_encoding_ber_element*));

                                        if (tmp == (qsc_encoding_ber_element**)NULL)
                                        {
                                            break;
                                        }
                                        else
                                        {
                                            elem->children = tmp;
                                        }
                                    }

                                    elem->children[elem->ccount] = child;
                                    elem->ccount = elem->ccount + 1U;
                                    child = (qsc_encoding_ber_element*)NULL;
                                }

                                if (((pos + 2U) > buflen) || (buffer[pos] != 0U) || (buffer[pos + 1U] != 0U))
                                {
                                    relem = (qsc_encoding_ber_element*)NULL;
                                }
                                else
                                {
                                    pos = pos + 2U;
                                    elem->length = pos - start;
                                    elem->value = (uint8_t*)NULL;
                                    relem = elem;
                                    elem = (qsc_encoding_ber_element*)NULL;
                                }
                            }
                            else
                            {
                                size_t end;

                                end = pos + length;

                                while (pos < end)
                                {
                                    chconsumed = 0U;
                                    child = qsc_encoding_ber_decode_element(buffer + pos, end - pos, &chconsumed);

                                    if (child == (qsc_encoding_ber_element*)NULL)
                                    {
                                        break;
                                    }

                                    pos = pos + chconsumed;

                                    if (elem->ccount >= achildren)
                                    {
                                        if (achildren == 0U)
                                        {
                                            achildren = 4U;
                                        }
                                        else
                                        {
                                            achildren = achildren * 2U;
                                        }

                                        tmp = (qsc_encoding_ber_element**)qsc_memutils_realloc(elem->children, achildren * sizeof(qsc_encoding_ber_element*));
                                        
                                        if (tmp == (qsc_encoding_ber_element**)NULL)
                                        {
                                            break;
                                        }
                                        else
                                        {
                                            elem->children = tmp;
                                        }
                                    }

                                    elem->children[elem->ccount] = child;
                                    elem->ccount = elem->ccount + 1U;
                                    child = (qsc_encoding_ber_element*)NULL;
                                }

                                if (pos != end)
                                {
                                    relem = (qsc_encoding_ber_element*)NULL;
                                }
                                else
                                {
                                    elem->length = pos - start;
                                    elem->value = (uint8_t*)NULL;
                                    relem = elem;
                                    elem = (qsc_encoding_ber_element*)NULL;
                                }
                            }
                        }
                        else
                        {
                            if (indefinite == true)
                            {
                                relem = (qsc_encoding_ber_element*)NULL;
                            }
                            else if ((pos + length) > buflen)
                            {
                                relem = (qsc_encoding_ber_element*)NULL;
                            }
                            else
                            {
                                elem->length = length;
                                
                                elem->value = qsc_memutils_malloc(length);

                                if (elem->value != (uint8_t*)NULL)
                                {
                                    qsc_memutils_copy(elem->value, buffer + pos, length);
                                    pos = pos + length;
                                    relem = elem;
                                    elem = (qsc_encoding_ber_element*)NULL;
                                }
                                else
                                {
                                    relem = (qsc_encoding_ber_element*)NULL;
                                }
                            }
                        }
                    }
                }
            }

            *consumed = pos;
        }
    }

    return relem;
}

size_t qsc_encoding_ber_decode_length(const uint8_t* buffer, size_t buflen, size_t* length, bool* indef)
{
    QSC_ASSERT(buffer != NULL);
    QSC_ASSERT(buflen != 0U);
    QSC_ASSERT(length != NULL);
    QSC_ASSERT(indef != NULL);

    size_t res;

    res = 0U;

    if (buffer != NULL && buflen >= 1U && length != NULL && indef != NULL)
    {
        uint8_t first;

        first = buffer[0U];

        if (first == 0x80U)
        {
            *indef = true;
            /* for indefinite lengths the length isn't pre-known */
            *length = 0U;
            res = 1U;
        }
        else if ((first & 0x80U) == 0U)
        {
            *indef = false;
            *length = first;
            res = 1U;
        }
        else
        {
            uint8_t bnum;

            *indef = false;
            bnum = first & 0x7FU;

            if (buflen < 1 + bnum)
            {
                res = 0U;
            }
            else
            {
                size_t len;

                len = 0U;

                for (size_t i = 0U; i < bnum; ++i)
                {
                    len = (len << 8) | buffer[1 + i];
                }

                *length = len;

                res = 1 + bnum;
            }
        }
    }

    return res;
}

size_t qsc_encoding_ber_decode_tag(const uint8_t* buffer, size_t buflen, uint8_t* tagclass, bool* construct, uint32_t* tagnum)
{
    QSC_ASSERT(buffer != NULL);
    QSC_ASSERT(buflen != 0U);
    QSC_ASSERT(tagclass != NULL);
    QSC_ASSERT(construct != NULL);
    QSC_ASSERT(tagnum != NULL);

    size_t pos;

    pos = 0U;

    if (buffer != NULL && buflen > 0U && tagclass != NULL && construct != NULL && tagnum != NULL)
    {
        uint8_t first;
        uint8_t tagval;

        first = buffer[0U];
        *tagclass = first & 0xC0U;
        *construct = (first & 0x20U) ? true : false;
        tagval = first & 0x1FU;
        pos = 1U;

        if (tagval != 0x1FU)
        {
            *tagnum = tagval;
        }
        else
        {
            /* extended tag number: read base-128 encoded bytes */
            uint32_t num;

            num = 0U;

            while (pos < buflen) 
            {
                uint8_t b;

                b = buffer[pos];
                ++pos;
                num = (num << 7) | (b & 0x7FU);

                if ((b & 0x80U) == 0U)
                {
                    break;
                }
            }

            *tagnum = num;
        }
    }

    return pos;
}

size_t qsc_encoding_ber_encode_element(qsc_encoding_ber_element* element, uint8_t* buffer, size_t buflen)
{
    QSC_ASSERT(element != NULL);
    QSC_ASSERT(buffer != NULL);
    QSC_ASSERT(buflen != 0U);

    uint8_t alen[10U] = { 0U };
    uint8_t tagbuf[10U] = { 0U };
    size_t ret;
    size_t total;
    size_t taglen;
    size_t llen;

    ret = 0U;
    total = 0U;

    if (element != NULL && buffer != NULL && buflen != 0U)
    {
        taglen = qsc_encoding_ber_encode_tag(element->tagclass, element->constructed, element->tagnumber, tagbuf, (size_t)sizeof(tagbuf));
            
        if ((taglen != 0U) && (taglen <= buflen))
        {
            qsc_memutils_copy(buffer, tagbuf, taglen);
            total = total + taglen;

            if ((element->constructed == true) && (element->indefinite == true))
            {
                if ((buflen - total) >= 1U)
                {
                    alen[0U] = 0x80U;
                    llen = 1U;
                }
                else
                {
                    llen = 0U;
                }
            }
            else
            {
                llen = qsc_encoding_ber_encode_length(element->length, alen, (size_t)sizeof(alen));
            }

            if ((llen != 0U) && ((total + llen) <= buflen))
            {
                qsc_memutils_copy(buffer + total, alen, llen);
                total = total + llen;

                if (element->constructed == true)
                {
                    if (element->indefinite == true)
                    {
                        {
                            for (size_t i = 0U; i < element->ccount; i++)
                            {
                                size_t clen;

                                clen = qsc_encoding_ber_encode_element(element->children[i], buffer + total, buflen - total);
                                    
                                if (clen == 0U)
                                {
                                    total = 0U;
                                    /* Exit the loop on error */
                                    i = element->ccount;
                                }
                                else
                                {
                                    total = total + clen;
                                }
                            }
                        }

                        if ((total != 0U) && ((buflen - total) >= 2U))
                        {
                            buffer[total] = 0x00U;
                            total = total + 1U;
                            buffer[total] = 0x00U;
                            total = total + 1U;
                            ret = total;
                        }
                        else
                        {
                            ret = 0U;
                        }
                    }
                    else
                    {
                        if ((total + element->length) <= buflen)
                        {
                            qsc_memutils_copy(buffer + total, element->value, element->length);
                            total = total + element->length;
                            ret = total;
                        }
                        else
                        {
                            ret = 0U;
                        }
                    }
                }
                else
                {
                    /* primitive element */
                    if ((total + element->length) <= buflen)
                    {
                        qsc_memutils_copy(buffer + total, element->value, element->length);
                        total = total + element->length;
                        ret = total;
                    }
                    else
                    {
                        ret = 0U;
                    }
                }
            }
            else
            {
                ret = 0U;
            }
        }
        else
        {
            ret = 0U;
        }
    }

    return ret;
}

size_t qsc_encoding_ber_encode_length(size_t length, uint8_t* buffer, size_t buflen)
{
    QSC_ASSERT(buffer != NULL);
    QSC_ASSERT(buflen != 0U);

    size_t res;

    res = 1U;

    if (buffer != NULL && buflen >= 1)
    {
        if (length == QSC_BER_ENCODING_INDEFINITE_LENGTH)
        {
            /* indefinite length: one byte 0x80 */
            buffer[0U] = 0x80U;
        }
        else if (length < 128U)
        {
            /* short form */
            buffer[0U] = (uint8_t)length;
        }
        else
        {
            /* long form: determine the number of bytes needed to encode the length */
            uint8_t alen[8U] = { 0U };
            size_t bnum;
            size_t tlen;

            bnum = 0U;
            tlen = length;

            while (tlen > 0U)
            {
                alen[bnum] = tlen & 0xFFU;
                ++bnum;
                tlen >>= 8;
            }

            if (buflen < 1 + bnum)
            {
                res = 0U;
            }
            else
            {
                buffer[0U] = 0x80U | (uint8_t)bnum;

                for (size_t i = 0U; i < bnum; i++)
                {
                    /* big-endian order */
                    buffer[1U + i] = alen[bnum - 1U - i];
                }

                res = 1U + bnum;
            }
        }
    }

    return res;
}

size_t qsc_encoding_ber_encode_tag(uint8_t tagclass, bool construct, uint32_t tagnum, uint8_t* buffer, size_t buflen)
{
    QSC_ASSERT(buffer != NULL);
    QSC_ASSERT(buflen != 0U);

    size_t pos;
    uint8_t first;

    pos = 0U;

    if (buffer != NULL && buflen > 0U)
    {
        first = tagclass;

        if (construct)
        {
            /* set the constructed bit */
            first |= 0x20U;
        }

        if (tagnum < 31)
        {
            first |= (uint8_t)(tagnum & 0x1FU);
            buffer[pos] = first;
            ++pos;
        }
        else 
        {
            uint8_t temp[5U] = { 0U };
            size_t tmplen;

            /* indicate long-form tag */
            first |= 0x1FU;
            buffer[pos] = first;
            ++pos;
            tmplen = 0U;

            /* encode tagnumber in base-128 (big-endian, with continuation bits) */
            do 
            {
                temp[tmplen] = tagnum & 0x7FU;
                ++tmplen;
                tagnum >>= 7;
            } 
            while (tagnum > 0U);

            for (int32_t i = (int32_t)tmplen - 1; i >= 0; --i)
            {
                uint8_t b;

                b = temp[i];

                if (i != 0)
                {
                    /* set continuation bit on all but the last byte */
                    b |= 0x80U;
                }

                if (pos >= buflen)
                {
                    pos = 0U;
                    break;
                }

                buffer[pos] = b;
                ++pos;
            }
        }
    }

    return pos;
}

void encoding_ber_free_element(qsc_encoding_ber_element* element)
{
    QSC_ASSERT(element != NULL);

    if (element != NULL)
    {
        if (element->constructed)
        {
            for (size_t i = 0U; i < element->ccount; ++i) 
            {
                encoding_ber_free_element(element->children[i]);
            }
            
            qsc_memutils_alloc_free(element->children);
            element->children = NULL;
        }
        else 
        {
            qsc_memutils_alloc_free(element->value);
            element->value = NULL;
        }

        qsc_memutils_alloc_free(element);
        element = NULL;
    }
}

bool qsc_encoding_base64_decode(uint8_t* output, size_t otplen, const char* input, size_t inplen)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(inplen != 0U);

	const int32_t DECTBL[80U] = 
	{
		62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58,
		59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5,
		6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
		21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28,
		29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42,
		43, 44, 45, 46, 47, 48, 49, 50, 51 
	};

	size_t i;
	size_t j;
	int32_t v;
	bool res;

    res = false;

    if (output != NULL && input != NULL && inplen != 0U)
    {
        res = true;

        if (otplen < qsc_encoding_base64_decoded_size(input, inplen) || inplen % 4U != 0U)
        {
            res = false;
        }

        if (res == true)
        {
            for (i = 0U; i < inplen; i++)
            {
                if (qsc_encoding_base64_is_valid_char(input[i]) == false)
                {
                    res = false;
                    break;
                }
            }

            if (res == true)
            {
                for (i = 0U, j = 0U; i < inplen; i += 4, j += 3)
                {
                    char c = input[i];

                    if (c < '+' || c > 'z')
                    {
                        res = false;
                        break;
                    }

                    int idx = c - 43U;

                    if ((size_t)idx >= (sizeof(DECTBL)/sizeof(DECTBL[0U])))
                    {
                        res = false;
                        break;
                    }

                    v = DECTBL[input[i] - 43U];
                    v = ((uint32_t)v << 6) | DECTBL[input[i + 1U] - 43U];
                    v = input[i + 2U] == '=' ? (uint32_t)v << 6 : ((uint32_t)v << 6) | DECTBL[input[i + 2U] - 43U];
                    v = input[i + 3U] == '=' ? (uint32_t)v << 6 : ((uint32_t)v << 6) | DECTBL[input[i + 3U] - 43U];
                    output[j] = (v >> 16) & 0xFFU;

                    if (input[i + 2U] != '=')
                    {
                        output[j + 1U] = (v >> 8) & 0xFFU;
                    }

                    if (input[i + 3U] != '=')
                    {
                        output[j + 2U] = v & 0xFFU;
                    }
                }
            }
        }
    }

	return res;
}

size_t qsc_encoding_base64_decoded_size(const char* input, size_t length)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(length != 0U);

	size_t res;

	res = 0U;

	if (input != NULL && length != 0U)
	{
		res = (length / 4U) * 3U;

		for (size_t i = length - 1U; i > 0U; --i)
		{
			if (input[i] == '=')
			{
				--res;

				if (input[i - 1U] == '=')
				{
					--res;
				}

				break;
			}
		}
	}

	return res;
}

void qsc_encoding_base64_encode(char* output, size_t otplen, const uint8_t* input, size_t inplen)
{
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(otplen != 0U);
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(inplen != 0U);

	const char ENCTBL[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

	size_t i;
	size_t j;
	size_t v;

	if (output != NULL && input != NULL && inplen != 0U && qsc_encoding_base64_encoded_size(inplen) <= otplen)
	{
		for (i = 0U, j = 0; i < inplen; i += 3U, j += 4U)
		{
			v = input[i];
			v = i + 1U < inplen ? (v << 8) | input[i + 1U] : (v << 8);
			v = i + 2U < inplen ? (v << 8) | input[i + 2U] : (v << 8);

			output[j] = ENCTBL[(v >> 18) & 0x3FU];
			output[j + 1U] = ENCTBL[(v >> 12) & 0x3FU];

			if (i + 1U < inplen)
			{
				output[j + 2U] = ENCTBL[(v >> 6) & 0x3FU];
			}
			else
			{
				output[j + 2U] = '=';
			}

			if (i + 2U < inplen)
			{
				output[j + 3U] = ENCTBL[v & 0x3FU];
			}
			else
			{
				output[j + 3U] = '=';
			}
		}
	}
}

size_t qsc_encoding_base64_encoded_size(size_t length)
{
    QSC_ASSERT(length != 0U);

	size_t ret;

	ret = length;

	if (length % 3U != 0U)
	{
		ret += 3U - (length % 3U);
	}

	ret /= 3U;
	ret *= 4U;

	return ret;
}

bool qsc_encoding_base64_is_valid_char(char value)
{
	bool res;

	if (value >= '0' && value <= '9')
	{
		res = true;
	}
	else if (value >= 'A' && value <= 'Z')
	{
		res = true;
	}
	else if (value >= 'a' && value <= 'z')
	{
		res = true;
	}
	else if (value == '+' || value == '/' || value == '=')
	{
		res = true;
	}
	else
	{
		res = false;
	}

	return res;
}

qsc_encoding_ber_element* qsc_encoding_der_decode_element(const uint8_t* buffer, size_t buflen, size_t* consumed)
{
    QSC_ASSERT(buffer != NULL);
    QSC_ASSERT(buflen != 0U);
    QSC_ASSERT(consumed != NULL);

    qsc_encoding_ber_element* elem;

    elem = NULL;

    if (buffer != NULL && buflen != 0U && consumed != NULL)
    {
        elem = qsc_encoding_ber_decode_element(buffer, buflen, consumed);

        if (elem != NULL)
        {
            if (elem->indefinite == true)
            {
                /* DER disallows indefinite lengths */
                encoding_ber_free_element(elem);
                elem = NULL;
            }
        }
    }

    return elem;
}

size_t qsc_encoding_der_encode_element(qsc_encoding_ber_element* element, uint8_t* buffer, size_t buflen)
{
    uint8_t* contbuf;
    const size_t TEMP_BUF_SIZE = 16384;
    size_t total;
    size_t taglen;
    size_t lfield;
    size_t contlen;
    bool bcond;

    total = 0U;

    if (element != NULL && buffer != NULL && buflen != 0U)
    {
        /* For constructed elements, recursively encode each child element into a temporary buffer.
        * Here we allocate a temporary buffer. In a real implementation, you may wish to compute the
        * required size dynamically or reuse an allocation strategy.
        */
        contbuf = (uint8_t*)qsc_memutils_malloc(TEMP_BUF_SIZE);

        if (contbuf != NULL)
        {
            /* DER does not allow indefinite-length encoding. */
            if (element->indefinite == false)
            {
                /* Encode the tag using the BER tag encoding routine */
                taglen = qsc_encoding_ber_encode_tag(element->tagclass, element->constructed, element->tagnumber, buffer, buflen);

                if ((taglen != 0U) && (taglen <= buflen))
                {
                    bcond = true;
                    total += taglen;

                    if (element->constructed == true)
                    {
                        contlen = 0U;

                        for (size_t i = 0U; i < element->ccount; i++)
                        {
                            size_t clen;

                            clen = qsc_encoding_der_encode_element(element->children[i], contbuf + contlen, TEMP_BUF_SIZE - contlen);
                            
                            if (clen == 0U)
                            {
                                bcond = false;
                                break;
                            }

                            contlen += clen;
                        }
                    }
                    else
                    {
                        /* For primitive elements, the content is the raw value. */
                        contlen = element->length;
                    }

                    if (bcond == true)
                    {
                        /* Encode the length field (definite-length only) */
                        lfield = qsc_encoding_ber_encode_length(contlen, buffer + total, buflen - total);

                        if (lfield != 0U && (total + lfield) <= buflen)
                        {
                            total += lfield;

                            /* Copy the content bytes into the output buffer */
                            if ((total + contlen) <= buflen)
                            {
                                if (element->constructed == true)
                                {
                                    qsc_memutils_copy(buffer + total, contbuf, contlen);
                                }
                                else
                                {
                                    qsc_memutils_copy(buffer + total, element->value, contlen);
                                }

                                total += contlen;
                            }
                        }
                    }
                }

                qsc_memutils_alloc_free(contbuf);
                contbuf = NULL;
            }
        }
    }

    return total;
}

bool qsc_encoding_hex_decode(const char* input, size_t inplen, uint8_t* output, size_t otplen, size_t* declen)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(inplen != 0U);
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(otplen != 0U);
    QSC_ASSERT(declen != NULL);

    size_t req;
    bool res;

    *declen = 0U;
    req = inplen / 2;
    res = false;

    if (inplen % 2 == 0U && req <= otplen && input != NULL && output != NULL && declen != NULL)
    {
        res = true;

        for (size_t i = 0U; i < req; i++)
        {
            char c1;
            char c2;
            uint8_t nibble1;
            uint8_t nibble2;

            c1 = input[2U * i];
            c2 = input[(2U * i) + 1U];

            if (c1 >= '0' && c1 <= '9')
            {
                nibble1 = c1 - '0';
            }
            else if (c1 >= 'A' && c1 <= 'F')
            {
                nibble1 = c1 - 'A' + 10U;
            }
            else if (c1 >= 'a' && c1 <= 'f')
            {
                nibble1 = c1 - 'a' + 10U;
            }
            else
            {
                res = false;
                break;
            }

            if (c2 >= '0' && c2 <= '9')
            {
                nibble2 = c2 - '0';
            }
            else if (c2 >= 'A' && c2 <= 'F')
            {
                nibble2 = c2 - 'A' + 10U;
            }
            else if (c2 >= 'a' && c2 <= 'f')
            {
                nibble2 = c2 - 'a' + 10U;
            }
            else
            {
                res = false;
                break;
            }

            output[i] = (nibble1 << 4) | nibble2;
        }

        *declen = req;
    }

    return res;
}

bool qsc_encoding_hex_encode(const uint8_t* input, size_t inplen, char* output, size_t otplen)
{
    QSC_ASSERT(input != NULL);
    QSC_ASSERT(inplen != 0U);
    QSC_ASSERT(output != NULL);
    QSC_ASSERT(otplen != 0U);

    bool res;

    res = false;

    if (output != NULL && input != NULL && otplen >= (inplen * 2U) + 1U)
    {
        static const char hex_digits[] = "0123456789ABCDEF";

        for (size_t i = 0U; i < inplen; i++)
        {
            output[2U * i] = hex_digits[(input[i] >> 4) & 0x0FU];
            output[(2U * i) + 1U] = hex_digits[input[i] & 0x0FU];
        }

        output[inplen * 2U] = '\0';
        res = true;
    }

    return res;
}

bool qsc_encoding_pem_decode(const char* input, uint8_t* output, size_t otplen, size_t* declen)
{
    const char* lstart;
    const char* ppos;
    char* b64data;
    size_t linelen;
    size_t pinplen;
    size_t b64idx;
    char ch;
    bool res;

    res = false;

    if (input != NULL && output != NULL && declen != NULL && otplen != 0U)
    {
        *declen = 0U;

        if (encoding_header_labels_check(input, "-----BEGIN ", "-----END ", "-----") == true)
        {
            if (encoding_base64_length_valid(input, "-----"))
            {
                pinplen = qsc_stringutils_string_size(input);
                b64data = qsc_memutils_malloc(pinplen + 1U);

                if (b64data != NULL)
                {
                    b64idx = 0U;
                    lstart = input;
                    ppos = input;

                    /* process the PEM input line by line */
                    while (*ppos != '\0')
                    {
                        if (*ppos == '\n')
                        {
                            linelen = (size_t)(ppos - lstart);

                            if (linelen > 0U)
                            {
                                /* skip the line if its first non-whitespace character is '-' */
                                if (lstart[0U] != '-')
                                {
                                    for (size_t i = 0U; i < linelen; i++)
                                    {
                                        ch = lstart[i];

                                        if ((ch != ' ') && (ch != '\r') && (ch != '\t'))
                                        {
                                            b64data[b64idx] = ch;
                                            ++b64idx;
                                        }
                                    }
                                }
                            }

                            lstart = ppos + 1U;
                        }

                        ++ppos;
                    }

                    /* process any final line (if there is no trailing newline) */
                    if (lstart < ppos)
                    {
                        linelen = (size_t)(ppos - lstart);

                        if (linelen > 0U)
                        {
                            if (lstart[0U] != '-')
                            {
                                for (size_t i = 0U; i < linelen; i++)
                                {
                                    ch = lstart[i];

                                    if ((ch != ' ') && (ch != '\r') && (ch != '\t'))
                                    {
                                        b64data[b64idx] = ch;
                                        ++b64idx;
                                    }
                                }
                            }
                        }
                    }

                    b64data[b64idx] = '\0';

                    /* pad the Base64 string if necessary so that its length is a multiple of 4 */
                    {
                        size_t pad;
                        size_t rmd;

                        rmd = b64idx % 4U;

                        if (rmd != 0U)
                        {
                            pad = 4U - rmd;

                            /* assuming our temporary buffer is large enough */
                            for (size_t i = 0U; i < pad; i++)
                            {
                                b64data[b64idx] = '=';
                                ++b64idx;
                            }

                            b64data[b64idx] = '\0';
                        }
                    }

                    /* determine the expected decoded size */
                    {
                        size_t dexp;

                        dexp = qsc_encoding_base64_decoded_size(b64data, b64idx);

                        if (dexp <= otplen)
                        {
                            res = qsc_encoding_base64_decode(output, otplen, b64data, b64idx);

                            if (declen != NULL)
                            {
                                *declen = dexp;
                            }
                        }
                    }

                    qsc_memutils_alloc_free(b64data);
                    b64data = NULL;
                }
            }
        }
    }

    return res;
}

bool qsc_encoding_pem_encode(const char* label, char* output, size_t otplen, const uint8_t* data, size_t data_len)
{
    /* insert newline every 64 base64 characters */
    const size_t LINE_LENGTH = 64U;
    char header[128U];
    char footer[128U];
    char* b64data;
    size_t b64len;
    size_t cnklen;
    size_t pidx;
    int32_t hdrlen;
    int32_t ftrlen;
    bool res;

    /* create header and footer lines */
    hdrlen = snprintf(header, sizeof(header), "-----BEGIN %s-----\n", label);
    ftrlen = snprintf(footer, sizeof(footer), "-----END %s-----\n", label);
    b64data = NULL;
    res = false;

    if (hdrlen != 0 && ftrlen != 0)
    {
        /* compute the length required for Base64 encoding */
        b64len = qsc_encoding_base64_encoded_size(data_len);
        /* allocate a temporary buffer for the Base64 encoded data */
        /* +1 for null terminator */
        b64data = qsc_memutils_malloc(b64len + 1U);

        if (b64data != NULL)
        {
            qsc_memutils_clear(b64data, b64len + 1U);
            qsc_encoding_base64_encode(b64data, b64len + 1, data, data_len);
            pidx = 0U;

            /* write the header line */
            if (pidx + hdrlen < otplen)
            {
                qsc_memutils_copy(output + pidx, header, hdrlen);
                pidx += hdrlen;

                /* write the base64 data, inserting newline characters every LINE_LENGTH characters */
                for (size_t i = 0U; i < b64len; i += LINE_LENGTH)
                {
                    cnklen = (b64len - i >= LINE_LENGTH) ? LINE_LENGTH : (b64len - i);

                    if (pidx + cnklen + 1U < otplen)
                    {
                        qsc_memutils_copy(output + pidx, b64data + i, cnklen);
                        pidx += cnklen;
                        output[pidx] = '\n';
                        ++pidx;
                    }
                }

                /* append the footer */
                if (pidx + ftrlen < otplen)
                {
                    qsc_memutils_copy(output + pidx, footer, ftrlen);
                    pidx += ftrlen;

                    /* null-terminate the output */
                    if (pidx < otplen)
                    {
                        output[pidx] = '\0';
                    }
                    
                    res = true;
                }
            }

            qsc_memutils_alloc_free(b64data);
            b64data = NULL;
        }
    }

    return res;
}

#if defined (QSC_DEBUG_MODE)

static bool encoding_test_expect_pem_decode(const char* pem, const uint8_t* expected, size_t explen)
{
    uint8_t out[512] = { 0U };
    size_t declen;
    bool res;

    res = false;
    qsc_memutils_set_value(out, sizeof(out), 0xA5U);
    declen = 777U;

    if (qsc_encoding_pem_decode(pem, out, sizeof(out), &declen) == true)
    {
        if (declen == explen && qsc_memutils_are_equal(out, expected, explen) == true)
        {
            res = true;
        }
    }

    return res;
}

static bool encoding_test_contains_substr(const char* s, const char* sub)
{
    size_t i;
    size_t slen;
    size_t sublen;
    bool res;

    res = false;

    if (s != NULL && sub != NULL)
    {
        slen = qsc_stringutils_string_size(s);
        sublen = qsc_stringutils_string_size(sub);

        if (sublen != 0U || sublen <= slen)
        {
            for (i = 0U; i + sublen <= slen; ++i)
            {
                if (qsc_stringutils_string_compare(s + i, sub, sublen) == 0)
                {
                    res = true;
                    break;
                }
            }
        }
    }

    return res;
}

static bool encoding_test_pem_line_wrap(const char* pem, size_t maxline)
{
    /* checks that between header and footer, each base64 line has length <= 64, ignoring empty lines. */
    const char* p;
    const char* bol;
    size_t linelen;
    size_t i;
    bool inpayload;
    bool res;

    res = false;

    if (pem != NULL)
    {
        res = true;
        p = pem;
        bol = pem;
        inpayload = false;

        while (*p != '\0')
        {
            if (*p == '\n' || *(p + 1U) == '\0')
            {
                const char* eol;

                eol = (*p == '\n') ? p : (p + 1U);
                linelen = (size_t)(eol - bol);

                /* detect boundary lines (no leading whitespace tolerance needed for encode output) */
                if (linelen >= 11U && qsc_stringutils_string_compare(bol, "-----BEGIN ", 11U) == 0)
                {
                    inpayload = true;
                }
                else if (linelen >= 9U && qsc_stringutils_string_compare(bol, "-----END ", 9U) == 0)
                {
                    inpayload = false;
                }
                else if (inpayload == true)
                {
                    /* payload line: should be <= maxline unless empty */
                    if (linelen > 0U && linelen > maxline)
                    {
                        res = false;
                        break;
                    }

                    /* payload line should contain only base64 alphabet or '=' */
                    for (i = 0U; i < linelen; ++i)
                    {
                        const char c = bol[i];

                        if ((c >= 'A' && c <= 'Z') ||
                            (c >= 'a' && c <= 'z') ||
                            (c >= '0' && c <= '9') ||
                            (c == '+') || (c == '/') || (c == '='))
                        {
                            continue;
                        }

                        res = false;
                        break;
                    }
                }

                bol = (*p == '\n') ? (p + 1U) : eol;
            }

            ++p;
        }
    }

    return res;
}

static bool encoding_test_expect_pem_pass(const char* pem, const uint8_t* expected, size_t explen)
{
    uint8_t out[256] = { 0U };
    size_t declen;
    bool res;

    res = false;
    qsc_memutils_set_value(out, sizeof(out), 0xA5U);
    declen = 777U;

    if (qsc_encoding_pem_decode(pem, out, sizeof(out), &declen) == true)
    {
        res = (declen == explen && qsc_memutils_are_equal(out, expected, explen));
    }

    return res;
}

static bool encoding_expect_test_pem_fail(const char* pem)
{
    uint8_t out[256] = { 0U };
    size_t declen;
    bool res;

    res = false;
    qsc_memutils_set_value(out, sizeof(out), 0xA5U);
    declen = 123U;

    if (qsc_encoding_pem_decode(pem, out, sizeof(out), &declen) == false)
    {
        res = (declen == 0U);
    }

    return res;
}

static bool encoding_test_pem_decode(void)
{
    const char* valabc = "-----BEGIN CERTIFICATE-----\nYWJj\n-----END CERTIFICATE-----\n";
    const uint8_t exp_abc[3] = { 0x61U, 0x62U, 0x63U };
    const uint8_t exp_abcd[4] = { 0x61U, 0x62U, 0x63U, 0x64U };
    uint8_t small[3] = { 0U };
    size_t declen;
    bool res;

    res = false;
    
    if (encoding_test_expect_pem_pass(valabc, exp_abc, sizeof(exp_abc)) == true)
    {
        const char* valabcdws = "-----BEGIN CERTIFICATE-----\r\n  Y W J j Z A = =  \r\n\t\r\n-----END CERTIFICATE-----\r\n";

        if (encoding_test_expect_pem_pass(valabcdws, exp_abcd, sizeof(exp_abcd)) == true)
        {
            const char* invlabel = "-----BEGIN CERTIFICATE-----\n YWJj\n-----END PUBLIC KEY-----\n";

            if (encoding_expect_test_pem_fail(invlabel) == true)
            {
                const char* invlenmod4 = "-----BEGIN CERTIFICATE-----\nYWJ\n-----END CERTIFICATE-----\n";

                if (encoding_expect_test_pem_fail(invlenmod4) == true)
                {
                    const char* invpad = "-----BEGIN CERTIFICATE-----\nYW=Jj\n-----END CERTIFICATE-----\n";

                    if (encoding_expect_test_pem_fail(invpad) == true)
                    {
                        const char* invsmout = "-----BEGIN CERTIFICATE-----\nYWJjZA==\n-----END CERTIFICATE-----\n";

                        qsc_memutils_set_value(small, sizeof(small), 0xA5U);
                        declen = 999U;

                        if (qsc_encoding_pem_decode(invsmout, small, sizeof(small), &declen) == false)
                        {
                            res = (declen == 0U);
                        }
                    }
                }
            }
        }
    }

    return res;
}

static bool encoding_test_pem_encode(void)
{
    const char* lok = "CERTIFICATE";;
    char pem[2048] = { 0U };
    char pemsm[32] = { 0U };
    uint8_t data1[3] = { 0x61U, 0x62U, 0x63U };
    uint8_t data2[96] = { 0U };
    bool res;

    res = false;

    for (size_t i = 0U; i < sizeof(data2); ++i)
    {
        data2[i] = (uint8_t)i;
    }

    /* 1) encode must succeed with a conforming label */
    if (qsc_encoding_pem_encode(lok, pem, sizeof(pem), data1, sizeof(data1)) == true)
    {
        /* 2) header/footer correctness */
        if (encoding_test_contains_substr(pem, "-----BEGIN CERTIFICATE-----\n") == true &&
            encoding_test_contains_substr(pem, "-----END CERTIFICATE-----\n") == true)
        {
            /* 3) round-trip: encode then decode equals original */
            if (encoding_test_expect_pem_decode(pem, data1, sizeof(data1)) == true)
            {
                /* 4) wrapping and alphabet constraints for a larger payload */
                qsc_memutils_clear(pem, sizeof(pem));

                if (qsc_encoding_pem_encode(lok, pem, sizeof(pem), data2, sizeof(data2)) == true &&
                    encoding_test_pem_line_wrap(pem, 64U) == true &&
                    encoding_test_expect_pem_decode(pem, data2, sizeof(data2)) == true)
                {
                    /* 5) output buffer too small must fail */
                    qsc_memutils_clear(pemsm, sizeof(pemsm));

                    if (qsc_encoding_pem_encode(lok, pemsm, sizeof(pemsm), data2, sizeof(data2)) == false)
                    {
                        res = true;
                    }
                }
            }
        }
    }

    return res;
}

bool qsc_encoding_tests()
{
    bool res;

    res = false;

    if (encoding_test_pem_decode() == true)
    {
        if (encoding_test_pem_encode() == true)
        {
            res = true;
        }
    }

    return res;
}
#endif
